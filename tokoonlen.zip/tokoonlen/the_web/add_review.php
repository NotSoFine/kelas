<?php
session_start();
include 'db.php';

// Check if user is logged in
if (!isset($_SESSION['user_id']) && !isset($_SESSION['admin_id'])) {
    header("Location: login.php");
    exit;
}

// Check if form was submitted
if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !isset($_POST['product_id']) || !isset($_POST['rating']) || !isset($_POST['comment'])) {
    header("Location: index.php");
    exit;
}

$product_id = $_POST['product_id'];
$rating = (int)$_POST['rating'];
$comment = trim($_POST['comment']);
$user_id = $_SESSION['user_id'] ?? $_SESSION['admin_id'];

// Validate data
if ($rating < 1 || $rating > 5) {
    header("Location: product_detail.php?id=$product_id&error=invalid_rating");
    exit;
}

if (empty($comment)) {
    header("Location: product_detail.php?id=$product_id&error=empty_comment");
    exit;
}

try {
    // Check if reviews table exists, create it if not
    $checkTable = $pdo->query("SHOW TABLES LIKE 'reviews'");
    if ($checkTable->rowCount() === 0) {
        // Create reviews table
        $createTable = "CREATE TABLE reviews (
            id INT AUTO_INCREMENT PRIMARY KEY,
            product_id INT NOT NULL,
            user_id INT NOT NULL,
            rating INT NOT NULL,
            comment TEXT NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE,
            FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
        )";
        $pdo->exec($createTable);
    }
    
    // Check if user already reviewed this product
    $checkReview = $pdo->prepare("SELECT id FROM reviews WHERE product_id = ? AND user_id = ?");
    $checkReview->execute([$product_id, $user_id]);
    
    if ($checkReview->rowCount() > 0) {
        // Update existing review
        $reviewId = $checkReview->fetchColumn();
        $updateReview = $pdo->prepare("UPDATE reviews SET rating = ?, comment = ?, created_at = CURRENT_TIMESTAMP WHERE id = ?");
        $updateReview->execute([$rating, $comment, $reviewId]);
        
        header("Location: product_detail.php?id=$product_id&updated=1");
        exit;
    } else {
        // Insert new review
        $insertReview = $pdo->prepare("INSERT INTO reviews (product_id, user_id, rating, comment) VALUES (?, ?, ?, ?)");
        $insertReview->execute([$product_id, $user_id, $rating, $comment]);
        
        header("Location: product_detail.php?id=$product_id&reviewed=1");
        exit;
    }
} catch (PDOException $e) {
    // Log error and redirect with error message
    error_log("Review submission error: " . $e->getMessage());
    header("Location: product_detail.php?id=$product_id&error=database");
    exit;
}
?> 