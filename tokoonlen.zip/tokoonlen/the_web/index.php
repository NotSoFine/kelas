<?php
session_start();
include 'db.php';

// Handle add to cart directly on index page
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_to_cart']) && isset($_POST['product_id'])) {
    $product_id = $_POST['product_id'];
    $quantity = isset($_POST['quantity']) ? (int)$_POST['quantity'] : 1;
    
    // Fetch product data
    $stmt = $pdo->prepare("SELECT * FROM products WHERE id = ?");
    $stmt->execute([$product_id]);
    $product = $stmt->fetch();
    
    if ($product) {
        if ($quantity <= 0) {
            $quantity = 1;
        }
        
        if ($quantity > $product['stock']) {
            $quantity = $product['stock'];
        }
        
        // Initialize cart in session if it doesn't exist
        if (!isset($_SESSION['cart'])) {
            $_SESSION['cart'] = [];
        }
        
        // Check if product already in cart
        $found = false;
        foreach ($_SESSION['cart'] as &$item) {
            if ($item['id'] == $product_id) {
                $item['quantity'] += $quantity;
                $found = true;
                break;
            }
        }
        
        // Add new product to cart if not found
        if (!$found) {
            $_SESSION['cart'][] = [
                'id' => $product_id,
                'name' => $product['name'],
                'price' => $product['price'],
                'discount' => $product['discount'],
                'image' => $product['image'],
                'quantity' => $quantity
            ];
        }
        
        // Set a flag to show notification
        $_SESSION['cart_notification'] = [
            'product_name' => $product['name'],
            'time' => time()
        ];
    }
    
    // Redirect back to the current page (index.php) with any existing query parameters
    $redirect = 'index.php';
    if (!empty($_SERVER['QUERY_STRING'])) {
        $redirect .= '?' . $_SERVER['QUERY_STRING'];
    }
    header("Location: $redirect");
    exit;
}

// Default sorting
$sort = isset($_GET['sort']) ? $_GET['sort'] : 'newest';
$search = isset($_GET['search']) ? $_GET['search'] : '';
$category = isset($_GET['category']) ? $_GET['category'] : '';

try {
    // Base query
    $productQuery = "SELECT * FROM products";
    $params = [];
    
    // Add search and category conditions
    $conditions = [];
    
    if (!empty($search)) {
        $conditions[] = "(name LIKE ? OR description LIKE ? OR category LIKE ?)";
        $searchTerm = "%$search%";
        $params[] = $searchTerm;
        $params[] = $searchTerm;
        $params[] = $searchTerm;
    }
    
    if (!empty($category)) {
        $conditions[] = "category = ?";
        $params[] = $category;
    }
    
    // Combine all conditions if any exist
    if (!empty($conditions)) {
        $productQuery .= " WHERE " . implode(" AND ", $conditions);
    }
    
    // Add sorting
    switch ($sort) {
        case 'price_low':
            $productQuery .= " ORDER BY (price - discount) ASC";
            break;
        case 'price_high':
            $productQuery .= " ORDER BY (price - discount) DESC";
            break;
        case 'name_asc':
            $productQuery .= " ORDER BY name ASC";
            break;
        case 'name_desc':
            $productQuery .= " ORDER BY name DESC";
            break;
        case 'newest':
        default:
            $productQuery .= " ORDER BY id DESC";
            break;
    }
    
    // Fetch discounted products
    $discountedQuery = $pdo->query("SELECT * FROM products WHERE discount > 0 LIMIT 6");
    $discountedProducts = $discountedQuery->fetchAll(PDO::FETCH_ASSOC);

    // Fetch products based on search and sort
    $stmt = $pdo->prepare($productQuery . " LIMIT 10");
    $stmt->execute($params);
    $products = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Count total products for the search
    $countQuery = str_replace("SELECT *", "SELECT COUNT(*)", $productQuery);
    $countStmt = $pdo->prepare($countQuery);
    $countStmt->execute($params);
    $totalProducts = $countStmt->fetchColumn();
    
    // Get all available categories for filter
    $categoryStmt = $pdo->query("SELECT DISTINCT category FROM products WHERE category IS NOT NULL ORDER BY category");
    $categories = $categoryStmt->fetchAll(PDO::FETCH_COLUMN);
    
    // Try to fetch banner/carousel images from database
    // Check if banners table exists first
    $banners = [];
    try {
        $checkTable = $pdo->query("SHOW TABLES LIKE 'banners'");
        if ($checkTable->rowCount() > 0) {
            $bannersQuery = $pdo->query("SELECT * FROM banners WHERE active = 1 ORDER BY position ASC LIMIT 3");
            $banners = $bannersQuery->fetchAll(PDO::FETCH_ASSOC);
        }
    } catch (PDOException $e) {
        // Table doesn't exist or other error, use default images
    }
    
    // If no banners in database, use default images
    if (empty($banners)) {
        $banners = [
            ['id' => 1, 'image' => 'assets/carousel/carousel1.png', 'title' => 'Welcome to EcomPro', 'description' => 'Your one-stop shop for quality products'],
            ['id' => 2, 'image' => 'assets/carousel/carousel2.jpg', 'title' => 'Great Deals', 'description' => 'Check out our special offers'],
            ['id' => 3, 'image' => 'assets/carousel/carousel3.jpg', 'title' => 'New Arrivals', 'description' => 'Discover our latest products']
        ];
    }
    
} catch (PDOException $e) {
    die("Database error: " . $e->getMessage());
}

// Check if user is logged in
$isLoggedIn = isset($_SESSION['user_id']) || isset($_SESSION['admin_id']);
$username = $_SESSION['username'] ?? $_SESSION['admin_username'] ?? '';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>EcomPro - Home</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome for icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

    <style>
        .card-img-top {
            height: 200px;
            object-fit: cover;
        }
        .strike {
            text-decoration: line-through;
            color: gray;
        }
        .navbar-brand {
            font-weight: 700;
            font-size: 1.8rem;
            color: #0d6efd;
        }
        .search-bar {
            background-color: #f8f9fa;
            padding: 15px 0;
            border-bottom: 1px solid #e9ecef;
        }
        .sort-options {
            font-size: 0.9rem;
        }
        .sort-options .active {
            color: #0d6efd;
            font-weight: 600;
        }
        .carousel-caption {
            background-color: rgba(0,0,0,0.5);
            border-radius: 10px;
            padding: 15px;
        }
        .cart-notification {
            position: fixed;
            top: 20px;
            right: 20px;
            z-index: 1050;
            max-width: 300px;
        }
    </style>
</head>
<body>

<!-- Cart notification -->
<?php if (isset($_SESSION['cart_notification']) && (time() - $_SESSION['cart_notification']['time'] < 5)): ?>
    <div class="cart-notification">
        <div class="toast show" role="alert" aria-live="assertive" aria-atomic="true">
            <div class="toast-header bg-success text-white">
                <strong class="me-auto"><i class="fas fa-check-circle me-2"></i> Added to Cart</strong>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="toast" aria-label="Close"></button>
            </div>
            <div class="toast-body">
                <strong><?php echo htmlspecialchars($_SESSION['cart_notification']['product_name']); ?></strong> has been added to your cart.
                <div class="mt-2">
                    <a href="cart.php" class="btn btn-sm btn-primary">View Cart</a>
                </div>
            </div>
        </div>
    </div>
<?php endif; ?>

<!-- Main Navbar -->
<nav class="navbar navbar-expand-lg navbar-light bg-white shadow-sm">
    <div class="container">
        <a class="navbar-brand" href="index.php">EcomPro</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav me-auto">
                <li class="nav-item">
                    <a class="nav-link active" href="index.php">Home</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="catalog.php">Catalog</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="about.php">About</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="contact.php">Contact</a>
                </li>
            </ul>
            <ul class="navbar-nav">
                <?php if ($isLoggedIn): ?>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown">
                            <i class="fas fa-user-circle me-1"></i> <?php echo htmlspecialchars($username); ?>
                        </a>
                        <ul class="dropdown-menu dropdown-menu-end">
                            <?php if (isset($_SESSION['admin_id'])): ?>
                                <li><a class="dropdown-item" href="admin/index.php">Admin Dashboard</a></li>
                                <li><hr class="dropdown-divider"></li>
                            <?php endif; ?>
                            <li><a class="dropdown-item" href="profile.php">My Profile</a></li>
                            <li><a class="dropdown-item" href="orders.php">My Orders</a></li>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item" href="logout.php">Logout</a></li>
                        </ul>
                    </li>
                <?php else: ?>
                    <li class="nav-item">
                        <a class="nav-link" href="login.php">Login</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="register.php">Register</a>
                    </li>
                <?php endif; ?>
                <li class="nav-item">
                    <a class="nav-link" href="cart.php">
                        <i class="fas fa-shopping-cart"></i>
                    </a>
                </li>
            </ul>
        </div>
    </div>
</nav>

<!-- Search Bar -->
<div class="search-bar">
    <div class="container">
        <div class="row g-3">
            <div class="col-md-6">
                <form action="index.php" method="GET" class="d-flex">
                    <?php if (!empty($sort)): ?>
                        <input type="hidden" name="sort" value="<?php echo htmlspecialchars($sort); ?>">
                    <?php endif; ?>
                    <?php if (!empty($category)): ?>
                        <input type="hidden" name="category" value="<?php echo htmlspecialchars($category); ?>">
                    <?php endif; ?>
                    <input class="form-control me-2" type="search" name="search" placeholder="Search products..." value="<?php echo htmlspecialchars($search); ?>">
                    <button class="btn btn-primary" type="submit">
                        <i class="fas fa-search"></i>
                    </button>
                </form>
            </div>
            <div class="col-md-3">
                <div class="dropdown">
                    <button class="btn btn-outline-secondary dropdown-toggle w-100" type="button" id="categoryDropdown" data-bs-toggle="dropdown" aria-expanded="false">
                        <?php if (!empty($category)): ?>
                            Category: <?php echo htmlspecialchars($category); ?>
                        <?php else: ?>
                            All Categories
                        <?php endif; ?>
                    </button>
                    <ul class="dropdown-menu w-100" aria-labelledby="categoryDropdown">
                        <li><a class="dropdown-item <?php echo empty($category) ? 'active' : ''; ?>" href="index.php?<?php echo http_build_query(array_merge($_GET, ['category' => ''])); ?>">All Categories</a></li>
                        <?php foreach ($categories as $cat): ?>
                            <li><a class="dropdown-item <?php echo $category === $cat ? 'active' : ''; ?>" href="index.php?<?php echo http_build_query(array_merge($_GET, ['category' => $cat])); ?>"><?php echo htmlspecialchars($cat); ?></a></li>
                        <?php endforeach; ?>
                    </ul>
                </div>
            </div>
            <div class="col-md-3">
                <div class="dropdown">
                    <button class="btn btn-outline-secondary dropdown-toggle w-100" type="button" id="sortDropdown" data-bs-toggle="dropdown" aria-expanded="false">
                        Sort By
                    </button>
                    <ul class="dropdown-menu w-100" aria-labelledby="sortDropdown">
                        <li><a class="dropdown-item <?php echo $sort === 'newest' ? 'active' : ''; ?>" href="index.php?<?php echo http_build_query(array_merge($_GET, ['sort' => 'newest'])); ?>">Newest</a></li>
                        <li><a class="dropdown-item <?php echo $sort === 'price_low' ? 'active' : ''; ?>" href="index.php?<?php echo http_build_query(array_merge($_GET, ['sort' => 'price_low'])); ?>">Price: Low to High</a></li>
                        <li><a class="dropdown-item <?php echo $sort === 'price_high' ? 'active' : ''; ?>" href="index.php?<?php echo http_build_query(array_merge($_GET, ['sort' => 'price_high'])); ?>">Price: High to Low</a></li>
                        <li><a class="dropdown-item <?php echo $sort === 'name_asc' ? 'active' : ''; ?>" href="index.php?<?php echo http_build_query(array_merge($_GET, ['sort' => 'name_asc'])); ?>">Name: A to Z</a></li>
                        <li><a class="dropdown-item <?php echo $sort === 'name_desc' ? 'active' : ''; ?>" href="index.php?<?php echo http_build_query(array_merge($_GET, ['sort' => 'name_desc'])); ?>">Name: Z to A</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="container mt-4">
    <?php if (!empty($search)): ?>
        <div class="mb-4">
            <h4>Search Results for "<?php echo htmlspecialchars($search); ?>"</h4>
            <p><?php echo $totalProducts; ?> products found</p>
        </div>
    <?php else: ?>
        <!-- Carousel -->
        <div id="carouselExampleIndicators" class="carousel slide mb-5" data-bs-ride="carousel">
            <div class="carousel-indicators">
                <?php foreach ($banners as $index => $banner): ?>
                    <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="<?php echo $index; ?>" <?php echo $index === 0 ? 'class="active"' : ''; ?>></button>
                <?php endforeach; ?>
            </div>
            <div class="carousel-inner">
                <?php foreach ($banners as $index => $banner): ?>
                    <div class="carousel-item <?php echo $index === 0 ? 'active' : ''; ?>">
                        <img src="<?php echo htmlspecialchars($banner['image']); ?>" class="d-block w-100" alt="<?php echo htmlspecialchars($banner['title'] ?? 'Banner '.($index+1)); ?>">
                        <?php if (!empty($banner['title']) || !empty($banner['description'])): ?>
                            <div class="carousel-caption d-none d-md-block">
                                <?php if (!empty($banner['title'])): ?>
                                    <h5><?php echo htmlspecialchars($banner['title']); ?></h5>
                                <?php endif; ?>
                                <?php if (!empty($banner['description'])): ?>
                                    <p><?php echo htmlspecialchars($banner['description']); ?></p>
                                <?php endif; ?>
                            </div>
                        <?php endif; ?>
                    </div>
                <?php endforeach; ?>
            </div>
            <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="prev">
                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                <span class="visually-hidden">Previous</span>
            </button>
            <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="next">
                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                <span class="visually-hidden">Next</span>
            </button>
        </div>

        <!-- Discounted Products -->
        <h4>Discounted Products</h4>
        <div class="row">
            <?php foreach ($discountedProducts as $product): ?>
                <div class="col-md-4 mb-4">
                    <div class="card h-100">
                        <a href="product_detail.php?id=<?= $product['id'] ?>" class="text-decoration-none">
                            <img src="<?= $product['image'] ?>" class="card-img-top" alt="Product">
                        </a>
                        <div class="card-body d-flex flex-column">
                            <h5 class="card-title">
                                <a href="product_detail.php?id=<?= $product['id'] ?>" class="text-decoration-none text-dark">
                                    <?= htmlspecialchars($product['name']) ?>
                                </a>
                            </h5>
                            
                            <?php if (!empty($product['category'])): ?>
                                <div class="mb-2">
                                    <a href="catalog.php?category=<?php echo urlencode($product['category']); ?>" class="badge bg-info text-decoration-none">
                                        <?php echo htmlspecialchars($product['category']); ?>
                                    </a>
                                </div>
                            <?php endif; ?>
                            
                            <p class="card-text flex-grow-1">
                                <?php 
                                    $desc = $product['description'] ?? 'No description available';
                                    echo strlen($desc) > 100 ? htmlspecialchars(substr($desc, 0, 100)) . '...' : htmlspecialchars($desc);
                                ?>
                            </p>
                            
                            <div>
                                <p>
                                    <span class="strike">$<?= number_format($product['price'], 2) ?></span>
                                    <strong class="text-danger">$<?= number_format($product['price'] - $product['discount'], 2) ?></strong>
                                </p>
                                <p class="mb-3">Stock: <?= $product['stock'] ?></p>
                                <form action="" method="POST" class="d-grid">
                                    <input type="hidden" name="add_to_cart" value="1">
                                    <input type="hidden" name="quantity" value="1">
                                    <input type="hidden" name="product_id" value="<?= $product['id'] ?>">
                                    <button type="submit" class="btn btn-sm btn-outline-primary">
                                        <i class="fas fa-cart-plus me-1"></i> Add to Cart
                                    </button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>

    <!-- Products -->
    <h4 class="mt-4"><?php echo !empty($search) ? 'Products' : 'Latest Products'; ?></h4>
    <?php if (empty($products)): ?>
        <div class="alert alert-info">No products found.</div>
    <?php else: ?>
        <div class="row">
            <?php foreach ($products as $product): ?>
                <div class="col-md-3 mb-4">
                    <div class="card h-100">
                        <a href="product_detail.php?id=<?= $product['id'] ?>" class="text-decoration-none">
                            <img src="<?= $product['image'] ?>" class="card-img-top" alt="Product">
                        </a>
                        <div class="card-body d-flex flex-column">
                            <h5 class="card-title">
                                <a href="product_detail.php?id=<?= $product['id'] ?>" class="text-decoration-none text-dark">
                                    <?= htmlspecialchars($product['name']) ?>
                                </a>
                            </h5>
                            
                            <?php if (!empty($product['category'])): ?>
                                <div class="mb-2">
                                    <a href="catalog.php?category=<?php echo urlencode($product['category']); ?>" class="badge bg-info text-decoration-none">
                                        <?php echo htmlspecialchars($product['category']); ?>
                                    </a>
                                </div>
                            <?php endif; ?>
                            
                            <p class="card-text flex-grow-1">
                                <?php 
                                    $desc = $product['description'] ?? 'No description available';
                                    echo strlen($desc) > 80 ? htmlspecialchars(substr($desc, 0, 80)) . '...' : htmlspecialchars($desc);
                                ?>
                            </p>
                            
                            <div>
                                <?php if ($product['discount'] > 0): ?>
                                    <p>
                                        <span class="strike">$<?= number_format($product['price'], 2) ?></span>
                                        <strong class="text-danger">$<?= number_format($product['price'] - $product['discount'], 2) ?></strong>
                                    </p>
                                <?php else: ?>
                                    <p>$<?= number_format($product['price'], 2) ?></p>
                                <?php endif; ?>
                                <p class="mb-3">Stock: <?= $product['stock'] ?></p>
                                <form action="" method="POST" class="d-grid">
                                    <input type="hidden" name="add_to_cart" value="1">
                                    <input type="hidden" name="quantity" value="1">
                                    <input type="hidden" name="product_id" value="<?= $product['id'] ?>">
                                    <button type="submit" class="btn btn-sm btn-outline-primary">
                                        <i class="fas fa-cart-plus me-1"></i> Add to Cart
                                    </button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>

</div>

<!-- Footer -->
<footer class="bg-dark text-white mt-5 py-4">
    <div class="container">
        <div class="row">
            <div class="col-md-4">
                <h5>EcomPro</h5>
                <p>Your one-stop shop for quality products.</p>
            </div>
            <div class="col-md-4">
                <h5>Quick Links</h5>
                <ul class="list-unstyled">
                    <li><a href="index.php" class="text-white">Home</a></li>
                    <li><a href="catalog.php" class="text-white">Catalog</a></li>
                    <li><a href="about.php" class="text-white">About Us</a></li>
                    <li><a href="contact.php" class="text-white">Contact</a></li>
                    <li><a href="index_optimize.php" class="text-white">Performance Tools</a></li>
                </ul>
            </div>
            <div class="col-md-4">
                <h5>Contact Us</h5>
                <address>
                    <p><i class="fas fa-map-marker-alt me-2"></i> 123 Main St, City</p>
                    <p><i class="fas fa-phone me-2"></i> (123) 456-7890</p>
                    <p><i class="fas fa-envelope me-2"></i> info@ecompro.com</p>
                </address>
            </div>
        </div>
        <hr>
        <div class="text-center">
            <p>&copy; <?php echo date('Y'); ?> EcomPro. All rights reserved.</p>
        </div>
    </div>
</footer>

<!-- Bootstrap Bundle with Popper -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

<script>
    // Auto-hide the toast notification after 3 seconds
    document.addEventListener('DOMContentLoaded', function() {
        setTimeout(function() {
            var toastElement = document.querySelector('.cart-notification .toast');
            if (toastElement) {
                var toast = new bootstrap.Toast(toastElement);
                toast.hide();
            }
        }, 3000);
    });
</script>

</body>
</html>