<?php
require_once 'config.php';

// Handle different request methods
$method = $_SERVER['REQUEST_METHOD'];

switch ($method) {
    case 'GET':
        handleGet();
        break;
    case 'PUT':
        handlePut();
        break;
    default:
        apiResponse('error', 'Method not allowed', null);
}

// GET - Retrieve settings
function handleGet() {
    global $pdo;
    
    // Get specific setting by key
    if (isset($_GET['key'])) {
        $key = $_GET['key'];
        $stmt = $pdo->prepare("SELECT * FROM settings WHERE setting_key = ?");
        $stmt->execute([$key]);
        $setting = $stmt->fetch();
        
        if (!$setting) {
            apiResponse('error', 'Setting not found', null);
        }
        
        apiResponse('success', 'Setting retrieved successfully', $setting);
    }
    
    // Get settings by group
    if (isset($_GET['group'])) {
        $group = $_GET['group'];
        $stmt = $pdo->prepare("SELECT * FROM settings WHERE setting_group = ? ORDER BY id");
        $stmt->execute([$group]);
        $settings = $stmt->fetchAll();
        
        // Convert to associative array with setting_key as key
        $result = [];
        foreach ($settings as $setting) {
            $result[$setting['setting_key']] = $setting;
        }
        
        apiResponse('success', 'Settings retrieved successfully', $result);
    }
    
    // Get all settings grouped by group
    $stmt = $pdo->query("SELECT * FROM settings ORDER BY setting_group, id");
    $settings = $stmt->fetchAll();
    
    // Group settings by their group
    $grouped = [];
    foreach ($settings as $setting) {
        $group = $setting['setting_group'];
        if (!isset($grouped[$group])) {
            $grouped[$group] = [];
        }
        $grouped[$group][$setting['setting_key']] = $setting;
    }
    
    apiResponse('success', 'All settings retrieved successfully', $grouped);
}

// PUT - Update settings
function handlePut() {
    global $pdo;
    
    // Require admin authentication
    requireAdminAuth();
    
    // Get JSON data from request body
    $data = json_decode(file_get_contents('php://input'), true);
    
    if (!is_array($data) || empty($data)) {
        apiResponse('error', 'Invalid settings data', null);
    }
    
    // Begin transaction
    $pdo->beginTransaction();
    
    try {
        $updatedSettings = [];
        
        // Update each setting
        foreach ($data as $key => $value) {
            $stmt = $pdo->prepare("UPDATE settings SET setting_value = ? WHERE setting_key = ?");
            $stmt->execute([$value, $key]);
            
            if ($stmt->rowCount() > 0) {
                $getStmt = $pdo->prepare("SELECT * FROM settings WHERE setting_key = ?");
                $getStmt->execute([$key]);
                $updatedSettings[$key] = $getStmt->fetch();
            }
        }
        
        // Commit transaction
        $pdo->commit();
        
        apiResponse('success', 'Settings updated successfully', $updatedSettings);
    } catch (Exception $e) {
        // Rollback on error
        $pdo->rollBack();
        apiResponse('error', 'Error updating settings: ' . $e->getMessage(), null);
    }
} 