<?php
require_once 'config.php';

// Handle different request methods
$method = $_SERVER['REQUEST_METHOD'];

switch ($method) {
    case 'GET':
        handleGet();
        break;
    case 'POST':
        handlePost();
        break;
    case 'PUT':
        handlePut();
        break;
    case 'DELETE':
        handleDelete();
        break;
    default:
        apiResponse('error', 'Method not allowed', null);
}

// GET - Retrieve cart contents
function handleGet() {
    global $pdo;
    
    // Start session if not already started
    if (session_status() == PHP_SESSION_NONE) {
        session_start();
    }
    
    // Initialize cart if not exists
    if (!isset($_SESSION['cart'])) {
        $_SESSION['cart'] = [];
    }
    
    $cart = $_SESSION['cart'];
    $cartItems = [];
    $totalAmount = 0;
    
    // Get product details for items in cart
    if (!empty($cart)) {
        $productIds = array_keys($cart);
        $placeholders = implode(',', array_fill(0, count($productIds), '?'));
        
        $stmt = $pdo->prepare("SELECT * FROM products WHERE id IN ($placeholders)");
        $stmt->execute($productIds);
        $products = $stmt->fetchAll();
        
        foreach ($products as $product) {
            $quantity = $cart[$product['id']];
            $price = $product['discount'] ? $product['discount'] : $product['price'];
            $itemTotal = $price * $quantity;
            
            $cartItems[] = [
                'id' => $product['id'],
                'name' => $product['name'],
                'price' => $price,
                'image' => $product['image'],
                'quantity' => $quantity,
                'total' => $itemTotal
            ];
            
            $totalAmount += $itemTotal;
        }
    }
    
    $response = [
        'items' => $cartItems,
        'total' => $totalAmount,
        'count' => count($cartItems)
    ];
    
    apiResponse('success', 'Cart retrieved successfully', $response);
}

// POST - Add item to cart
function handlePost() {
    global $pdo;
    
    // Start session if not already started
    if (session_status() == PHP_SESSION_NONE) {
        session_start();
    }
    
    // Initialize cart if not exists
    if (!isset($_SESSION['cart'])) {
        $_SESSION['cart'] = [];
    }
    
    // Get JSON data from request body
    $data = json_decode(file_get_contents('php://input'), true);
    
    // If no JSON data, check for form data
    if (!$data && isset($_POST['product_id'])) {
        $data = $_POST;
    }
    
    // Validate required fields
    if (!isset($data['product_id'])) {
        apiResponse('error', 'Product ID is required', null);
    }
    
    $productId = $data['product_id'];
    $quantity = isset($data['quantity']) ? (int)$data['quantity'] : 1;
    
    // Validate quantity
    if ($quantity <= 0) {
        apiResponse('error', 'Quantity must be greater than zero', null);
    }
    
    // Verify product exists and has enough stock
    $stmt = $pdo->prepare("SELECT * FROM products WHERE id = ?");
    $stmt->execute([$productId]);
    $product = $stmt->fetch();
    
    if (!$product) {
        apiResponse('error', 'Product not found', null);
    }
    
    // Check stock
    if ($product['stock'] < $quantity) {
        apiResponse('error', 'Not enough stock available', null);
    }
    
    // Add to cart or update quantity
    if (isset($_SESSION['cart'][$productId])) {
        $_SESSION['cart'][$productId] += $quantity;
    } else {
        $_SESSION['cart'][$productId] = $quantity;
    }
    
    // Ensure quantity doesn't exceed stock
    if ($_SESSION['cart'][$productId] > $product['stock']) {
        $_SESSION['cart'][$productId] = $product['stock'];
    }
    
    // Get cart count
    $cartCount = count($_SESSION['cart']);
    
    apiResponse('success', 'Product added to cart', [
        'product_id' => $productId,
        'quantity' => $_SESSION['cart'][$productId],
        'cart_count' => $cartCount
    ]);
}

// PUT - Update cart item quantity
function handlePut() {
    global $pdo;
    
    // Start session if not already started
    if (session_status() == PHP_SESSION_NONE) {
        session_start();
    }
    
    // Initialize cart if not exists
    if (!isset($_SESSION['cart'])) {
        $_SESSION['cart'] = [];
    }
    
    // Get product ID from URL parameter
    if (!isset($_GET['id'])) {
        apiResponse('error', 'Product ID is required', null);
    }
    
    $productId = $_GET['id'];
    
    // Check if product is in cart
    if (!isset($_SESSION['cart'][$productId])) {
        apiResponse('error', 'Product not in cart', null);
    }
    
    // Get JSON data from request body
    $data = json_decode(file_get_contents('php://input'), true);
    
    // Validate required fields
    if (!isset($data['quantity'])) {
        apiResponse('error', 'Quantity is required', null);
    }
    
    $quantity = (int)$data['quantity'];
    
    // Validate quantity
    if ($quantity <= 0) {
        // If quantity is 0 or less, remove from cart
        unset($_SESSION['cart'][$productId]);
        apiResponse('success', 'Product removed from cart', [
            'cart_count' => count($_SESSION['cart'])
        ]);
    }
    
    // Verify product exists and has enough stock
    $stmt = $pdo->prepare("SELECT * FROM products WHERE id = ?");
    $stmt->execute([$productId]);
    $product = $stmt->fetch();
    
    if (!$product) {
        apiResponse('error', 'Product not found', null);
    }
    
    // Check stock
    if ($product['stock'] < $quantity) {
        $quantity = $product['stock'];
    }
    
    // Update quantity
    $_SESSION['cart'][$productId] = $quantity;
    
    apiResponse('success', 'Cart updated successfully', [
        'product_id' => $productId,
        'quantity' => $quantity,
        'cart_count' => count($_SESSION['cart'])
    ]);
}

// DELETE - Remove item from cart
function handleDelete() {
    // Start session if not already started
    if (session_status() == PHP_SESSION_NONE) {
        session_start();
    }
    
    // Initialize cart if not exists
    if (!isset($_SESSION['cart'])) {
        $_SESSION['cart'] = [];
    }
    
    // Get product ID from URL parameter
    if (isset($_GET['id'])) {
        $productId = $_GET['id'];
        
        // Remove specific product from cart
        if (isset($_SESSION['cart'][$productId])) {
            unset($_SESSION['cart'][$productId]);
            apiResponse('success', 'Product removed from cart', [
                'cart_count' => count($_SESSION['cart'])
            ]);
        } else {
            apiResponse('error', 'Product not in cart', null);
        }
    } elseif (isset($_GET['clear']) && $_GET['clear'] === 'true') {
        // Clear entire cart
        $_SESSION['cart'] = [];
        apiResponse('success', 'Cart cleared successfully', [
            'cart_count' => 0
        ]);
    } else {
        apiResponse('error', 'Product ID or clear parameter is required', null);
    }
} 