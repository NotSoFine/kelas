<?php
require_once 'config.php';

// Handle different request methods
$method = $_SERVER['REQUEST_METHOD'];

switch ($method) {
    case 'GET':
        handleGet();
        break;
    case 'POST':
        handlePost();
        break;
    case 'PUT':
        handlePut();
        break;
    default:
        apiResponse('error', 'Method not allowed', null);
}

// GET - Retrieve orders
function handleGet() {
    global $pdo;
    
    // Get specific order by ID
    if (isset($_GET['id'])) {
        $id = $_GET['id'];
        
        // Get order data
        $stmt = $pdo->prepare("SELECT * FROM orders WHERE id = ?");
        $stmt->execute([$id]);
        $order = $stmt->fetch();
        
        if (!$order) {
            apiResponse('error', 'Order not found', null);
        }
        
        // Check permissions - users can only view their own orders, admins can view any
        $userId = requireAuth();
        if ($order['user_id'] != $userId) {
            requireAdminAuth(); // Will exit if not admin
        }
        
        // Get order items
        $itemsStmt = $pdo->prepare("SELECT oi.*, p.name as product_name, p.image as product_image 
                                   FROM order_items oi 
                                   LEFT JOIN products p ON oi.product_id = p.id 
                                   WHERE oi.order_id = ?");
        $itemsStmt->execute([$id]);
        $orderItems = $itemsStmt->fetchAll();
        
        $result = [
            'order' => $order,
            'items' => $orderItems
        ];
        
        apiResponse('success', 'Order retrieved successfully', $result);
    }
    
    // Get orders for a specific user
    if (isset($_GET['user_id'])) {
        $requestedUserId = $_GET['user_id'];
        
        // Check permissions - users can only view their own orders, admins can view any
        $userId = requireAuth();
        if ($requestedUserId != $userId) {
            requireAdminAuth(); // Will exit if not admin
        }
        
        // Pagination
        $page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
        $limit = isset($_GET['limit']) ? (int)$_GET['limit'] : 10;
        $offset = ($page - 1) * $limit;
        
        // Get total count
        $countStmt = $pdo->prepare("SELECT COUNT(*) FROM orders WHERE user_id = ?");
        $countStmt->execute([$requestedUserId]);
        $totalOrders = $countStmt->fetchColumn();
        
        // Get orders with pagination
        $stmt = $pdo->prepare("SELECT * FROM orders WHERE user_id = ? ORDER BY created_at DESC LIMIT ? OFFSET ?");
        $stmt->bindValue(1, $requestedUserId);
        $stmt->bindValue(2, $limit, PDO::PARAM_INT);
        $stmt->bindValue(3, $offset, PDO::PARAM_INT);
        $stmt->execute();
        
        $orders = $stmt->fetchAll();
        
        $response = [
            'orders' => $orders,
            'pagination' => [
                'total' => $totalOrders,
                'page' => $page,
                'limit' => $limit,
                'total_pages' => ceil($totalOrders / $limit)
            ]
        ];
        
        apiResponse('success', 'Orders retrieved successfully', $response);
    }
    
    // Admin-only: Get all orders
    requireAdminAuth();
    
    // Pagination
    $page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
    $limit = isset($_GET['limit']) ? (int)$_GET['limit'] : 10;
    $offset = ($page - 1) * $limit;
    
    // Status filter
    $statusFilter = '';
    $params = [];
    
    if (isset($_GET['status']) && !empty($_GET['status'])) {
        $statusFilter = " WHERE status = ?";
        $params[] = $_GET['status'];
    }
    
    // Get total count
    $countQuery = "SELECT COUNT(*) FROM orders" . $statusFilter;
    $countStmt = $pdo->prepare($countQuery);
    $countStmt->execute($params);
    $totalOrders = $countStmt->fetchColumn();
    
    // Get orders with pagination
    $query = "SELECT o.*, u.username, u.email 
              FROM orders o 
              LEFT JOIN users u ON o.user_id = u.id" 
              . $statusFilter . 
              " ORDER BY o.created_at DESC LIMIT ? OFFSET ?";
    
    $stmt = $pdo->prepare($query);
    
    // Bind params
    $paramCount = 1;
    foreach ($params as $param) {
        $stmt->bindValue($paramCount++, $param);
    }
    
    $stmt->bindValue($paramCount++, $limit, PDO::PARAM_INT);
    $stmt->bindValue($paramCount, $offset, PDO::PARAM_INT);
    $stmt->execute();
    
    $orders = $stmt->fetchAll();
    
    $response = [
        'orders' => $orders,
        'pagination' => [
            'total' => $totalOrders,
            'page' => $page,
            'limit' => $limit,
            'total_pages' => ceil($totalOrders / $limit)
        ]
    ];
    
    apiResponse('success', 'Orders retrieved successfully', $response);
}

// POST - Create a new order
function handlePost() {
    global $pdo;
    
    // User must be authenticated
    $userId = requireAuth();
    
    // Get JSON data from request body
    $data = json_decode(file_get_contents('php://input'), true);
    
    // Validate required fields
    if (!isset($data['items']) || empty($data['items']) || !is_array($data['items'])) {
        apiResponse('error', 'Order items are required', null);
    }
    
    // Validate each item has product_id and quantity
    foreach ($data['items'] as $item) {
        if (!isset($item['product_id']) || !isset($item['quantity'])) {
            apiResponse('error', 'Each item must have product_id and quantity', null);
        }
    }
    
    // Start transaction
    $pdo->beginTransaction();
    
    try {
        // Calculate order total and check stock
        $orderTotal = 0;
        $orderItems = [];
        
        foreach ($data['items'] as $item) {
            $productId = $item['product_id'];
            $quantity = $item['quantity'];
            
            // Get product details
            $stmt = $pdo->prepare("SELECT * FROM products WHERE id = ?");
            $stmt->execute([$productId]);
            $product = $stmt->fetch();
            
            if (!$product) {
                throw new Exception("Product not found: ID $productId");
            }
            
            // Check stock
            if ($product['stock'] < $quantity) {
                throw new Exception("Not enough stock for product: {$product['name']}");
            }
            
            // Calculate item price (use discount if available)
            $price = $product['discount'] ? $product['discount'] : $product['price'];
            $itemTotal = $price * $quantity;
            
            // Add to order total
            $orderTotal += $itemTotal;
            
            // Add to order items
            $orderItems[] = [
                'product_id' => $productId,
                'quantity' => $quantity,
                'price' => $price,
                'total' => $itemTotal,
                'product_name' => $product['name']
            ];
            
            // Update stock
            $newStock = $product['stock'] - $quantity;
            $updateStmt = $pdo->prepare("UPDATE products SET stock = ? WHERE id = ?");
            $updateStmt->execute([$newStock, $productId]);
        }
        
        // Create order
        $shipping = isset($data['shipping_address']) ? $data['shipping_address'] : '';
        $status = 'pending';
        
        $stmt = $pdo->prepare("INSERT INTO orders (user_id, total, status, shipping_address, created_at) 
                               VALUES (?, ?, ?, ?, NOW())");
        $stmt->execute([$userId, $orderTotal, $status, $shipping]);
        
        $orderId = $pdo->lastInsertId();
        
        // Insert order items
        foreach ($orderItems as $item) {
            $stmt = $pdo->prepare("INSERT INTO order_items (order_id, product_id, quantity, price, total) 
                                   VALUES (?, ?, ?, ?, ?)");
            $stmt->execute([
                $orderId, 
                $item['product_id'], 
                $item['quantity'],
                $item['price'],
                $item['total']
            ]);
        }
        
        // Commit transaction
        $pdo->commit();
        
        // Get the created order
        $stmt = $pdo->prepare("SELECT * FROM orders WHERE id = ?");
        $stmt->execute([$orderId]);
        $order = $stmt->fetch();
        
        // Get order items
        $itemsStmt = $pdo->prepare("SELECT oi.*, p.name as product_name, p.image as product_image 
                                    FROM order_items oi 
                                    LEFT JOIN products p ON oi.product_id = p.id 
                                    WHERE oi.order_id = ?");
        $itemsStmt->execute([$orderId]);
        $orderItems = $itemsStmt->fetchAll();
        
        $result = [
            'order' => $order,
            'items' => $orderItems
        ];
        
        apiResponse('success', 'Order created successfully', $result);
    } catch (Exception $e) {
        // Rollback on error
        $pdo->rollBack();
        apiResponse('error', $e->getMessage(), null);
    }
}

// PUT - Update order status
function handlePut() {
    global $pdo;
    
    // Admin authorization required
    requireAdminAuth();
    
    // Get order ID from URL parameter
    if (!isset($_GET['id'])) {
        apiResponse('error', 'Order ID is required', null);
    }
    
    $id = $_GET['id'];
    
    // Get JSON data from request body
    $data = json_decode(file_get_contents('php://input'), true);
    
    // Validate required fields
    if (!isset($data['status'])) {
        apiResponse('error', 'Status is required', null);
    }
    
    $status = $data['status'];
    
    // Validate status
    $validStatuses = ['pending', 'processing', 'shipped', 'delivered', 'cancelled'];
    if (!in_array($status, $validStatuses)) {
        apiResponse('error', 'Invalid status. Must be one of: ' . implode(', ', $validStatuses), null);
    }
    
    // Verify order exists
    $stmt = $pdo->prepare("SELECT * FROM orders WHERE id = ?");
    $stmt->execute([$id]);
    $order = $stmt->fetch();
    
    if (!$order) {
        apiResponse('error', 'Order not found', null);
    }
    
    try {
        // Update order status
        $stmt = $pdo->prepare("UPDATE orders SET status = ? WHERE id = ?");
        $stmt->execute([$status, $id]);
        
        // Get the updated order
        $stmt = $pdo->prepare("SELECT * FROM orders WHERE id = ?");
        $stmt->execute([$id]);
        $updatedOrder = $stmt->fetch();
        
        apiResponse('success', 'Order status updated successfully', $updatedOrder);
    } catch (Exception $e) {
        apiResponse('error', 'Error updating order: ' . $e->getMessage(), null);
    }
} 