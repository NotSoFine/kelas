<?php
require_once 'config.php';

// Start session if not already started
if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

// Prepare response
$response = [
    'status' => 'success',
    'message' => 'API status check',
    'data' => [
        'api_version' => '1.0',
        'time' => date('Y-m-d H:i:s'),
        'session' => [
            'active' => session_status() === PHP_SESSION_ACTIVE,
            'id' => session_id(),
            'logged_in' => isset($_SESSION['user_id']) || isset($_SESSION['admin_id'])
        ]
    ]
];

// Add complete session info for debugging
$response['data']['session_variables'] = [];
foreach ($_SESSION as $key => $value) {
    if (is_array($value)) {
        $response['data']['session_variables'][$key] = json_encode($value);
    } else {
        $response['data']['session_variables'][$key] = $value;
    }
}

// Add user info if logged in with regular account
if (isset($_SESSION['user_id'])) {
    $response['data']['user'] = [
        'id' => $_SESSION['user_id'],
        'username' => $_SESSION['username'],
        'role' => $_SESSION['role'],
        'login_type' => 'regular'
    ];
}

// Add user info if logged in with admin account
if (isset($_SESSION['admin_id'])) {
    $response['data']['user'] = [
        'id' => $_SESSION['admin_id'],
        'username' => $_SESSION['admin_username'],
        'role' => $_SESSION['role'],
        'login_type' => 'admin'
    ];
}

// Return response
echo json_encode($response);
exit; 