<?php
require_once 'config.php';

// Handle different request methods
$method = $_SERVER['REQUEST_METHOD'];

switch ($method) {
    case 'GET':
        handleGet();
        break;
    case 'POST':
        handlePost();
        break;
    case 'PUT':
        handlePut();
        break;
    case 'DELETE':
        handleDelete();
        break;
    default:
        apiResponse('error', 'Method not allowed', null);
}

// GET - Retrieve user(s)
function handleGet() {
    global $pdo;
    
    // Get current user profile
    if (isset($_GET['profile'])) {
        $userId = requireAuth();
        
        $stmt = $pdo->prepare("SELECT id, username, email, first_name, last_name, role, created_at FROM users WHERE id = ?");
        $stmt->execute([$userId]);
        $user = $stmt->fetch();
        
        if (!$user) {
            apiResponse('error', 'User not found', null);
        }
        
        apiResponse('success', 'User profile retrieved', $user);
    }
    
    // Admin only access to list all users
    if (!isset($_GET['id'])) {
        requireAdminAuth();
        
        // Pagination
        $page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
        $limit = isset($_GET['limit']) ? (int)$_GET['limit'] : 10;
        $offset = ($page - 1) * $limit;
        
        // Get total count for pagination
        $countStmt = $pdo->query("SELECT COUNT(*) FROM users");
        $totalUsers = $countStmt->fetchColumn();
        
        // Get users with pagination
        $stmt = $pdo->prepare("SELECT id, username, email, first_name, last_name, role, created_at FROM users ORDER BY id DESC LIMIT ? OFFSET ?");
        $stmt->bindValue(1, $limit, PDO::PARAM_INT);
        $stmt->bindValue(2, $offset, PDO::PARAM_INT);
        $stmt->execute();
        
        $users = $stmt->fetchAll();
        
        $response = [
            'users' => $users,
            'pagination' => [
                'total' => $totalUsers,
                'page' => $page,
                'limit' => $limit,
                'total_pages' => ceil($totalUsers / $limit)
            ]
        ];
        
        apiResponse('success', 'Users retrieved successfully', $response);
    }
    
    // Get specific user (admin only or own profile)
    $id = $_GET['id'];
    $userId = requireAuth();
    
    // If not admin and not requesting own profile, reject
    if ($id != $userId) {
        requireAdminAuth();
    }
    
    $stmt = $pdo->prepare("SELECT id, username, email, first_name, last_name, role, created_at FROM users WHERE id = ?");
    $stmt->execute([$id]);
    $user = $stmt->fetch();
    
    if (!$user) {
        apiResponse('error', 'User not found', null);
    }
    
    apiResponse('success', 'User retrieved successfully', $user);
}

// POST - Create new user
function handlePost() {
    global $pdo;
    
    // Registration endpoint
    if (isset($_GET['register'])) {
        // Get JSON data from request body
        $data = json_decode(file_get_contents('php://input'), true);
        
        // If no JSON data, check for form data
        if (!$data && isset($_POST['username'])) {
            $data = $_POST;
        }
        
        // Validate required fields
        if (!isset($data['username']) || !isset($data['email']) || !isset($data['password'])) {
            apiResponse('error', 'Missing required fields', null);
        }
        
        $username = $data['username'];
        $email = $data['email'];
        $password = password_hash($data['password'], PASSWORD_DEFAULT);
        $firstName = isset($data['first_name']) ? $data['first_name'] : '';
        $lastName = isset($data['last_name']) ? $data['last_name'] : '';
        $role = 'customer'; // Default role for new users
        
        // Check if username or email already exists
        $stmt = $pdo->prepare("SELECT * FROM users WHERE username = ? OR email = ?");
        $stmt->execute([$username, $email]);
        if ($stmt->rowCount() > 0) {
            apiResponse('error', 'Username or email already exists', null);
        }
        
        try {
            $stmt = $pdo->prepare("INSERT INTO users (username, email, password, first_name, last_name, role) VALUES (?, ?, ?, ?, ?, ?)");
            $stmt->execute([$username, $email, $password, $firstName, $lastName, $role]);
            
            $userId = $pdo->lastInsertId();
            
            apiResponse('success', 'User registered successfully', ['id' => $userId]);
        } catch (PDOException $e) {
            apiResponse('error', 'Database error: ' . $e->getMessage(), null);
        }
    }
    
    // Login endpoint
    if (isset($_GET['login'])) {
        // Get JSON data from request body
        $data = json_decode(file_get_contents('php://input'), true);
        
        // If no JSON data, check for form data
        if (!$data && isset($_POST['username'])) {
            $data = $_POST;
        }
        
        // Validate required fields
        if ((!isset($data['username']) && !isset($data['email'])) || !isset($data['password'])) {
            apiResponse('error', 'Missing required fields', null);
        }
        
        // Allow login with username or email
        $identifier = isset($data['username']) ? $data['username'] : $data['email'];
        $password = $data['password'];
        
        // Find user
        $stmt = $pdo->prepare("SELECT * FROM users WHERE username = ? OR email = ?");
        $stmt->execute([$identifier, $identifier]);
        $user = $stmt->fetch();
        
        if (!$user || !password_verify($password, $user['password'])) {
            apiResponse('error', 'Invalid credentials', null);
        }
        
        // Ensure any existing session is cleared first
        if (session_status() === PHP_SESSION_ACTIVE) {
            session_write_close();
        }
        
        // Start session with stricter cookie settings
        session_start([
            'cookie_lifetime' => 86400, // 1 day
            'cookie_httponly' => true,
            'cookie_path' => '/',       // Important: Make cookie available across the entire site
            'cookie_samesite' => 'Lax'  // Allow same-site cookies
        ]);
        
        // Regenerate session ID for security
        session_regenerate_id(true);
        
        // Set user data
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['username'] = $user['username'];
        $_SESSION['role'] = $user['role'];
        $_SESSION['login_time'] = time();
        
        // Log the session information
        error_log("User logged in - Session ID: " . session_id());
        error_log("Session data: " . json_encode([
            'user_id' => $user['id'],
            'username' => $user['username'],
            'role' => $user['role']
        ]));
        
        // Return user data without password
        unset($user['password']);
        
        // Include session ID in response for debugging
        $user['session_id'] = session_id();
        
        apiResponse('success', 'Login successful', $user);
    }
    
    // Admin-only user creation
    requireAdminAuth();
    
    // Get JSON data from request body
    $data = json_decode(file_get_contents('php://input'), true);
    
    // If no JSON data, check for form data
    if (!$data && isset($_POST['username'])) {
        $data = $_POST;
    }
    
    // Validate required fields
    if (!isset($data['username']) || !isset($data['email']) || !isset($data['password']) || !isset($data['role'])) {
        apiResponse('error', 'Missing required fields', null);
    }
    
    $username = $data['username'];
    $email = $data['email'];
    $password = password_hash($data['password'], PASSWORD_DEFAULT);
    $firstName = isset($data['first_name']) ? $data['first_name'] : '';
    $lastName = isset($data['last_name']) ? $data['last_name'] : '';
    $role = $data['role'];
    
    // Check if username or email already exists
    $stmt = $pdo->prepare("SELECT * FROM users WHERE username = ? OR email = ?");
    $stmt->execute([$username, $email]);
    if ($stmt->rowCount() > 0) {
        apiResponse('error', 'Username or email already exists', null);
    }
    
    try {
        $stmt = $pdo->prepare("INSERT INTO users (username, email, password, first_name, last_name, role) VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->execute([$username, $email, $password, $firstName, $lastName, $role]);
        
        $userId = $pdo->lastInsertId();
        
        // Get the newly created user
        $stmt = $pdo->prepare("SELECT id, username, email, first_name, last_name, role, created_at FROM users WHERE id = ?");
        $stmt->execute([$userId]);
        $user = $stmt->fetch();
        
        apiResponse('success', 'User created successfully', $user);
    } catch (PDOException $e) {
        apiResponse('error', 'Database error: ' . $e->getMessage(), null);
    }
}

// PUT - Update existing user
function handlePut() {
    global $pdo;
    
    // Get user ID from URL parameter
    if (!isset($_GET['id'])) {
        apiResponse('error', 'User ID is required', null);
    }
    
    $id = $_GET['id'];
    $userId = requireAuth();
    
    // If not admin and not updating own profile, reject
    if ($id != $userId) {
        requireAdminAuth();
    }
    
    // Get JSON data from request body
    $data = json_decode(file_get_contents('php://input'), true);
    
    // Verify user exists
    $stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
    $stmt->execute([$id]);
    $user = $stmt->fetch();
    
    if (!$user) {
        apiResponse('error', 'User not found', null);
    }
    
    // Update only provided fields
    $fields = [];
    $values = [];
    
    if (isset($data['username'])) {
        // Check if username already exists for another user
        $stmt = $pdo->prepare("SELECT * FROM users WHERE username = ? AND id != ?");
        $stmt->execute([$data['username'], $id]);
        if ($stmt->rowCount() > 0) {
            apiResponse('error', 'Username already exists', null);
        }
        
        $fields[] = "username = ?";
        $values[] = $data['username'];
    }
    
    if (isset($data['email'])) {
        // Check if email already exists for another user
        $stmt = $pdo->prepare("SELECT * FROM users WHERE email = ? AND id != ?");
        $stmt->execute([$data['email'], $id]);
        if ($stmt->rowCount() > 0) {
            apiResponse('error', 'Email already exists', null);
        }
        
        $fields[] = "email = ?";
        $values[] = $data['email'];
    }
    
    if (isset($data['password'])) {
        $fields[] = "password = ?";
        $values[] = password_hash($data['password'], PASSWORD_DEFAULT);
    }
    
    if (isset($data['first_name'])) {
        $fields[] = "first_name = ?";
        $values[] = $data['first_name'];
    }
    
    if (isset($data['last_name'])) {
        $fields[] = "last_name = ?";
        $values[] = $data['last_name'];
    }
    
    // Only admins can change roles
    if (isset($data['role']) && $_SESSION['role'] === 'admin') {
        $fields[] = "role = ?";
        $values[] = $data['role'];
    }
    
    if (empty($fields)) {
        apiResponse('error', 'No fields to update', null);
    }
    
    // Add user ID to values array
    $values[] = $id;
    
    try {
        $sql = "UPDATE users SET " . implode(", ", $fields) . " WHERE id = ?";
        $stmt = $pdo->prepare($sql);
        $stmt->execute($values);
        
        // Get the updated user
        $stmt = $pdo->prepare("SELECT id, username, email, first_name, last_name, role, created_at FROM users WHERE id = ?");
        $stmt->execute([$id]);
        $updatedUser = $stmt->fetch();
        
        apiResponse('success', 'User updated successfully', $updatedUser);
    } catch (PDOException $e) {
        apiResponse('error', 'Database error: ' . $e->getMessage(), null);
    }
}

// DELETE - Remove a user
function handleDelete() {
    global $pdo;
    
    // Admin only can delete users
    requireAdminAuth();
    
    // Get user ID from URL parameter
    if (!isset($_GET['id'])) {
        apiResponse('error', 'User ID is required', null);
    }
    
    $id = $_GET['id'];
    
    // Prevent deleting own account
    if ($id == $_SESSION['user_id']) {
        apiResponse('error', 'Cannot delete your own account', null);
    }
    
    // Verify user exists
    $stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
    $stmt->execute([$id]);
    $user = $stmt->fetch();
    
    if (!$user) {
        apiResponse('error', 'User not found', null);
    }
    
    try {
        $stmt = $pdo->prepare("DELETE FROM users WHERE id = ?");
        $stmt->execute([$id]);
        
        apiResponse('success', 'User deleted successfully', ['id' => $id]);
    } catch (PDOException $e) {
        apiResponse('error', 'Database error: ' . $e->getMessage(), null);
    }
} 