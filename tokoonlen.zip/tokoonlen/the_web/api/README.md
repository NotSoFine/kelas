# eCompro API Documentation

This directory contains the eCompro API which provides a structured way to interact with the eCompro database. The API follows RESTful principles and uses JSON for data exchange.

## API Structure

- `config.php` - Core API configuration and utility functions
- `products.php` - Product management endpoints
- `users.php` - User management endpoints
- `cart.php` - Cart management endpoints
- More endpoints will be added as needed

## Authentication

The API uses PHP sessions for authentication. Most endpoints require authentication, and some require admin privileges.

## General Response Format

All API responses follow this format:

```json
{
  "status": "success|error",
  "message": "A descriptive message",
  "data": { ... } // Optional data payload
}
```

## Available Endpoints

### Products API (`products.php`)

#### GET /api/products.php
Get a list of products with pagination.

**Query Parameters:**
- `page` - Page number (default: 1)
- `limit` - Results per page (default: 10)

**Response:**
```json
{
  "status": "success",
  "message": "Products retrieved successfully",
  "data": {
    "products": [ ... ],
    "pagination": {
      "total": 100,
      "page": 1,
      "limit": 10,
      "total_pages": 10
    }
  }
}
```

#### GET /api/products.php?id=X
Get a specific product by ID.

**Response:**
```json
{
  "status": "success",
  "message": "Product retrieved successfully",
  "data": { ... }
}
```

#### GET /api/products.php?search=query
Search for products.

**Response:**
```json
{
  "status": "success",
  "message": "Search results retrieved",
  "data": [ ... ]
}
```

#### POST /api/products.php
Create a new product (requires admin/operator role).

**Request Body:**
```json
{
  "name": "Product Name",
  "price": 19.99,
  "stock": 100,
  "discount": 15.99,
  "image": "path/to/image.jpg"
}
```

**Response:**
```json
{
  "status": "success",
  "message": "Product created successfully",
  "data": { ... }
}
```

#### PUT /api/products.php?id=X
Update a product (requires admin/operator role).

**Request Body:**
```json
{
  "name": "Updated Name",
  "price": 24.99
}
```

**Response:**
```json
{
  "status": "success",
  "message": "Product updated successfully",
  "data": { ... }
}
```

#### DELETE /api/products.php?id=X
Delete a product (requires admin/operator role).

**Response:**
```json
{
  "status": "success",
  "message": "Product deleted successfully",
  "data": { "id": X }
}
```

### Users API (`users.php`)

#### GET /api/users.php?profile=true
Get the current user's profile (requires authentication).

**Response:**
```json
{
  "status": "success",
  "message": "User profile retrieved",
  "data": { ... }
}
```

#### GET /api/users.php
Get a list of all users with pagination (requires admin role).

**Query Parameters:**
- `page` - Page number (default: 1)
- `limit` - Results per page (default: 10)

**Response:**
```json
{
  "status": "success",
  "message": "Users retrieved successfully",
  "data": {
    "users": [ ... ],
    "pagination": { ... }
  }
}
```

#### GET /api/users.php?id=X
Get a specific user (requires admin role or be the user).

**Response:**
```json
{
  "status": "success",
  "message": "User retrieved successfully",
  "data": { ... }
}
```

#### POST /api/users.php?register=true
Register a new user.

**Request Body:**
```json
{
  "username": "newuser",
  "email": "user@example.com",
  "password": "securepassword",
  "first_name": "John",
  "last_name": "Doe"
}
```

**Response:**
```json
{
  "status": "success",
  "message": "User registered successfully",
  "data": { "id": X }
}
```

#### POST /api/users.php?login=true
Login a user.

**Request Body:**
```json
{
  "username": "username_or_email",
  "password": "password"
}
```

**Response:**
```json
{
  "status": "success",
  "message": "Login successful",
  "data": { ... }
}
```

#### PUT /api/users.php?id=X
Update a user (requires admin role or be the user).

**Request Body:**
```json
{
  "email": "newemail@example.com",
  "first_name": "Updated",
  "password": "newpassword"
}
```

**Response:**
```json
{
  "status": "success",
  "message": "User updated successfully",
  "data": { ... }
}
```

#### DELETE /api/users.php?id=X
Delete a user (requires admin role, cannot delete self).

**Response:**
```json
{
  "status": "success",
  "message": "User deleted successfully",
  "data": { "id": X }
}
```

### Cart API (`cart.php`)

#### GET /api/cart.php
Get the current user's cart contents.

**Response:**
```json
{
  "status": "success",
  "message": "Cart retrieved successfully",
  "data": {
    "items": [
      {
        "id": 1,
        "name": "Product Name",
        "price": 19.99,
        "image": "path/to/image.jpg",
        "quantity": 2,
        "total": 39.98
      },
      // ...
    ],
    "total": 39.98,
    "count": 1
  }
}
```

#### POST /api/cart.php
Add a product to the cart.

**Request Body:**
```json
{
  "product_id": 1,
  "quantity": 2
}
```

**Response:**
```json
{
  "status": "success",
  "message": "Product added to cart",
  "data": {
    "product_id": 1,
    "quantity": 2,
    "cart_count": 1
  }
}
```

#### PUT /api/cart.php?id=X
Update the quantity of a product in the cart.

**Request Body:**
```json
{
  "quantity": 3
}
```

**Response:**
```json
{
  "status": "success",
  "message": "Cart updated successfully",
  "data": {
    "product_id": 1,
    "quantity": 3,
    "cart_count": 1
  }
}
```

#### DELETE /api/cart.php?id=X
Remove a product from the cart.

**Response:**
```json
{
  "status": "success",
  "message": "Product removed from cart",
  "data": {
    "cart_count": 0
  }
}
```

#### DELETE /api/cart.php?clear=true
Clear the entire cart.

**Response:**
```json
{
  "status": "success",
  "message": "Cart cleared successfully",
  "data": {
    "cart_count": 0
  }
}
```

## Using the API Client

For PHP code, use the `ApiClient` class from `includes/api_client.php`:

```php
require_once 'includes/api_client.php';

$api = new ApiClient();

// Get products
$response = $api->getProducts();

// Create a product
$product = [
  'name' => 'New Product',
  'price' => 19.99,
  'stock' => 100
];
$response = $api->addProduct($product);

// Update user profile
$userId = $_SESSION['user_id'];
$profileData = [
  'first_name' => 'John',
  'last_name' => 'Doe'
];
$response = $api->updateProfile($userId, $profileData);
```

## For JavaScript/Frontend

You can also call the API directly from JavaScript:

```javascript
// Get products
fetch('/ecompro/the_web/api/products.php')
  .then(response => response.json())
  .then(data => {
    console.log(data);
  });

// Create a product
fetch('/ecompro/the_web/api/products.php', {
  method: 'POST',
  headers: {
    'Content-Type': 'application/json'
  },
  body: JSON.stringify({
    name: 'New Product',
    price: 19.99,
    stock: 100
  }),
  credentials: 'same-origin'
})
  .then(response => response.json())
  .then(data => {
    console.log(data);
  });
``` 