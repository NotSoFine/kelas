<?php
require_once 'config.php';

// Handle different request methods
$method = $_SERVER['REQUEST_METHOD'];

switch ($method) {
    case 'GET':
        handleGet();
        break;
    case 'POST':
        handlePost();
        break;
    case 'PUT':
        handlePut();
        break;
    case 'DELETE':
        handleDelete();
        break;
    default:
        apiResponse('error', 'Method not allowed', null);
}

// GET - Retrieve products
function handleGet() {
    global $pdo;
    
    // Log request information
    error_log("Products API GET request received");
    
    // Check if ID is provided (get single product)
    if (isset($_GET['id'])) {
        $id = $_GET['id'];
        error_log("Retrieving product with ID: $id");
        
        $stmt = $pdo->prepare("SELECT * FROM products WHERE id = ?");
        $stmt->execute([$id]);
        $product = $stmt->fetch();
        
        if (!$product) {
            error_log("Product not found with ID: $id");
            apiResponse('error', 'Product not found', null);
        }
        
        apiResponse('success', 'Product retrieved successfully', $product);
    }
    
    // Search functionality
    if (isset($_GET['search']) && !empty($_GET['search'])) {
        $search = '%' . $_GET['search'] . '%';
        error_log("Searching for products with term: " . $_GET['search']);
        
        $stmt = $pdo->prepare("SELECT * FROM products WHERE name LIKE ? OR category LIKE ? OR description LIKE ? ORDER BY id DESC");
        $stmt->execute([$search, $search, $search]);
        $products = $stmt->fetchAll();
        
        error_log("Found " . count($products) . " products matching search term");
        apiResponse('success', 'Search results retrieved', $products);
    }
    
    // Pagination
    $page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
    $limit = isset($_GET['limit']) ? (int)$_GET['limit'] : 10;
    $offset = ($page - 1) * $limit;
    
    error_log("Retrieving products page $page with limit $limit");
    
    try {
        // Get total count for pagination
        $countStmt = $pdo->query("SELECT COUNT(*) FROM products");
        $totalProducts = $countStmt->fetchColumn();
        
        error_log("Total products found: $totalProducts");
        
        // Debug database connection
        if ($totalProducts === false) {
            error_log("Error retrieving product count");
            throw new Exception("Failed to retrieve product count");
        }
        
        // Get products with pagination
        $stmt = $pdo->prepare("SELECT * FROM products ORDER BY id DESC LIMIT ? OFFSET ?");
        $stmt->bindValue(1, $limit, PDO::PARAM_INT);
        $stmt->bindValue(2, $offset, PDO::PARAM_INT);
        $stmt->execute();
        
        $products = $stmt->fetchAll();
        
        if ($stmt->errorCode() !== '00000') {
            $errorInfo = $stmt->errorInfo();
            error_log("SQL Error: " . implode(", ", $errorInfo));
            throw new Exception("Database error: " . $errorInfo[2]);
        }
        
        error_log("Retrieved " . count($products) . " products for current page");
        
        $response = [
            'products' => $products,
            'pagination' => [
                'total' => $totalProducts,
                'page' => $page,
                'limit' => $limit,
                'total_pages' => ceil($totalProducts / $limit)
            ]
        ];
        
        apiResponse('success', 'Products retrieved successfully', $response);
    } catch (Exception $e) {
        error_log("Error in products API: " . $e->getMessage());
        apiResponse('error', 'Database error: ' . $e->getMessage(), null);
    }
}

// POST - Create new product
function handlePost() {
    global $pdo;
    
    // Check admin/operator authorization
    requireAdminAuth();
    
    // Get JSON data from request body
    $data = json_decode(file_get_contents('php://input'), true);
    
    // If no JSON data, check for form data
    if (!$data && isset($_POST['name'])) {
        $data = $_POST;
    }
    
    // Validate required fields
    if (!isset($data['name']) || !isset($data['price']) || !isset($data['stock'])) {
        apiResponse('error', 'Missing required fields', null);
    }
    
    $name = $data['name'];
    $price = $data['price'];
    $stock = $data['stock'];
    $discount = isset($data['discount']) ? $data['discount'] : null;
    $description = isset($data['description']) ? $data['description'] : null;
    $category = isset($data['category']) ? $data['category'] : null;
    $imagePath = isset($data['image']) ? $data['image'] : '';
    
    // Handle image upload if provided
    if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
        $targetDir = "../uploads/";
        if (!is_dir($targetDir)) {
            mkdir($targetDir, 0755, true);
        }
        $imageName = basename($_FILES['image']['name']);
        $targetFile = $targetDir . uniqid() . '_' . $imageName;
        move_uploaded_file($_FILES['image']['tmp_name'], $targetFile);
        $imagePath = str_replace("../", "", $targetFile); // Store relative path
    }
    
    try {
        $stmt = $pdo->prepare("INSERT INTO products (name, description, price, stock, discount, category, image) VALUES (?, ?, ?, ?, ?, ?, ?)");
        $stmt->execute([$name, $description, $price, $stock, $discount, $category, $imagePath]);
        
        $productId = $pdo->lastInsertId();
        
        // Get the newly created product
        $stmt = $pdo->prepare("SELECT * FROM products WHERE id = ?");
        $stmt->execute([$productId]);
        $product = $stmt->fetch();
        
        apiResponse('success', 'Product created successfully', $product);
    } catch (PDOException $e) {
        apiResponse('error', 'Database error: ' . $e->getMessage(), null);
    }
}

// PUT - Update existing product
function handlePut() {
    global $pdo;
    
    // Check admin/operator authorization
    requireAdminAuth();
    
    // Get product ID from URL parameter
    if (!isset($_GET['id'])) {
        apiResponse('error', 'Product ID is required', null);
    }
    
    $id = $_GET['id'];
    
    // Get JSON data from request body
    $data = json_decode(file_get_contents('php://input'), true);
    
    // Verify product exists
    $stmt = $pdo->prepare("SELECT * FROM products WHERE id = ?");
    $stmt->execute([$id]);
    $product = $stmt->fetch();
    
    if (!$product) {
        apiResponse('error', 'Product not found', null);
    }
    
    // Update only provided fields
    $fields = [];
    $values = [];
    
    if (isset($data['name'])) {
        $fields[] = "name = ?";
        $values[] = $data['name'];
    }
    
    if (isset($data['description'])) {
        $fields[] = "description = ?";
        $values[] = $data['description'];
    }
    
    if (isset($data['price'])) {
        $fields[] = "price = ?";
        $values[] = $data['price'];
    }
    
    if (isset($data['stock'])) {
        $fields[] = "stock = ?";
        $values[] = $data['stock'];
    }
    
    if (isset($data['discount'])) {
        $fields[] = "discount = ?";
        $values[] = $data['discount'];
    }
    
    if (isset($data['category'])) {
        $fields[] = "category = ?";
        $values[] = $data['category'];
    }
    
    if (isset($data['image'])) {
        $fields[] = "image = ?";
        $values[] = $data['image'];
    }
    
    if (empty($fields)) {
        apiResponse('error', 'No fields to update', null);
    }
    
    // Add product ID to values array
    $values[] = $id;
    
    try {
        $sql = "UPDATE products SET " . implode(", ", $fields) . " WHERE id = ?";
        $stmt = $pdo->prepare($sql);
        $stmt->execute($values);
        
        // Get the updated product
        $stmt = $pdo->prepare("SELECT * FROM products WHERE id = ?");
        $stmt->execute([$id]);
        $updatedProduct = $stmt->fetch();
        
        apiResponse('success', 'Product updated successfully', $updatedProduct);
    } catch (PDOException $e) {
        apiResponse('error', 'Database error: ' . $e->getMessage(), null);
    }
}

// DELETE - Remove a product
function handleDelete() {
    global $pdo;
    
    // Check admin/operator authorization
    requireAdminAuth();
    
    // Get product ID from URL parameter
    if (!isset($_GET['id'])) {
        apiResponse('error', 'Product ID is required', null);
    }
    
    $id = $_GET['id'];
    
    // Verify product exists
    $stmt = $pdo->prepare("SELECT * FROM products WHERE id = ?");
    $stmt->execute([$id]);
    $product = $stmt->fetch();
    
    if (!$product) {
        apiResponse('error', 'Product not found', null);
    }
    
    try {
        $stmt = $pdo->prepare("DELETE FROM products WHERE id = ?");
        $stmt->execute([$id]);
        
        apiResponse('success', 'Product deleted successfully', ['id' => $id]);
    } catch (PDOException $e) {
        apiResponse('error', 'Database error: ' . $e->getMessage(), null);
    }
} 