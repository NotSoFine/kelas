<?php
// Prevent direct access to config file
if (basename($_SERVER['PHP_SELF']) === 'config.php') {
    header('HTTP/1.1 403 Forbidden');
    echo json_encode([
        'status' => 'error',
        'message' => 'Direct access to this file is not allowed'
    ]);
    exit;
}

// API Configuration
header('Content-Type: application/json');

// Allow CORS - adjust as needed for production
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

// Handle preflight OPTIONS request
if (isset($_SERVER['REQUEST_METHOD']) && $_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

// Error handler for API
function handleApiError($errno, $errstr, $errfile, $errline) {
    $error = [
        'status' => 'error',
        'message' => 'Server error: ' . $errstr,
        'details' => [
            'file' => basename($errfile),
            'line' => $errline
        ]
    ];
    
    // Log error to file
    error_log("API Error: $errstr in $errfile on line $errline");
    
    // Return JSON response
    echo json_encode($error);
    exit;
}

// Set error handler
set_error_handler('handleApiError', E_ALL);

// Include database connection
try {
    // Calculate path to db.php
    $rootDir = dirname(dirname(__FILE__));
    require_once $rootDir . '/db.php';
    
    // Check that PDO object exists
    if (!isset($pdo) || !($pdo instanceof PDO)) {
        throw new Exception('Database connection not established.');
    }
    
    // Test the connection
    $pdo->query('SELECT 1');
} catch (Exception $e) {
    apiResponse('error', 'Database connection failed: ' . $e->getMessage(), null);
}

// API Response function
function apiResponse($status, $message, $data = null) {
    $response = [
        'status' => $status,
        'message' => $message
    ];
    
    if ($data !== null) {
        $response['data'] = $data;
    }
    
    echo json_encode($response);
    exit;
}

// API Authentication check
function requireAuth() {
    // Simple session-based authentication check
    session_start();
    
    // Check for either user_id (regular login) or admin_id (admin login)
    if (!isset($_SESSION['user_id']) && !isset($_SESSION['admin_id'])) {
        apiResponse('error', 'Authentication required', null);
    }
    
    // Return the appropriate ID
    return isset($_SESSION['user_id']) ? $_SESSION['user_id'] : $_SESSION['admin_id'];
}

// Admin/Operator Authentication check
function requireAdminAuth() {
    session_start();
    
    // Check for admin role with either login method
    if ((!isset($_SESSION['user_id']) && !isset($_SESSION['admin_id'])) || 
        ($_SESSION['role'] !== 'admin' && $_SESSION['role'] !== 'operator')) {
        apiResponse('error', 'Admin authentication required', null);
    }
    
    // Return the appropriate ID
    return isset($_SESSION['user_id']) ? $_SESSION['user_id'] : $_SESSION['admin_id'];
} 