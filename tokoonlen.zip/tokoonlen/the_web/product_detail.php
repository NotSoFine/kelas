<?php
session_start();
include 'db.php';

// Check if product ID is provided
if (!isset($_GET['id']) || empty($_GET['id'])) {
    header("Location: index.php");
    exit;
}

$product_id = $_GET['id'];
$product = null;
$reviews = [];
$avgRating = 0;
$totalReviews = 0;

try {
    // Fetch product details
    $stmt = $pdo->prepare("SELECT * FROM products WHERE id = ?");
    $stmt->execute([$product_id]);
    $product = $stmt->fetch();
    
    if (!$product) {
        header("Location: index.php");
        exit;
    }
    
    // Check if reviews table exists and fetch reviews
    try {
        $checkTable = $pdo->query("SHOW TABLES LIKE 'reviews'");
        if ($checkTable->rowCount() > 0) {
            // Fetch reviews for this product
            $reviewStmt = $pdo->prepare("SELECT r.*, u.username FROM reviews r 
                                        LEFT JOIN users u ON r.user_id = u.id 
                                        WHERE r.product_id = ? 
                                        ORDER BY r.created_at DESC");
            $reviewStmt->execute([$product_id]);
            $reviews = $reviewStmt->fetchAll();
            
            // Calculate average rating
            $ratingStmt = $pdo->prepare("SELECT AVG(rating) as avg_rating, COUNT(*) as total FROM reviews WHERE product_id = ?");
            $ratingStmt->execute([$product_id]);
            $ratingData = $ratingStmt->fetch();
            $avgRating = round($ratingData['avg_rating'], 1) ?: 0;
            $totalReviews = $ratingData['total'];
        }
    } catch (PDOException $e) {
        // Reviews table doesn't exist or other error
    }
    
    // Check if user is logged in
    $isLoggedIn = isset($_SESSION['user_id']) || isset($_SESSION['admin_id']);
    $username = $_SESSION['username'] ?? $_SESSION['admin_username'] ?? '';
    
} catch (PDOException $e) {
    die("Database error: " . $e->getMessage());
}

// Handle add to cart
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_to_cart'])) {
    $quantity = isset($_POST['quantity']) ? (int)$_POST['quantity'] : 1;
    
    // If product_id is provided in POST (from index page), use that instead
    if (isset($_POST['product_id'])) {
        $product_id = $_POST['product_id'];
        
        // Fetch the product data if we don't have it yet
        if (!$product || $product['id'] != $product_id) {
            $stmt = $pdo->prepare("SELECT * FROM products WHERE id = ?");
            $stmt->execute([$product_id]);
            $product = $stmt->fetch();
            
            if (!$product) {
                header("Location: index.php");
                exit;
            }
        }
    }
    
    if ($quantity <= 0) {
        $quantity = 1;
    }
    
    if ($quantity > $product['stock']) {
        $quantity = $product['stock'];
    }
    
    // Initialize cart in session if it doesn't exist
    if (!isset($_SESSION['cart'])) {
        $_SESSION['cart'] = [];
    }
    
    // Check if product already in cart
    $found = false;
    foreach ($_SESSION['cart'] as &$item) {
        if ($item['id'] == $product_id) {
            $item['quantity'] += $quantity;
            $found = true;
            break;
        }
    }
    
    // Add new product to cart if not found
    if (!$found) {
        $_SESSION['cart'][] = [
            'id' => $product_id,
            'name' => $product['name'],
            'price' => $product['price'],
            'discount' => $product['discount'],
            'image' => $product['image'],
            'quantity' => $quantity
        ];
    }
    
    // Set a flag to show notification
    $_SESSION['cart_notification'] = [
        'product_name' => $product['name'],
        'time' => time()
    ];
    
    // Redirect back to the same product page
    header("Location: product_detail.php?id=$product_id");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title><?php echo htmlspecialchars($product['name']); ?> - EcomPro</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome for icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <style>
        .product-image {
            max-height: 400px;
            object-fit: contain;
        }
        .strike {
            text-decoration: line-through;
            color: gray;
        }
        .rating {
            color: #ffc107;
        }
        .review-card {
            border-bottom: 1px solid #eee;
            padding-bottom: 15px;
            margin-bottom: 15px;
        }
        .review-card:last-child {
            border-bottom: none;
        }
        .cart-notification {
            position: fixed;
            top: 20px;
            right: 20px;
            z-index: 1050;
            max-width: 300px;
        }
    </style>
</head>
<body>

<!-- Cart notification -->
<?php if (isset($_SESSION['cart_notification']) && (time() - $_SESSION['cart_notification']['time'] < 5)): ?>
    <div class="cart-notification">
        <div class="toast show" role="alert" aria-live="assertive" aria-atomic="true">
            <div class="toast-header bg-success text-white">
                <strong class="me-auto"><i class="fas fa-check-circle me-2"></i> Added to Cart</strong>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="toast" aria-label="Close"></button>
            </div>
            <div class="toast-body">
                <strong><?php echo htmlspecialchars($_SESSION['cart_notification']['product_name']); ?></strong> has been added to your cart.
                <div class="mt-2">
                    <a href="cart.php" class="btn btn-sm btn-primary">View Cart</a>
                </div>
            </div>
        </div>
    </div>
<?php endif; ?>

<!-- Main Navbar -->
<nav class="navbar navbar-expand-lg navbar-light bg-white shadow-sm">
    <div class="container">
        <a class="navbar-brand" href="index.php">EcomPro</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav me-auto">
                <li class="nav-item">
                    <a class="nav-link" href="index.php">Home</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="catalog.php">Catalog</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="about.php">About</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="contact.php">Contact</a>
                </li>
            </ul>
            <ul class="navbar-nav">
                <?php if ($isLoggedIn): ?>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown">
                            <i class="fas fa-user-circle me-1"></i> <?php echo htmlspecialchars($username); ?>
                        </a>
                        <ul class="dropdown-menu dropdown-menu-end">
                            <?php if (isset($_SESSION['admin_id'])): ?>
                                <li><a class="dropdown-item" href="admin/index.php">Admin Dashboard</a></li>
                                <li><hr class="dropdown-divider"></li>
                            <?php endif; ?>
                            <li><a class="dropdown-item" href="profile.php">My Profile</a></li>
                            <li><a class="dropdown-item" href="orders.php">My Orders</a></li>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item" href="logout.php">Logout</a></li>
                        </ul>
                    </li>
                <?php else: ?>
                    <li class="nav-item">
                        <a class="nav-link" href="login.php">Login</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="register.php">Register</a>
                    </li>
                <?php endif; ?>
                <li class="nav-item">
                    <a class="nav-link" href="cart.php">
                        <i class="fas fa-shopping-cart"></i>
                    </a>
                </li>
            </ul>
        </div>
    </div>
</nav>

<div class="container mt-4">
    <!-- Breadcrumb -->
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="index.php">Home</a></li>
            <li class="breadcrumb-item active" aria-current="page"><?php echo htmlspecialchars($product['name']); ?></li>
        </ol>
    </nav>
    
    <div class="row mb-5">
        <!-- Product Image -->
        <div class="col-md-6 mb-4">
            <img src="<?php echo htmlspecialchars($product['image']); ?>" class="img-fluid product-image" alt="<?php echo htmlspecialchars($product['name']); ?>">
        </div>
        
        <!-- Product Details -->
        <div class="col-md-6">
            <h2><?php echo htmlspecialchars($product['name']); ?></h2>
            
            <!-- Category -->
            <?php if (!empty($product['category'])): ?>
                <div class="mb-3">
                    <a href="catalog.php?category=<?php echo urlencode($product['category']); ?>" class="badge bg-info text-decoration-none fs-6">
                        <i class="fas fa-tag me-1"></i> <?php echo htmlspecialchars($product['category']); ?>
                    </a>
                </div>
            <?php endif; ?>
            
            <!-- Rating -->
            <div class="mb-3">
                <div class="rating">
                    <?php for ($i = 1; $i <= 5; $i++): ?>
                        <?php if ($i <= $avgRating): ?>
                            <i class="fas fa-star"></i>
                        <?php elseif ($i - 0.5 <= $avgRating): ?>
                            <i class="fas fa-star-half-alt"></i>
                        <?php else: ?>
                            <i class="far fa-star"></i>
                        <?php endif; ?>
                    <?php endfor; ?>
                    <span class="ms-2"><?php echo $avgRating; ?> (<?php echo $totalReviews; ?> reviews)</span>
                </div>
            </div>
            
            <!-- Price -->
            <div class="mb-3">
                <?php if ($product['discount'] > 0): ?>
                    <h4>
                        <span class="strike">$<?php echo number_format($product['price'], 2); ?></span>
                        <span class="text-danger">$<?php echo number_format($product['price'] - $product['discount'], 2); ?></span>
                        <span class="badge bg-danger">Save $<?php echo number_format($product['discount'], 2); ?></span>
                    </h4>
                <?php else: ?>
                    <h4>$<?php echo number_format($product['price'], 2); ?></h4>
                <?php endif; ?>
            </div>
            
            <!-- Stock -->
            <div class="mb-3">
                <p>
                    <?php if ($product['stock'] > 10): ?>
                        <span class="text-success"><i class="fas fa-check-circle"></i> In Stock (<?php echo $product['stock']; ?> available)</span>
                    <?php elseif ($product['stock'] > 0): ?>
                        <span class="text-warning"><i class="fas fa-exclamation-circle"></i> Low Stock (Only <?php echo $product['stock']; ?> left)</span>
                    <?php else: ?>
                        <span class="text-danger"><i class="fas fa-times-circle"></i> Out of Stock</span>
                    <?php endif; ?>
                </p>
            </div>
            
            <!-- Description -->
            <div class="mb-4">
                <h5>Description</h5>
                <p><?php echo nl2br(htmlspecialchars($product['description'] ?? 'No description available')); ?></p>
            </div>
            
            <!-- Add to Cart Form -->
            <?php if ($product['stock'] > 0): ?>
                <form action="" method="POST" class="mb-4">
                    <div class="row g-3 align-items-center">
                        <div class="col-auto">
                            <label for="quantity" class="col-form-label">Quantity:</label>
                        </div>
                        <div class="col-auto">
                            <input type="number" id="quantity" name="quantity" class="form-control" value="1" min="1" max="<?php echo $product['stock']; ?>">
                        </div>
                        <div class="col-auto">
                            <button type="submit" name="add_to_cart" class="btn btn-primary">
                                <i class="fas fa-cart-plus me-2"></i> Add to Cart
                            </button>
                        </div>
                    </div>
                </form>
            <?php else: ?>
                <button class="btn btn-secondary" disabled>Out of Stock</button>
            <?php endif; ?>
        </div>
    </div>
    
    <!-- Reviews Section -->
    <div class="row">
        <div class="col-12">
            <h4 class="mb-4">Customer Reviews</h4>
            
            <?php if (empty($reviews)): ?>
                <div class="alert alert-info">
                    No reviews yet. Be the first to review this product!
                </div>
            <?php else: ?>
                <div class="reviews">
                    <?php foreach ($reviews as $review): ?>
                        <div class="review-card">
                            <div class="d-flex justify-content-between">
                                <h5><?php echo htmlspecialchars($review['username'] ?? 'Anonymous'); ?></h5>
                                <small class="text-muted"><?php echo date('M d, Y', strtotime($review['created_at'])); ?></small>
                            </div>
                            <div class="rating mb-2">
                                <?php for ($i = 1; $i <= 5; $i++): ?>
                                    <?php if ($i <= $review['rating']): ?>
                                        <i class="fas fa-star"></i>
                                    <?php else: ?>
                                        <i class="far fa-star"></i>
                                    <?php endif; ?>
                                <?php endfor; ?>
                            </div>
                            <p><?php echo nl2br(htmlspecialchars($review['comment'])); ?></p>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
            
            <!-- Add Review Form (only for logged-in users) -->
            <?php if ($isLoggedIn): ?>
                <div class="mt-4">
                    <h5>Write a Review</h5>
                    <form action="add_review.php" method="POST">
                        <input type="hidden" name="product_id" value="<?php echo $product_id; ?>">
                        
                        <div class="mb-3">
                            <label class="form-label">Rating</label>
                            <div class="rating-select">
                                <?php for ($i = 5; $i >= 1; $i--): ?>
                                    <div class="form-check form-check-inline">
                                        <input class="form-check-input" type="radio" name="rating" id="rating<?php echo $i; ?>" value="<?php echo $i; ?>" <?php echo $i == 5 ? 'checked' : ''; ?>>
                                        <label class="form-check-label" for="rating<?php echo $i; ?>"><?php echo $i; ?> stars</label>
                                    </div>
                                <?php endfor; ?>
                            </div>
                        </div>
                        
                        <div class="mb-3">
                            <label for="comment" class="form-label">Your Review</label>
                            <textarea class="form-control" id="comment" name="comment" rows="3" required></textarea>
                        </div>
                        
                        <button type="submit" class="btn btn-primary">Submit Review</button>
                    </form>
                </div>
            <?php else: ?>
                <div class="alert alert-info mt-4">
                    Please <a href="login.php">login</a> to write a review.
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<!-- Footer -->
<footer class="bg-dark text-white mt-5 py-4">
    <div class="container">
        <div class="row">
            <div class="col-md-4">
                <h5>EcomPro</h5>
                <p>Your one-stop shop for quality products.</p>
            </div>
            <div class="col-md-4">
                <h5>Quick Links</h5>
                <ul class="list-unstyled">
                    <li><a href="index.php" class="text-white">Home</a></li>
                    <li><a href="catalog.php" class="text-white">Catalog</a></li>
                    <li><a href="about.php" class="text-white">About Us</a></li>
                    <li><a href="contact.php" class="text-white">Contact</a></li>
                </ul>
            </div>
            <div class="col-md-4">
                <h5>Contact Us</h5>
                <address>
                    <p><i class="fas fa-map-marker-alt me-2"></i> 123 Main St, City</p>
                    <p><i class="fas fa-phone me-2"></i> (123) 456-7890</p>
                    <p><i class="fas fa-envelope me-2"></i> info@ecompro.com</p>
                </address>
            </div>
        </div>
        <hr>
        <div class="text-center">
            <p>&copy; <?php echo date('Y'); ?> EcomPro. All rights reserved.</p>
        </div>
    </div>
</footer>

<!-- Bootstrap Bundle with Popper -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

<script>
    // Auto-hide the toast notification after 3 seconds
    document.addEventListener('DOMContentLoaded', function() {
        setTimeout(function() {
            var toastElement = document.querySelector('.cart-notification .toast');
            if (toastElement) {
                var toast = new bootstrap.Toast(toastElement);
                toast.hide();
            }
        }, 3000);
    });
</script>

</body>
</html> 