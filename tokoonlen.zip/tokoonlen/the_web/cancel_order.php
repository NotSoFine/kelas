<?php
session_start();
include 'db.php';

// Redirect if not logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

// Check if order ID is provided
if (!isset($_POST['order_id'])) {
    header('Location: orders.php');
    exit;
}

$order_id = $_POST['order_id'];
$user_id = $_SESSION['user_id'];

try {
    // Verify that the order belongs to the current user and is in 'pending' status
    $stmt = $pdo->prepare("SELECT * FROM orders WHERE id = ? AND user_id = ? AND status = 'pending'");
    $stmt->execute([$order_id, $user_id]);
    $order = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$order) {
        // Order not found, doesn't belong to the current user, or is not in 'pending' status
        $_SESSION['error_message'] = "This order cannot be cancelled.";
        header('Location: orders.php');
        exit;
    }
    
    // Start transaction
    $pdo->beginTransaction();
    
    // Update order status to 'cancelled'
    $stmt = $pdo->prepare("UPDATE orders SET status = 'cancelled', updated_at = NOW() WHERE id = ?");
    $stmt->execute([$order_id]);
    
    // Restore product stock (optional)
    $stmt = $pdo->prepare("SELECT * FROM order_items WHERE order_id = ?");
    $stmt->execute([$order_id]);
    $order_items = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    foreach ($order_items as $item) {
        if ($item['product_id']) {
            $stmt = $pdo->prepare("UPDATE products SET stock = stock + ? WHERE id = ?");
            $stmt->execute([$item['quantity'], $item['product_id']]);
        }
    }
    
    // Commit transaction
    $pdo->commit();
    
    // Set success message
    $_SESSION['success_message'] = "Order #{$order['order_code']} has been cancelled successfully.";
    
} catch (PDOException $e) {
    // Rollback transaction on error
    $pdo->rollBack();
    $_SESSION['error_message'] = "An error occurred while cancelling your order. Please try again.";
}

// Redirect back to orders page
header('Location: orders.php');
exit;
?> 