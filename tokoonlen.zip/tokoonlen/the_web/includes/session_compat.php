<?php
/**
 * Session Compatibility Layer
 * 
 * This file helps normalize session variables between the admin and regular login systems.
 * Include this file after session_start() in pages where you need compatible session handling.
 */

// Only process if session is active
if (session_status() === PHP_SESSION_ACTIVE) {
    
    // If logged in as admin, add user_id and username for API compatibility
    if (isset($_SESSION['admin_id']) && !isset($_SESSION['user_id'])) {
        $_SESSION['user_id'] = $_SESSION['admin_id'];
        $_SESSION['username'] = $_SESSION['admin_username'] ?? 'admin';
    }
    
    // If logged in as regular user, add admin_id and admin_username for admin panel compatibility
    if (isset($_SESSION['user_id']) && !isset($_SESSION['admin_id'])) {
        $_SESSION['admin_id'] = $_SESSION['user_id'];
        $_SESSION['admin_username'] = $_SESSION['username'] ?? 'user';
    }
    
    // Ensure role is set
    if (!isset($_SESSION['role']) && (isset($_SESSION['user_id']) || isset($_SESSION['admin_id']))) {
        $_SESSION['role'] = 'customer'; // Default role
    }
}

/**
 * Helper function to check if user is logged in (works with either login system)
 * 
 * @return bool True if logged in, false otherwise
 */
function is_logged_in() {
    return isset($_SESSION['user_id']) || isset($_SESSION['admin_id']);
}

/**
 * Helper function to check if user is admin (works with either login system)
 * 
 * @return bool True if admin, false otherwise
 */
function is_admin() {
    return is_logged_in() && ($_SESSION['role'] === 'admin' || $_SESSION['role'] === 'operator');
}

/**
 * Helper function to get current user ID (works with either login system)
 * 
 * @return int|null User ID or null if not logged in
 */
function get_user_id() {
    if (isset($_SESSION['user_id'])) {
        return $_SESSION['user_id'];
    } elseif (isset($_SESSION['admin_id'])) {
        return $_SESSION['admin_id'];
    }
    return null;
}

/**
 * Helper function to get current username (works with either login system)
 * 
 * @return string|null Username or null if not logged in
 */
function get_username() {
    if (isset($_SESSION['username'])) {
        return $_SESSION['username'];
    } elseif (isset($_SESSION['admin_username'])) {
        return $_SESSION['admin_username'];
    }
    return null;
} 