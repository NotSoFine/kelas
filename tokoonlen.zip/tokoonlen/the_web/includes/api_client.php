<?php
/**
 * API Client - A simple PHP client for interacting with the eCompro API
 */
class ApiClient {
    private $baseUrl;
    
    /**
     * Constructor
     */
    public function __construct() {
        // Base URL with protocol and hostname to avoid path issues
        $protocol = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 'https' : 'http';
        $host = isset($_SERVER['HTTP_HOST']) ? $_SERVER['HTTP_HOST'] : 'localhost';
        $this->baseUrl = "$protocol://$host/ecompro/the_web/api";
        
        // For debugging
        error_log("API Client initialized with base URL: " . $this->baseUrl);
    }
    
    /**
     * Make a request to the API
     * 
     * @param string $endpoint API endpoint
     * @param string $method HTTP method (GET, POST, PUT, DELETE)
     * @param array|null $data Data to send with the request
     * @param array $queryParams Query parameters
     * @return array Response from the API
     */
    public function request($endpoint, $method = 'GET', $data = null, $queryParams = []) {
        // Build the URL with query parameters
        $url = $this->baseUrl . '/' . $endpoint;
        if (!empty($queryParams)) {
            $url .= '?' . http_build_query($queryParams);
        }
        
        // Log the request for debugging
        error_log("API Request: $method $url");
        if ($data) {
            error_log("Request data: " . json_encode($data));
        }
        
        // Initialize cURL
        $ch = curl_init();
        
        // Set options based on method
        switch ($method) {
            case 'POST':
                curl_setopt($ch, CURLOPT_POST, 1);
                if ($data !== null) {
                    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
                }
                break;
                
            case 'PUT':
                curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'PUT');
                if ($data !== null) {
                    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
                }
                break;
                
            case 'DELETE':
                curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'DELETE');
                break;
                
            default: // GET
                if ($data !== null) {
                    $url .= (strpos($url, '?') === false ? '?' : '&') . http_build_query($data);
                }
                break;
        }
        
        // Common options
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Content-Type: application/json',
            'Accept: application/json'
        ]);
        
        // Enhanced session handling - make sure session is started first
        if (!session_id()) {
            session_start();
        }
        
        // Include all cookies from the current session
        $cookies = [];
        foreach ($_COOKIE as $key => $value) {
            $cookies[] = $key . '=' . $value;
        }
        
        if (!empty($cookies)) {
            curl_setopt($ch, CURLOPT_COOKIE, implode('; ', $cookies));
            error_log("Sending cookies: " . implode('; ', $cookies));
        } else {
            error_log("No cookies available to send with API request");
        }
        
        // Enable cookie handling
        curl_setopt($ch, CURLOPT_COOKIEFILE, ""); // Enable cookie handling but don't read from file
        curl_setopt($ch, CURLOPT_COOKIEJAR, "");  // Enable cookie storage but don't write to file
        
        // Needed for local development with self-signed certificates
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        
        // Execute the request
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        
        // Log the response for debugging
        error_log("API Response code: $httpCode");
        error_log("API Response: $response");
        
        // Check for errors
        if (curl_errno($ch)) {
            $error = curl_error($ch);
            curl_close($ch);
            error_log("cURL Error: $error");
            return [
                'status' => 'error',
                'message' => 'cURL Error: ' . $error,
                'http_code' => $httpCode
            ];
        }
        
        curl_close($ch);
        
        // Parse the response
        $result = json_decode($response, true);
        
        // Check if response was valid JSON
        if ($result === null && json_last_error() !== JSON_ERROR_NONE) {
            error_log("Invalid JSON response: $response");
            return [
                'status' => 'error',
                'message' => 'Invalid JSON response: ' . $response,
                'http_code' => $httpCode
            ];
        }
        
        return $result;
    }
    
    /**
     * GET request
     * 
     * @param string $endpoint API endpoint
     * @param array $queryParams Query parameters
     * @return array Response
     */
    public function get($endpoint, $queryParams = []) {
        return $this->request($endpoint, 'GET', null, $queryParams);
    }
    
    /**
     * POST request
     * 
     * @param string $endpoint API endpoint
     * @param array $data Data to send
     * @param array $queryParams Query parameters
     * @return array Response
     */
    public function post($endpoint, $data, $queryParams = []) {
        return $this->request($endpoint, 'POST', $data, $queryParams);
    }
    
    /**
     * PUT request
     * 
     * @param string $endpoint API endpoint
     * @param array $data Data to send
     * @param array $queryParams Query parameters
     * @return array Response
     */
    public function put($endpoint, $data, $queryParams = []) {
        return $this->request($endpoint, 'PUT', $data, $queryParams);
    }
    
    /**
     * DELETE request
     * 
     * @param string $endpoint API endpoint
     * @param array $queryParams Query parameters
     * @return array Response
     */
    public function delete($endpoint, $queryParams = []) {
        return $this->request($endpoint, 'DELETE', null, $queryParams);
    }
    
    /*
     * User API Methods
     */
    
    /**
     * Get user profile
     * 
     * @return array User profile data
     */
    public function getUserProfile() {
        return $this->get('users.php', ['profile' => true]);
    }
    
    /**
     * Get a specific user by ID
     * 
     * @param int $userId User ID
     * @return array User data
     */
    public function getUser($userId) {
        return $this->get('users.php', ['id' => $userId]);
    }
    
    /**
     * Get all users (admin only)
     * 
     * @param int $page Page number
     * @param int $limit Results per page
     * @return array Users with pagination
     */
    public function getUsers($page = 1, $limit = 10) {
        return $this->get('users.php', [
            'page' => $page,
            'limit' => $limit
        ]);
    }
    
    /**
     * Update user profile
     * 
     * @param int $userId User ID
     * @param array $data Profile data to update
     * @return array Updated user data
     */
    public function updateProfile($userId, $data) {
        return $this->put('users.php', $data, ['id' => $userId]);
    }
    
    /**
     * Login user
     * 
     * @param string $username Username or email
     * @param string $password Password
     * @return array Login response
     */
    public function login($username, $password) {
        return $this->post('users.php', [
            'username' => $username,
            'password' => $password
        ], ['login' => true]);
    }
    
    /**
     * Register a new user
     * 
     * @param array $userData User data
     * @return array Registration response
     */
    public function register($userData) {
        return $this->post('users.php', $userData, ['register' => true]);
    }
    
    /**
     * Create a new user (admin only)
     * 
     * @param array $userData User data
     * @return array Created user
     */
    public function createUser($userData) {
        return $this->post('users.php', $userData);
    }
    
    /**
     * Delete a user (admin only)
     * 
     * @param int $userId User ID
     * @return array Response
     */
    public function deleteUser($userId) {
        return $this->delete('users.php', ['id' => $userId]);
    }
    
    /*
     * Product API Methods
     */
    
    /**
     * Get products with pagination
     * 
     * @param int $page Page number
     * @param int $limit Results per page
     * @return array Products with pagination data
     */
    public function getProducts($page = 1, $limit = 10) {
        return $this->get('products.php', [
            'page' => $page,
            'limit' => $limit
        ]);
    }
    
    /**
     * Get product by ID
     * 
     * @param int $id Product ID
     * @return array Product data
     */
    public function getProduct($id) {
        return $this->get('products.php', ['id' => $id]);
    }
    
    /**
     * Search products
     * 
     * @param string $query Search query
     * @return array Search results
     */
    public function searchProducts($query) {
        return $this->get('products.php', ['search' => $query]);
    }
    
    /**
     * Add product
     * 
     * @param array $data Product data
     * @return array Created product
     */
    public function addProduct($data) {
        return $this->post('products.php', $data);
    }
    
    /**
     * Update product
     * 
     * @param int $id Product ID
     * @param array $data Product data to update
     * @return array Updated product
     */
    public function updateProduct($id, $data) {
        return $this->put('products.php', $data, ['id' => $id]);
    }
    
    /**
     * Delete product
     * 
     * @param int $id Product ID
     * @return array Response
     */
    public function deleteProduct($id) {
        return $this->delete('products.php', ['id' => $id]);
    }
    
    /*
     * Order API Methods
     */
    
    /**
     * Get all orders (admin only)
     * 
     * @param int $page Page number
     * @param int $limit Results per page
     * @param string|null $status Filter by status
     * @return array Orders with pagination
     */
    public function getOrders($page = 1, $limit = 10, $status = null) {
        $params = [
            'page' => $page,
            'limit' => $limit
        ];
        
        if ($status) {
            $params['status'] = $status;
        }
        
        return $this->get('orders.php', $params);
    }
    
    /**
     * Get orders for a specific user
     * 
     * @param int $userId User ID
     * @param int $page Page number
     * @param int $limit Results per page
     * @return array Orders with pagination
     */
    public function getUserOrders($userId, $page = 1, $limit = 10) {
        return $this->get('orders.php', [
            'user_id' => $userId,
            'page' => $page,
            'limit' => $limit
        ]);
    }
    
    /**
     * Get a specific order by ID
     * 
     * @param int $id Order ID
     * @return array Order with items
     */
    public function getOrder($id) {
        return $this->get('orders.php', ['id' => $id]);
    }
    
    /**
     * Create a new order
     * 
     * @param array $orderData Order data with items
     * @return array Created order
     */
    public function createOrder($orderData) {
        return $this->post('orders.php', $orderData);
    }
    
    /**
     * Update order status (admin only)
     * 
     * @param int $id Order ID
     * @param string $status New status
     * @return array Updated order
     */
    public function updateOrderStatus($id, $status) {
        return $this->put('orders.php', ['status' => $status], ['id' => $id]);
    }
    
    /*
     * Settings API Methods
     */
    
    /**
     * Get all settings
     * 
     * @return array All settings grouped by group
     */
    public function getSettings() {
        return $this->get('settings.php');
    }
    
    /**
     * Get settings for a specific group
     * 
     * @param string $group Group name
     * @return array Settings for the group
     */
    public function getSettingsByGroup($group) {
        return $this->get('settings.php', ['group' => $group]);
    }
    
    /**
     * Get a specific setting by key
     * 
     * @param string $key Setting key
     * @return array Setting data
     */
    public function getSetting($key) {
        return $this->get('settings.php', ['key' => $key]);
    }
    
    /**
     * Update settings (admin only)
     * 
     * @param array $settings Settings to update (key => value pairs)
     * @return array Updated settings
     */
    public function updateSettings($settings) {
        return $this->put('settings.php', $settings);
    }
} 