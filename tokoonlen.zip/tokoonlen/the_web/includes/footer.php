    <!-- Footer -->
    <footer class="bg-dark text-white py-4 mt-5">
        <div class="container">
            <div class="row">
                <div class="col-md-4 mb-3">
                    <h5 class="mb-3">eCompro</h5>
                    <p>Your one-stop shop for all your needs.</p>
                    <div class="social-icons">
                        <a href="#" class="text-white me-2"><i class="fab fa-facebook-f"></i></a>
                        <a href="#" class="text-white me-2"><i class="fab fa-twitter"></i></a>
                        <a href="#" class="text-white me-2"><i class="fab fa-instagram"></i></a>
                        <a href="#" class="text-white"><i class="fab fa-linkedin-in"></i></a>
                    </div>
                </div>
                
                <div class="col-md-2 mb-3">
                    <h5 class="mb-3">Quick Links</h5>
                    <ul class="list-unstyled">
                        <li><a href="/ecompro/the_web/index.php" class="text-white">Home</a></li>
                        <li><a href="/ecompro/the_web/catalog.php" class="text-white">Products</a></li>
                        <li><a href="/ecompro/the_web/about.php" class="text-white">About Us</a></li>
                        <li><a href="/ecompro/the_web/contact.php" class="text-white">Contact Us</a></li>
                    </ul>
                </div>
                
                <div class="col-md-3 mb-3">
                    <h5 class="mb-3">Customer Service</h5>
                    <ul class="list-unstyled">
                        <li><a href="#" class="text-white">My Account</a></li>
                        <li><a href="#" class="text-white">Order History</a></li>
                        <li><a href="#" class="text-white">Shipping Info</a></li>
                        <li><a href="#" class="text-white">Returns & Refunds</a></li>
                    </ul>
                </div>
                
                <div class="col-md-3 mb-3">
                    <h5 class="mb-3">API & Development</h5>
                    <ul class="list-unstyled">
                        <li><a href="/ecompro/the_web/api_demo.php" class="text-white">API Demo</a></li>
                        <li><a href="/ecompro/the_web/api/README.md" class="text-white" target="_blank">API Documentation</a></li>
                    </ul>
                </div>
            </div>
            
            <hr class="my-4">
            
            <div class="row">
                <div class="col-md-6 text-center text-md-start">
                    <p class="mb-0">&copy; <?php echo date('Y'); ?> eCompro. All rights reserved.</p>
                </div>
                <div class="col-md-6 text-center text-md-end">
                    <a href="#" class="text-white me-2">Privacy Policy</a>
                    <a href="#" class="text-white me-2">Terms of Service</a>
                </div>
            </div>
        </div>
    </footer>
    
    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <!-- Custom JS -->
    <script src="/ecompro/the_web/assets/js/api-client.js"></script>
    <script src="/ecompro/the_web/assets/js/main.js"></script>
</body>
</html>
