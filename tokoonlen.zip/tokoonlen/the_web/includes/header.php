<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>eCompro - Your Online Shopping Destination</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome for icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="/ecompro/the_web/assets/style.css">
</head>
<body>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
        <div class="container">
            <a class="navbar-brand" href="/ecompro/the_web/index.php">
                <i class="fas fa-shopping-cart me-2"></i> eCompro
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                    <li class="nav-item">
                        <a class="nav-link" href="/ecompro/the_web/index.php">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="/ecompro/the_web/catalog.php">Products</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="/ecompro/the_web/about.php">About</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="/ecompro/the_web/contact.php">Contact</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="/ecompro/the_web/api_demo.php">
                            <i class="fas fa-code me-1"></i> API Demo
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="/ecompro/the_web/api_test.php">
                            <i class="fas fa-vial me-1"></i> API Testing
                        </a>
                    </li>
                </ul>
                
                <form class="d-flex me-2" action="/ecompro/the_web/catalog.php" method="GET">
                    <input class="form-control me-2" type="search" name="search" placeholder="Search products..." aria-label="Search">
                    <button class="btn btn-light" type="submit">
                        <i class="fas fa-search"></i>
                    </button>
                </form>
                
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link" href="/ecompro/the_web/cart.php">
                            <i class="fas fa-shopping-basket"></i>
                            <?php if (isset($_SESSION['cart']) && count($_SESSION['cart']) > 0): ?>
                                <span class="badge bg-danger"><?php echo count($_SESSION['cart']); ?></span>
                            <?php endif; ?>
                        </a>
                    </li>
                    
                    <?php if (isset($_SESSION['user_id'])): ?>
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown">
                                <i class="fas fa-user-circle"></i> 
                                <?php echo htmlspecialchars($_SESSION['username'] ?? 'User'); ?>
                            </a>
                            <ul class="dropdown-menu dropdown-menu-end">
                                <li><a class="dropdown-item" href="/ecompro/the_web/profile.php">My Profile</a></li>
                                <li><a class="dropdown-item" href="/ecompro/the_web/orders.php">My Orders</a></li>
                                <?php if (isset($_SESSION['role']) && ($_SESSION['role'] === 'admin' || $_SESSION['role'] === 'operator')): ?>
                                    <li><hr class="dropdown-divider"></li>
                                    <li><a class="dropdown-item" href="/ecompro/the_web/admin/index.php">Admin Panel</a></li>
                                <?php endif; ?>
                                <li><hr class="dropdown-divider"></li>
                                <li><a class="dropdown-item" href="/ecompro/the_web/logout.php">Logout</a></li>
                            </ul>
                        </li>
                    <?php else: ?>
                        <li class="nav-item">
                            <a class="nav-link" href="/ecompro/the_web/login.php">Login</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="/ecompro/the_web/register.php">Register</a>
                        </li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </nav>
    
    <!-- Main Content -->
</body>
</html>
