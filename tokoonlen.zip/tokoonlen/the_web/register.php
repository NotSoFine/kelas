<?php
require_once 'db.php';
require_once 'admin/includes/config.php';

// Start session if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Check if already logged in
if (isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit;
} elseif (isset($_SESSION['admin_id'])) {
    header("Location: admin/index.php");
    exit;
}

// Check if there's already an admin user
$stmt = $pdo->query("SELECT COUNT(*) FROM users WHERE role = 'operator'");
$adminCount = $stmt->fetchColumn();

$error = '';
$success = '';

// Handle registration form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'] ?? '';
    $password = $_POST['password'] ?? '';
    $confirmPassword = $_POST['confirm_password'] ?? '';
    $role = $_POST['role'] ?? 'user';
    $token = $_POST['token'] ?? '';
    
    // Validate input
    if (empty($username) || empty($password) || empty($confirmPassword)) {
        $error = "Please fill in all fields";
    } elseif ($password !== $confirmPassword) {
        $error = "Passwords do not match";
    } elseif ($role === 'operator' && empty($token)) {
        $error = "Admin registration requires a token";
    } elseif ($role === 'operator' && $token !== ADMIN_REGISTER_TOKEN) {
        $error = "Invalid admin token";
    } else {
        // Check if username already exists
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM users WHERE username = ?");
        $stmt->execute([$username]);
        $userExists = $stmt->fetchColumn() > 0;
        
        if ($userExists) {
            $error = "Username already exists";
        } else {
            // In a production environment, you should hash the password
            // $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
            
            // Insert new user
            $stmt = $pdo->prepare("INSERT INTO users (username, password, role) VALUES (?, ?, ?)");
            $stmt->execute([$username, $password, $role]); // Use $hashedPassword in production
            
            $success = $role === 'operator' ? "Admin account created successfully!" : "Account created successfully!";
            
            // Redirect to login after a short delay
            header("refresh:2;url=login.php");
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register - eCompro</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome for icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="assets/style.css">
    <style>
        body {
            background-color: #f8f9fa;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px 0;
            overflow-y: auto;
        }
        .register-container {
            max-width: 380px;
            width: 100%;
            padding: 10px;
            margin: 0 auto;
        }
        .register-logo {
            text-align: center;
            margin-bottom: 10px;
        }
        .register-logo h1 {
            font-weight: 700;
            color: #0d6efd;
            font-size: 1.7rem;
            margin-bottom: 0;
        }
        .register-form {
            background: white;
            padding: 15px;
            border-radius: 10px;
            box-shadow: 0 0.5rem 1rem rgba(0, 0, 0, 0.15);
        }
        .btn-register {
            font-weight: 600;
            padding: 6px;
        }
        .mb-4 {
            margin-bottom: 0.6rem !important;
        }
        .form-text {
            font-size: 0.75rem;
            margin-top: 0.1rem;
        }
        .input-group-text {
            padding: 0.375rem 0.5rem;
        }
        .form-control {
            padding: 0.375rem 0.5rem;
        }
        .token-field {
            display: none;
        }
    </style>
</head>
<body>
    <div class="register-container">
        <div class="register-logo">
            <h1>eCompro</h1>
            <p class="text-muted small">Create Account</p>
        </div>
        
        <div class="register-form">
            <?php if (!empty($error)): ?>
                <div class="alert alert-danger py-2" role="alert">
                    <small><?php echo $error; ?></small>
                </div>
            <?php endif; ?>
            
            <?php if (!empty($success)): ?>
                <div class="alert alert-success py-2" role="alert">
                    <small><?php echo $success; ?></small>
                </div>
            <?php endif; ?>
            
            <form method="POST" action="">
                <div class="mb-4">
                    <label for="username" class="form-label small mb-1">Username</label>
                    <div class="input-group input-group-sm">
                        <span class="input-group-text"><i class="fas fa-user"></i></span>
                        <input type="text" class="form-control" id="username" name="username" placeholder="Choose a username" required>
                    </div>
                </div>
                
                <div class="mb-4">
                    <label for="password" class="form-label small mb-1">Password</label>
                    <div class="input-group input-group-sm">
                        <span class="input-group-text"><i class="fas fa-lock"></i></span>
                        <input type="password" class="form-control" id="password" name="password" placeholder="Choose a password" required>
                    </div>
                </div>
                
                <div class="mb-4">
                    <label for="confirm_password" class="form-label small mb-1">Confirm Password</label>
                    <div class="input-group input-group-sm">
                        <span class="input-group-text"><i class="fas fa-lock"></i></span>
                        <input type="password" class="form-control" id="confirm_password" name="confirm_password" placeholder="Confirm your password" required>
                    </div>
                </div>
                
                <div class="mb-4">
                    <label for="role" class="form-label small mb-1">Account Type</label>
                    <select class="form-select form-select-sm" id="role" name="role">
                        <option value="user">Customer</option>
                        <option value="operator">Administrator</option>
                    </select>
                </div>
                
                <div class="mb-4 token-field" id="tokenField">
                    <label for="token" class="form-label small mb-1">Admin Token</label>
                    <div class="input-group input-group-sm">
                        <span class="input-group-text"><i class="fas fa-key"></i></span>
                        <input type="password" class="form-control" id="token" name="token" placeholder="Enter admin token">
                    </div>
                    <div class="form-text text-muted">
                        <small>Required for administrator registration</small>
                    </div>
                </div>
                
                <div class="d-grid">
                    <button type="submit" class="btn btn-primary btn-sm btn-register">
                        <i class="fas fa-user-plus me-1"></i> Create Account
                    </button>
                </div>
            </form>
            
            <div class="text-center mt-3">
                <p class="small mb-2">Already have an account? <a href="login.php" class="text-decoration-none">Login here</a></p>
                
                <hr class="my-2">
                
                <a href="index.php" class="text-decoration-none small">
                    <i class="fas fa-arrow-left me-1"></i> Back to Home
                </a>
            </div>
        </div>
    </div>
    
    <!-- Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    
    <script>
        // Show/hide token field based on role selection
        document.getElementById('role').addEventListener('change', function() {
            const tokenField = document.getElementById('tokenField');
            const tokenInput = document.getElementById('token');
            
            if (this.value === 'operator') {
                tokenField.style.display = 'block';
                tokenInput.setAttribute('required', 'required');
            } else {
                tokenField.style.display = 'none';
                tokenInput.removeAttribute('required');
            }
        });
    </script>
</body>
</html>
