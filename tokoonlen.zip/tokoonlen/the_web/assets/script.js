// Custom JavaScript for eCompro Admin Panel

document.addEventListener('DOMContentLoaded', function() {
    // Auto-dismiss alerts after 5 seconds
    const alerts = document.querySelectorAll('.alert');
    alerts.forEach(function(alert) {
        setTimeout(function() {
            const bsAlert = new bootstrap.Alert(alert);
            bsAlert.close();
        }, 5000);
    });

    // Toggle sidebar on mobile
    const sidebarToggler = document.querySelector('.navbar-toggler');
    if (sidebarToggler) {
        sidebarToggler.addEventListener('click', function() {
            document.querySelector('.sidebar').classList.toggle('show');
        });
    }

    // Image preview for file inputs
    const fileInputs = document.querySelectorAll('input[type="file"][accept*="image"]');
    fileInputs.forEach(function(input) {
        input.addEventListener('change', function(e) {
            const file = e.target.files[0];
            if (file) {
                const reader = new FileReader();
                reader.onload = function(event) {
                    // Find closest image preview or create one
                    let previewContainer = input.closest('.form-group, .mb-3').querySelector('.image-preview');
                    
                    if (!previewContainer) {
                        previewContainer = document.createElement('div');
                        previewContainer.className = 'image-preview mt-2';
                        input.parentNode.appendChild(previewContainer);
                    }
                    
                    previewContainer.innerHTML = `
                        <div class="card">
                            <div class="card-body text-center">
                                <img src="${event.target.result}" class="img-fluid" style="max-height: 200px;">
                                <p class="small text-muted mt-2">Preview of selected image</p>
                            </div>
                        </div>
                    `;
                };
                reader.readAsDataURL(file);
            }
        });
    });

    // Confirm delete actions
    const deleteButtons = document.querySelectorAll('[data-confirm]');
    deleteButtons.forEach(function(button) {
        button.addEventListener('click', function(e) {
            if (!confirm(this.dataset.confirm || 'Are you sure?')) {
                e.preventDefault();
            }
        });
    });
});
