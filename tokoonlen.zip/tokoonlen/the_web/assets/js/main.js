/**
 * Main JavaScript file for eCompro website
 */
document.addEventListener('DOMContentLoaded', function() {
    console.log('eCompro website loaded');
    
    // Initialize API client if needed
    if (typeof EcomproApiClient !== 'undefined') {
        window.api = new EcomproApiClient();
        console.log('API client initialized');
    }
    
    // Handle add to cart buttons
    const addToCartButtons = document.querySelectorAll('.add-to-cart');
    if (addToCartButtons.length > 0) {
        addToCartButtons.forEach(button => {
            button.addEventListener('click', function(e) {
                e.preventDefault();
                const productId = this.getAttribute('data-product-id');
                const quantity = document.querySelector(`#quantity-${productId}`) ? 
                    document.querySelector(`#quantity-${productId}`).value : 1;
                
                // If API client is available, use it
                if (window.api) {
                    addToCartViaApi(productId, quantity);
                } else {
                    // Otherwise use traditional form submission
                    window.location.href = `/ecompro/the_web/cart.php?add=${productId}&qty=${quantity}`;
                }
            });
        });
    }
    
    // API-based add to cart function
    function addToCartViaApi(productId, quantity) {
        fetch(`/ecompro/the_web/api/cart.php`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Accept': 'application/json'
            },
            body: JSON.stringify({
                product_id: productId,
                quantity: quantity
            }),
            credentials: 'same-origin'
        })
        .then(response => response.json())
        .then(data => {
            if (data.status === 'success') {
                showNotification('Product added to cart!', 'success');
                // Update cart count if exists
                const cartBadge = document.querySelector('.fa-shopping-basket + .badge');
                if (cartBadge) {
                    cartBadge.textContent = data.data.cart_count;
                    cartBadge.style.display = 'inline';
                }
            } else {
                showNotification(data.message, 'error');
            }
        })
        .catch(error => {
            console.error('Error:', error);
            showNotification('Could not add product to cart. Please try again.', 'error');
        });
    }
    
    // Show notification function
    function showNotification(message, type = 'info') {
        // Check if notification container exists, create if not
        let container = document.querySelector('.notification-container');
        if (!container) {
            container = document.createElement('div');
            container.className = 'notification-container';
            document.body.appendChild(container);
            
            // Add style for notifications if not already in CSS
            if (!document.getElementById('notification-style')) {
                const style = document.createElement('style');
                style.id = 'notification-style';
                style.textContent = `
                    .notification-container {
                        position: fixed;
                        top: 20px;
                        right: 20px;
                        z-index: 9999;
                    }
                    .notification {
                        padding: 15px 20px;
                        margin-bottom: 10px;
                        border-radius: 4px;
                        color: white;
                        width: 300px;
                        box-shadow: 0 4px 8px rgba(0,0,0,0.1);
                        animation: slideIn 0.3s ease-out forwards;
                    }
                    .notification.success {
                        background-color: #28a745;
                    }
                    .notification.error {
                        background-color: #dc3545;
                    }
                    .notification.info {
                        background-color: #17a2b8;
                    }
                    @keyframes slideIn {
                        from { transform: translateX(100%); opacity: 0; }
                        to { transform: translateX(0); opacity: 1; }
                    }
                    @keyframes fadeOut {
                        from { opacity: 1; }
                        to { opacity: 0; }
                    }
                `;
                document.head.appendChild(style);
            }
        }
        
        // Create notification element
        const notification = document.createElement('div');
        notification.className = `notification ${type}`;
        notification.textContent = message;
        
        // Add to container
        container.appendChild(notification);
        
        // Remove after 3 seconds
        setTimeout(() => {
            notification.style.animation = 'fadeOut 0.3s ease-out forwards';
            setTimeout(() => {
                notification.remove();
            }, 300);
        }, 3000);
    }
}); 