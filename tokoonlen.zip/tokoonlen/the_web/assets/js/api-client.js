/**
 * eCompro API Client - JavaScript edition
 * This client provides an easy way to interact with the eCompro API from frontend JavaScript code
 */
class EcomproApiClient {
    constructor() {
        this.baseUrl = '/ecompro/the_web/api';
    }

    /**
     * Send a request to the API
     * @param {string} endpoint - API endpoint
     * @param {string} method - HTTP method (GET, POST, PUT, DELETE)
     * @param {object} data - Data to send
     * @param {object} queryParams - Query parameters
     * @returns {Promise} - Promise resolving to the API response
     */
    async request(endpoint, method = 'GET', data = null, queryParams = {}) {
        // Build URL with query parameters
        let url = `${this.baseUrl}/${endpoint}`;
        const queryString = new URLSearchParams(queryParams).toString();
        if (queryString) {
            url += `?${queryString}`;
        }

        // Prepare fetch options
        const options = {
            method: method,
            headers: {
                'Content-Type': 'application/json',
                'Accept': 'application/json'
            },
            credentials: 'same-origin' // Include cookies for session authentication
        };

        // Add body data for POST/PUT requests
        if (data && (method === 'POST' || method === 'PUT')) {
            options.body = JSON.stringify(data);
        }

        try {
            const response = await fetch(url, options);
            const result = await response.json();
            return result;
        } catch (error) {
            console.error('API request error:', error);
            return {
                status: 'error',
                message: `Network error: ${error.message}`
            };
        }
    }

    // Convenience methods for different HTTP methods
    async get(endpoint, queryParams = {}) {
        return this.request(endpoint, 'GET', null, queryParams);
    }

    async post(endpoint, data, queryParams = {}) {
        return this.request(endpoint, 'POST', data, queryParams);
    }

    async put(endpoint, data, queryParams = {}) {
        return this.request(endpoint, 'PUT', data, queryParams);
    }

    async delete(endpoint, queryParams = {}) {
        return this.request(endpoint, 'DELETE', null, queryParams);
    }

    // Common API operations
    async getProducts(page = 1, limit = 10) {
        return this.get('products.php', { page, limit });
    }

    async getProduct(id) {
        return this.get('products.php', { id });
    }

    async searchProducts(query) {
        return this.get('products.php', { search: query });
    }

    async createProduct(productData) {
        return this.post('products.php', productData);
    }

    async updateProduct(id, productData) {
        return this.put('products.php', productData, { id });
    }

    async deleteProduct(id) {
        return this.delete('products.php', { id });
    }

    async getUserProfile() {
        return this.get('users.php', { profile: true });
    }

    async updateUserProfile(id, userData) {
        return this.put('users.php', userData, { id });
    }

    async login(credentials) {
        return this.post('users.php', credentials, { login: true });
    }

    async register(userData) {
        return this.post('users.php', userData, { register: true });
    }

    // Cart API Methods
    async getCart() {
        return this.get('cart.php');
    }

    async addToCart(productId, quantity = 1) {
        return this.post('cart.php', {
            product_id: productId,
            quantity: quantity
        });
    }

    async updateCartItem(productId, quantity) {
        return this.put('cart.php', { quantity }, { id: productId });
    }

    async removeFromCart(productId) {
        return this.delete('cart.php', { id: productId });
    }

    async clearCart() {
        return this.delete('cart.php', { clear: true });
    }
} 