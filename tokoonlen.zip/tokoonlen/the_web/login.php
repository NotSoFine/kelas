<?php
require_once 'db.php';
require_once 'admin/includes/config.php';

// Start session if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Check if already logged in
if (isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit;
} elseif (isset($_SESSION['admin_id'])) {
    header("Location: admin/index.php");
    exit;
}

$error = '';

// Handle login form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'] ?? '';
    $password = $_POST['password'] ?? '';
    $role = $_POST['role'] ?? 'user';
    $token = $_POST['token'] ?? '';
    
    if (empty($username) || empty($password)) {
        $error = "Please enter both username and password";
    } elseif ($role === 'operator' && empty($token)) {
        $error = "Admin login requires a token";
    } elseif ($role === 'operator' && $token !== ADMIN_REGISTER_TOKEN) {
        $error = "Invalid admin token";
    } else {
        // Query for user based on role
        $stmt = $pdo->prepare("SELECT * FROM users WHERE username = ? AND role = ? LIMIT 1");
        $stmt->execute([$username, $role]);
        $user = $stmt->fetch();
        
        if ($user && $password === $user['password']) { // In production, use password_verify()
            // Set session variables
            if ($role === 'operator') {
                $_SESSION['admin_id'] = $user['id'];
                $_SESSION['admin_username'] = $user['username'];
                $_SESSION['role'] = $user['role'];
                
                // Redirect to admin dashboard
                header("Location: admin/index.php");
                exit;
            } else {
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['username'] = $user['username'];
                $_SESSION['role'] = $user['role'];
                
                // Redirect to main page
                header("Location: index.php");
                exit;
            }
        } else {
            $error = "Invalid username or password";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - eCompro</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome for icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="assets/style.css">
    <style>
        body {
            background-color: #f8f9fa;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px 0;
            overflow-y: auto;
        }
        .login-container {
            max-width: 380px;
            width: 100%;
            padding: 15px;
            margin: 0 auto;
        }
        .login-logo {
            text-align: center;
            margin-bottom: 15px;
        }
        .login-logo h1 {
            font-weight: 700;
            color: #0d6efd;
            font-size: 1.7rem;
            margin-bottom: 0;
        }
        .login-form {
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0.5rem 1rem rgba(0, 0, 0, 0.15);
        }
        .btn-login {
            font-weight: 600;
            padding: 8px;
        }
        .mb-4 {
            margin-bottom: 0.8rem !important;
        }
        .token-field {
            display: none;
        }
    </style>
</head>
<body>
    <div class="login-container">
        <div class="login-logo">
            <h1>eCompro</h1>
            <p class="text-muted">Account Login</p>
        </div>
        
        <div class="login-form">
            <?php if (!empty($error)): ?>
                <div class="alert alert-danger" role="alert">
                    <?php echo $error; ?>
                </div>
            <?php endif; ?>
            
            <?php if (isset($_GET['logout'])): ?>
                <div class="alert alert-info" role="alert">
                    You have been logged out successfully.
                </div>
            <?php endif; ?>
            
            <form method="POST" action="">
                <div class="mb-4">
                    <label for="username" class="form-label">Username</label>
                    <div class="input-group">
                        <span class="input-group-text"><i class="fas fa-user"></i></span>
                        <input type="text" class="form-control" id="username" name="username" placeholder="Enter username" required>
                    </div>
                </div>
                
                <div class="mb-4">
                    <label for="password" class="form-label">Password</label>
                    <div class="input-group">
                        <span class="input-group-text"><i class="fas fa-lock"></i></span>
                        <input type="password" class="form-control" id="password" name="password" placeholder="Enter password" required>
                    </div>
                </div>
                
                <div class="mb-4">
                    <label for="role" class="form-label">Login As</label>
                    <select class="form-select" id="role" name="role">
                        <option value="user">Customer</option>
                        <option value="operator">Administrator</option>
                    </select>
                </div>
                
                <div class="mb-4 token-field" id="tokenField">
                    <label for="token" class="form-label">Admin Token</label>
                    <div class="input-group">
                        <span class="input-group-text"><i class="fas fa-key"></i></span>
                        <input type="password" class="form-control" id="token" name="token" placeholder="Enter admin token">
                    </div>
                    <div class="form-text text-muted">
                        <small>Required for administrator login</small>
                    </div>
                </div>
                
                <div class="d-grid">
                    <button type="submit" class="btn btn-primary btn-login">
                        <i class="fas fa-sign-in-alt me-2"></i> Login
                    </button>
                </div>
            </form>
            
            <div class="text-center mt-4">
                <div class="row">
                    <div class="col-6">
                        <a href="index.php" class="text-decoration-none">
                            <i class="fas fa-arrow-left me-1"></i> Back to Home
                        </a>
                    </div>
                    <div class="col-6">
                        <a href="register.php" class="text-decoration-none">
                            <i class="fas fa-user-plus me-1"></i> Register
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    
    <script>
        // Show/hide token field based on role selection
        document.getElementById('role').addEventListener('change', function() {
            const tokenField = document.getElementById('tokenField');
            const tokenInput = document.getElementById('token');
            
            if (this.value === 'operator') {
                tokenField.style.display = 'block';
                tokenInput.setAttribute('required', 'required');
            } else {
                tokenField.style.display = 'none';
                tokenInput.removeAttribute('required');
            }
        });
    </script>
</body>
</html>
