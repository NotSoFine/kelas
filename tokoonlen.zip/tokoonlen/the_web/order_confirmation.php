<?php
session_start();
include 'db.php';

// Redirect if no order ID in session
if (!isset($_SESSION['order_id']) || !isset($_SESSION['order_code'])) {
    header('Location: index.php');
    exit;
}

$order_id = $_SESSION['order_id'];
$order_code = $_SESSION['order_code'];

// Fetch order details
try {
    $stmt = $pdo->prepare("SELECT * FROM orders WHERE id = ?");
    $stmt->execute([$order_id]);
    $order = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$order) {
        header('Location: index.php');
        exit;
    }
    
    // Fetch order items
    $stmt = $pdo->prepare("SELECT * FROM order_items WHERE order_id = ?");
    $stmt->execute([$order_id]);
    $order_items = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
} catch (PDOException $e) {
    // Handle database error
    die("Error fetching order details: " . $e->getMessage());
}

// Calculate cart items count (for navbar)
$total_items = 0;
if (isset($_SESSION['cart'])) {
    foreach ($_SESSION['cart'] as $item) {
        $total_items += $item['quantity'];
    }
}

// Check if user is logged in
$isLoggedIn = isset($_SESSION['user_id']) || isset($_SESSION['admin_id']);
$username = $_SESSION['username'] ?? $_SESSION['admin_username'] ?? '';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Order Confirmation - EcomPro</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome for icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

    <style>
        .navbar-brand {
            font-weight: 700;
            font-size: 1.8rem;
            color: #0d6efd;
        }
        .confirmation-section {
            padding: 50px 0;
        }
        .order-details {
            background-color: #f8f9fa;
            border-radius: 0.25rem;
            padding: 20px;
        }
        .order-item {
            border-bottom: 1px solid #dee2e6;
            padding: 10px 0;
        }
        .order-item:last-child {
            border-bottom: none;
        }
        .total-line {
            border-top: 1px solid #dee2e6;
            padding-top: 10px;
            margin-top: 10px;
        }
        .grand-total {
            font-size: 1.2rem;
            font-weight: bold;
        }
        .success-icon {
            font-size: 5rem;
            color: #28a745;
        }
    </style>
</head>
<body>

<!-- Main Navbar -->
<nav class="navbar navbar-expand-lg navbar-light bg-white shadow-sm">
    <div class="container">
        <a class="navbar-brand" href="index.php">EcomPro</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav me-auto">
                <li class="nav-item">
                    <a class="nav-link" href="index.php">Home</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="catalog.php">Catalog</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="about.php">About</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="contact.php">Contact</a>
                </li>
            </ul>
            <ul class="navbar-nav">
                <?php if ($isLoggedIn): ?>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown">
                            <i class="fas fa-user-circle me-1"></i> <?php echo htmlspecialchars($username); ?>
                        </a>
                        <ul class="dropdown-menu dropdown-menu-end">
                            <?php if (isset($_SESSION['admin_id'])): ?>
                                <li><a class="dropdown-item" href="admin/index.php">Admin Dashboard</a></li>
                                <li><hr class="dropdown-divider"></li>
                            <?php endif; ?>
                            <li><a class="dropdown-item" href="profile.php">My Profile</a></li>
                            <li><a class="dropdown-item" href="orders.php">My Orders</a></li>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item" href="logout.php">Logout</a></li>
                        </ul>
                    </li>
                <?php else: ?>
                    <li class="nav-item">
                        <a class="nav-link" href="login.php">Login</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="register.php">Register</a>
                    </li>
                <?php endif; ?>
                <li class="nav-item">
                    <a class="nav-link" href="cart.php">
                        <i class="fas fa-shopping-cart"></i>
                        <?php if ($total_items > 0): ?>
                            <span class="badge rounded-pill bg-danger"><?php echo $total_items; ?></span>
                        <?php endif; ?>
                    </a>
                </li>
            </ul>
        </div>
    </div>
</nav>

<div class="container mt-4">
    <!-- Breadcrumb -->
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="index.php">Home</a></li>
            <li class="breadcrumb-item active" aria-current="page">Order Confirmation</li>
        </ol>
    </nav>
</div>

<!-- Order Confirmation Section -->
<section class="confirmation-section">
    <div class="container">
        <div class="text-center mb-5">
            <i class="fas fa-check-circle success-icon mb-3"></i>
            <h1>Thank You for Your Order!</h1>
            <p class="lead">Your order has been placed successfully.</p>
            <p>Order #: <strong><?php echo htmlspecialchars($order_code); ?></strong></p>
            <p>A confirmation email has been sent to your email address.</p>
        </div>
        
        <div class="row">
            <div class="col-lg-8 mx-auto">
                <div class="card mb-4">
                    <div class="card-header bg-primary text-white">
                        <h5 class="mb-0">Order Details</h5>
                    </div>
                    <div class="card-body">
                        <div class="row mb-4">
                            <div class="col-md-6">
                                <h6>Order Information</h6>
                                <p class="mb-1">Order Number: <?php echo htmlspecialchars($order_code); ?></p>
                                <p class="mb-1">Date: <?php echo date('F j, Y', strtotime($order['created_at'])); ?></p>
                                <p class="mb-1">Status: <span class="badge bg-warning text-dark"><?php echo ucfirst($order['status']); ?></span></p>
                                <p class="mb-1">Payment Method: <?php echo ucfirst(str_replace('_', ' ', $order['payment_method'])); ?></p>
                            </div>
                            <div class="col-md-6">
                                <h6>Shipping Information</h6>
                                <p class="mb-1">Method: <?php echo ucfirst($order['shipping_method']); ?> Shipping</p>
                                <p class="mb-1">Address:</p>
                                <p class="mb-0"><?php echo nl2br(htmlspecialchars($order['shipping_address'])); ?></p>
                            </div>
                        </div>
                        
                        <h6>Order Items</h6>
                        <div class="order-details">
                            <?php foreach ($order_items as $item): ?>
                                <div class="order-item">
                                    <div class="row">
                                        <div class="col-md-8">
                                            <h6 class="mb-1"><?php echo htmlspecialchars($item['product_name']); ?></h6>
                                            <p class="text-muted mb-0">Quantity: <?php echo $item['quantity']; ?></p>
                                        </div>
                                        <div class="col-md-4 text-md-end">
                                            <?php if ($item['discount'] > 0): ?>
                                                <p class="mb-0">
                                                    <span class="text-decoration-line-through text-muted">$<?php echo number_format($item['price'], 2); ?></span>
                                                    <span class="ms-2">$<?php echo number_format($item['price'] - $item['discount'], 2); ?></span>
                                                    <span class="d-block">Total: $<?php echo number_format(($item['price'] - $item['discount']) * $item['quantity'], 2); ?></span>
                                                </p>
                                            <?php else: ?>
                                                <p class="mb-0">
                                                    $<?php echo number_format($item['price'], 2); ?>
                                                    <span class="d-block">Total: $<?php echo number_format($item['price'] * $item['quantity'], 2); ?></span>
                                                </p>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                            
                            <div class="mt-3">
                                <div class="d-flex justify-content-between mb-2">
                                    <span>Subtotal</span>
                                    <span>$<?php echo number_format($order['total_amount'] - $order['shipping_fee'] - $order['tax_amount'], 2); ?></span>
                                </div>
                                <div class="d-flex justify-content-between mb-2">
                                    <span>Shipping</span>
                                    <span>$<?php echo number_format($order['shipping_fee'], 2); ?></span>
                                </div>
                                <div class="d-flex justify-content-between mb-2">
                                    <span>Tax</span>
                                    <span>$<?php echo number_format($order['tax_amount'], 2); ?></span>
                                </div>
                                <div class="d-flex justify-content-between total-line grand-total">
                                    <span>Total</span>
                                    <span>$<?php echo number_format($order['total_amount'], 2); ?></span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="text-center">
                    <a href="index.php" class="btn btn-primary me-2">Continue Shopping</a>
                    <a href="orders.php" class="btn btn-outline-secondary">View All Orders</a>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Footer -->
<footer class="bg-dark text-white mt-5 py-4">
    <div class="container">
        <div class="row">
            <div class="col-md-4">
                <h5>EcomPro</h5>
                <p>Your one-stop shop for quality products.</p>
            </div>
            <div class="col-md-4">
                <h5>Quick Links</h5>
                <ul class="list-unstyled">
                    <li><a href="index.php" class="text-white">Home</a></li>
                    <li><a href="catalog.php" class="text-white">Catalog</a></li>
                    <li><a href="about.php" class="text-white">About Us</a></li>
                    <li><a href="contact.php" class="text-white">Contact</a></li>
                </ul>
            </div>
            <div class="col-md-4">
                <h5>Contact Us</h5>
                <address>
                    <p><i class="fas fa-map-marker-alt me-2"></i> 123 Main St, City</p>
                    <p><i class="fas fa-phone me-2"></i> (123) 456-7890</p>
                    <p><i class="fas fa-envelope me-2"></i> info@ecompro.com</p>
                </address>
            </div>
        </div>
        <hr>
        <div class="text-center">
            <p>&copy; <?php echo date('Y'); ?> EcomPro. All rights reserved.</p>
        </div>
    </div>
</footer>

<!-- Bootstrap Bundle with Popper -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html> 