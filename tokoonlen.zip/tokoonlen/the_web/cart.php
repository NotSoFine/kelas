<?php
session_start();
include 'db.php';

// Initialize cart if it doesn't exist
if (!isset($_SESSION['cart'])) {
    $_SESSION['cart'] = [];
}

// Handle cart updates
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Add to cart (direct from index page)
    if (isset($_POST['add_to_cart']) && isset($_POST['product_id'])) {
        $product_id = $_POST['product_id'];
        $quantity = isset($_POST['quantity']) ? (int)$_POST['quantity'] : 1;
        
        // Fetch product data
        $stmt = $pdo->prepare("SELECT * FROM products WHERE id = ?");
        $stmt->execute([$product_id]);
        $product = $stmt->fetch();
        
        if (!$product) {
            header("Location: index.php");
            exit;
        }
        
        if ($quantity <= 0) {
            $quantity = 1;
        }
        
        if ($quantity > $product['stock']) {
            $quantity = $product['stock'];
        }
        
        // Initialize cart in session if it doesn't exist
        if (!isset($_SESSION['cart'])) {
            $_SESSION['cart'] = [];
        }
        
        // Check if product already in cart
        $found = false;
        foreach ($_SESSION['cart'] as &$item) {
            if ($item['id'] == $product_id) {
                $item['quantity'] += $quantity;
                $found = true;
                break;
            }
        }
        
        // Add new product to cart if not found
        if (!$found) {
            $_SESSION['cart'][] = [
                'id' => $product_id,
                'name' => $product['name'],
                'price' => $product['price'],
                'discount' => $product['discount'],
                'image' => $product['image'],
                'quantity' => $quantity
            ];
        }
        
        // Redirect to cart page with success message
        header("Location: cart.php?added=1");
        exit;
    }
    
    // Remove item from cart
    if (isset($_POST['remove_item']) && isset($_POST['item_id'])) {
        $item_id = $_POST['item_id'];
        foreach ($_SESSION['cart'] as $key => $item) {
            if ($item['id'] == $item_id) {
                unset($_SESSION['cart'][$key]);
                break;
            }
        }
        // Reindex the array
        $_SESSION['cart'] = array_values($_SESSION['cart']);
    }
    
    // Update quantities
    if (isset($_POST['update_cart'])) {
        foreach ($_POST['quantity'] as $id => $quantity) {
            $quantity = (int)$quantity;
            if ($quantity <= 0) {
                // Remove item if quantity is 0 or negative
                foreach ($_SESSION['cart'] as $key => $item) {
                    if ($item['id'] == $id) {
                        unset($_SESSION['cart'][$key]);
                        break;
                    }
                }
            } else {
                // Update quantity
                foreach ($_SESSION['cart'] as &$item) {
                    if ($item['id'] == $id) {
                        // Check stock availability
                        $stmt = $pdo->prepare("SELECT stock FROM products WHERE id = ?");
                        $stmt->execute([$id]);
                        $product = $stmt->fetch();
                        
                        if ($product && $quantity > $product['stock']) {
                            $quantity = $product['stock'];
                        }
                        
                        $item['quantity'] = $quantity;
                        break;
                    }
                }
            }
        }
        // Reindex the array
        $_SESSION['cart'] = array_values($_SESSION['cart']);
    }
    
    // Clear cart
    if (isset($_POST['clear_cart'])) {
        $_SESSION['cart'] = [];
    }
    
    // Redirect to avoid form resubmission
    header("Location: cart.php?updated=1");
    exit;
}

// Calculate cart totals
$subtotal = 0;
$total_items = 0;

foreach ($_SESSION['cart'] as $item) {
    $item_price = $item['price'] - $item['discount'];
    $subtotal += $item_price * $item['quantity'];
    $total_items += $item['quantity'];
}

// Check if user is logged in
$isLoggedIn = isset($_SESSION['user_id']) || isset($_SESSION['admin_id']);
$username = $_SESSION['username'] ?? $_SESSION['admin_username'] ?? '';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Shopping Cart - EcomPro</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome for icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <style>
        .cart-item-img {
            width: 80px;
            height: 80px;
            object-fit: cover;
        }
        .strike {
            text-decoration: line-through;
            color: gray;
        }
        .quantity-input {
            width: 70px;
        }
    </style>
</head>
<body>

<!-- Main Navbar -->
<nav class="navbar navbar-expand-lg navbar-light bg-white shadow-sm">
    <div class="container">
        <a class="navbar-brand" href="index.php">EcomPro</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav me-auto">
                <li class="nav-item">
                    <a class="nav-link" href="index.php">Home</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="catalog.php">Catalog</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="about.php">About</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="contact.php">Contact</a>
                </li>
            </ul>
            <ul class="navbar-nav">
                <?php if ($isLoggedIn): ?>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown">
                            <i class="fas fa-user-circle me-1"></i> <?php echo htmlspecialchars($username); ?>
                        </a>
                        <ul class="dropdown-menu dropdown-menu-end">
                            <?php if (isset($_SESSION['admin_id'])): ?>
                                <li><a class="dropdown-item" href="admin/index.php">Admin Dashboard</a></li>
                                <li><hr class="dropdown-divider"></li>
                            <?php endif; ?>
                            <li><a class="dropdown-item" href="profile.php">My Profile</a></li>
                            <li><a class="dropdown-item" href="orders.php">My Orders</a></li>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item" href="logout.php">Logout</a></li>
                        </ul>
                    </li>
                <?php else: ?>
                    <li class="nav-item">
                        <a class="nav-link" href="login.php">Login</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="register.php">Register</a>
                    </li>
                <?php endif; ?>
                <li class="nav-item">
                    <a class="nav-link active" href="cart.php">
                        <i class="fas fa-shopping-cart"></i>
                        <?php if ($total_items > 0): ?>
                            <span class="badge rounded-pill bg-danger"><?php echo $total_items; ?></span>
                        <?php endif; ?>
                    </a>
                </li>
            </ul>
        </div>
    </div>
</nav>

<div class="container mt-4">
    <!-- Breadcrumb -->
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="index.php">Home</a></li>
            <li class="breadcrumb-item active" aria-current="page">Shopping Cart</li>
        </ol>
    </nav>
    
    <?php if (isset($_GET['updated'])): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            Cart updated successfully!
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>
    
    <?php if (isset($_GET['added'])): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            Product added to cart successfully!
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>
    
    <h2 class="mb-4">Your Shopping Cart</h2>
    
    <?php if (empty($_SESSION['cart'])): ?>
        <div class="alert alert-info">
            Your cart is empty. <a href="index.php" class="alert-link">Continue shopping</a>.
        </div>
    <?php else: ?>
        <form action="" method="POST">
            <div class="table-responsive">
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th>Product</th>
                            <th>Price</th>
                            <th>Quantity</th>
                            <th>Total</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($_SESSION['cart'] as $item): ?>
                            <?php 
                                $item_price = $item['price'] - $item['discount'];
                                $item_total = $item_price * $item['quantity'];
                            ?>
                            <tr>
                                <td>
                                    <div class="d-flex align-items-center">
                                        <img src="<?php echo htmlspecialchars($item['image']); ?>" alt="<?php echo htmlspecialchars($item['name']); ?>" class="cart-item-img me-3">
                                        <div>
                                            <h6 class="mb-0"><a href="product_detail.php?id=<?php echo $item['id']; ?>" class="text-decoration-none"><?php echo htmlspecialchars($item['name']); ?></a></h6>
                                        </div>
                                    </div>
                                </td>
                                <td>
                                    <?php if ($item['discount'] > 0): ?>
                                        <span class="strike">$<?php echo number_format($item['price'], 2); ?></span>
                                        <span class="text-danger">$<?php echo number_format($item_price, 2); ?></span>
                                    <?php else: ?>
                                        $<?php echo number_format($item_price, 2); ?>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <input type="number" name="quantity[<?php echo $item['id']; ?>]" value="<?php echo $item['quantity']; ?>" min="0" class="form-control quantity-input">
                                </td>
                                <td>$<?php echo number_format($item_total, 2); ?></td>
                                <td>
                                    <button type="submit" name="remove_item" value="1" class="btn btn-sm btn-outline-danger" onclick="this.form.item_id.value=<?php echo $item['id']; ?>">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                    <tfoot>
                        <tr>
                            <td colspan="3" class="text-end"><strong>Subtotal:</strong></td>
                            <td><strong>$<?php echo number_format($subtotal, 2); ?></strong></td>
                            <td></td>
                        </tr>
                    </tfoot>
                </table>
            </div>
            
            <input type="hidden" name="item_id" value="">
            
            <div class="d-flex justify-content-between mt-3">
                <div>
                    <button type="submit" name="clear_cart" value="1" class="btn btn-outline-secondary" onclick="return confirm('Are you sure you want to clear your cart?')">
                        <i class="fas fa-trash me-2"></i> Clear Cart
                    </button>
                </div>
                <div>
                    <a href="index.php" class="btn btn-outline-primary me-2">
                        <i class="fas fa-arrow-left me-2"></i> Continue Shopping
                    </a>
                    <button type="submit" name="update_cart" value="1" class="btn btn-outline-success me-2">
                        <i class="fas fa-sync-alt me-2"></i> Update Cart
                    </button>
                    <a href="checkout.php" class="btn btn-primary">
                        <i class="fas fa-shopping-bag me-2"></i> Checkout
                    </a>
                </div>
            </div>
        </form>
    <?php endif; ?>
</div>

<!-- Footer -->
<footer class="bg-dark text-white mt-5 py-4">
    <div class="container">
        <div class="row">
            <div class="col-md-4">
                <h5>EcomPro</h5>
                <p>Your one-stop shop for quality products.</p>
            </div>
            <div class="col-md-4">
                <h5>Quick Links</h5>
                <ul class="list-unstyled">
                    <li><a href="index.php" class="text-white">Home</a></li>
                    <li><a href="catalog.php" class="text-white">Catalog</a></li>
                    <li><a href="about.php" class="text-white">About Us</a></li>
                    <li><a href="contact.php" class="text-white">Contact</a></li>
                </ul>
            </div>
            <div class="col-md-4">
                <h5>Contact Us</h5>
                <address>
                    <p><i class="fas fa-map-marker-alt me-2"></i> 123 Main St, City</p>
                    <p><i class="fas fa-phone me-2"></i> (123) 456-7890</p>
                    <p><i class="fas fa-envelope me-2"></i> info@ecompro.com</p>
                </address>
            </div>
        </div>
        <hr>
        <div class="text-center">
            <p>&copy; <?php echo date('Y'); ?> EcomPro. All rights reserved.</p>
        </div>
    </div>
</footer>

<!-- Bootstrap Bundle with Popper -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html> 