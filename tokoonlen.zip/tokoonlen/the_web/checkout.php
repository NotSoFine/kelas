<?php
session_start();
include 'db.php';

// Redirect to login if not logged in
if (!isset($_SESSION['user_id'])) {
    $_SESSION['redirect_after_login'] = 'checkout.php';
    header('Location: login.php');
    exit;
}

// Redirect to cart if cart is empty
if (!isset($_SESSION['cart']) || count($_SESSION['cart']) === 0) {
    header('Location: cart.php');
    exit;
}

// Get user information
$user_id = $_SESSION['user_id'];
$stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
$stmt->execute([$user_id]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

// Initialize variables
$shipping_address = $user['address'] ?? '';
$billing_address = $user['address'] ?? '';
$payment_method = '';
$shipping_method = '';
$notes = '';
$errors = [];
$success = false;

// Calculate cart totals
$subtotal = 0;
$total_items = 0;
foreach ($_SESSION['cart'] as $item) {
    $subtotal += ($item['price'] - $item['discount']) * $item['quantity'];
    $total_items += $item['quantity'];
}

// Set default shipping fee and tax rate
$shipping_fee = 10.00; // Default shipping fee
$tax_rate = 0.05; // 5% tax rate
$tax_amount = $subtotal * $tax_rate;
$total_amount = $subtotal + $shipping_fee + $tax_amount;

// Process checkout form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Validate shipping address
    if (empty($_POST['shipping_address'])) {
        $errors['shipping_address'] = 'Shipping address is required';
    } else {
        $shipping_address = filter_var($_POST['shipping_address'], FILTER_SANITIZE_FULL_SPECIAL_CHARS);
    }
    
    // Validate billing address
    if (empty($_POST['billing_address'])) {
        $errors['billing_address'] = 'Billing address is required';
    } else {
        $billing_address = filter_var($_POST['billing_address'], FILTER_SANITIZE_FULL_SPECIAL_CHARS);
    }
    
    // Validate payment method
    if (empty($_POST['payment_method'])) {
        $errors['payment_method'] = 'Payment method is required';
    } else {
        $payment_method = filter_var($_POST['payment_method'], FILTER_SANITIZE_FULL_SPECIAL_CHARS);
    }
    
    // Validate shipping method
    if (empty($_POST['shipping_method'])) {
        $errors['shipping_method'] = 'Shipping method is required';
    } else {
        $shipping_method = filter_var($_POST['shipping_method'], FILTER_SANITIZE_FULL_SPECIAL_CHARS);
        
        // Adjust shipping fee based on selected method
        if ($shipping_method === 'standard') {
            $shipping_fee = 10.00;
        } elseif ($shipping_method === 'express') {
            $shipping_fee = 20.00;
        } elseif ($shipping_method === 'overnight') {
            $shipping_fee = 30.00;
        }
        
        // Recalculate total with updated shipping fee
        $total_amount = $subtotal + $shipping_fee + $tax_amount;
    }
    
    // Get optional notes
    $notes = filter_var($_POST['notes'] ?? '', FILTER_SANITIZE_FULL_SPECIAL_CHARS);
    
    // Check if the orders table exists with the correct structure
    try {
        $stmt = $pdo->query("SHOW TABLES LIKE 'orders'");
        $ordersTableExists = $stmt->fetch();
        
        if (!$ordersTableExists) {
            // Redirect to database fix page if orders table doesn't exist
            header('Location: fix_database.php');
            exit;
        }
        
        // Check if the orders table has the required columns
        $stmt = $pdo->query("SHOW COLUMNS FROM orders LIKE 'order_code'");
        $orderCodeColumnExists = $stmt->fetch();
        
        if (!$orderCodeColumnExists) {
            // Redirect to database fix page if orders table structure is incorrect
            header('Location: fix_database.php');
            exit;
        }
    } catch (PDOException $e) {
        // Redirect to database fix page on any database error
        header('Location: fix_database.php');
        exit;
    }
    
    // If no errors, process the order
    if (empty($errors)) {
        try {
            // Start transaction
            $pdo->beginTransaction();
            
            // Generate unique order code
            $order_code = 'ORD-' . strtoupper(substr(md5(uniqid(mt_rand(), true)), 0, 8));
            
            // Insert order into database
            $stmt = $pdo->prepare("INSERT INTO orders (order_code, user_id, total_amount, status, shipping_address, billing_address, payment_method, shipping_method, shipping_fee, tax_amount, notes) VALUES (?, ?, ?, 'pending', ?, ?, ?, ?, ?, ?, ?)");
            
            $stmt->execute([
                $order_code,
                $user_id,
                $total_amount,
                $shipping_address,
                $billing_address,
                $payment_method,
                $shipping_method,
                $shipping_fee,
                $tax_amount,
                $notes
            ]);
            
            $order_id = $pdo->lastInsertId();
            
            // Insert order items
            $stmt = $pdo->prepare("INSERT INTO order_items (order_id, product_id, product_name, quantity, price, discount) VALUES (?, ?, ?, ?, ?, ?)");
            
            foreach ($_SESSION['cart'] as $item) {
                $stmt->execute([
                    $order_id,
                    $item['id'],
                    $item['name'],
                    $item['quantity'],
                    $item['price'],
                    $item['discount']
                ]);
                
                // Update product stock (optional)
                $update_stock = $pdo->prepare("UPDATE products SET stock = stock - ? WHERE id = ? AND stock >= ?");
                $update_stock->execute([$item['quantity'], $item['id'], $item['quantity']]);
            }
            
            // Commit transaction
            $pdo->commit();
            
            // Clear the cart
            unset($_SESSION['cart']);
            
            // Set success flag and store order ID for confirmation page
            $_SESSION['order_id'] = $order_id;
            $_SESSION['order_code'] = $order_code;
            
            // Redirect to order confirmation page
            header('Location: order_confirmation.php');
            exit;
            
        } catch (PDOException $e) {
            // Rollback transaction on error
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            $errors['db'] = 'An error occurred while processing your order: ' . $e->getMessage();
        }
    }
}

// Check if user is logged in
$isLoggedIn = isset($_SESSION['user_id']) || isset($_SESSION['admin_id']);
$username = $_SESSION['username'] ?? $_SESSION['admin_username'] ?? '';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Checkout - EcomPro</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome for icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

    <style>
        .navbar-brand {
            font-weight: 700;
            font-size: 1.8rem;
            color: #0d6efd;
        }
        .checkout-section {
            padding: 30px 0;
        }
        .order-summary {
            background-color: #f8f9fa;
            border-radius: 0.25rem;
            padding: 20px;
        }
        .total-line {
            border-top: 1px solid #dee2e6;
            padding-top: 10px;
            margin-top: 10px;
        }
        .grand-total {
            font-size: 1.2rem;
            font-weight: bold;
        }
    </style>
</head>
<body>

<!-- Main Navbar -->
<nav class="navbar navbar-expand-lg navbar-light bg-white shadow-sm">
    <div class="container">
        <a class="navbar-brand" href="index.php">EcomPro</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav me-auto">
                <li class="nav-item">
                    <a class="nav-link" href="index.php">Home</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="catalog.php">Catalog</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="about.php">About</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="contact.php">Contact</a>
                </li>
            </ul>
            <ul class="navbar-nav">
                <?php if ($isLoggedIn): ?>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown">
                            <i class="fas fa-user-circle me-1"></i> <?php echo htmlspecialchars($username); ?>
                        </a>
                        <ul class="dropdown-menu dropdown-menu-end">
                            <?php if (isset($_SESSION['admin_id'])): ?>
                                <li><a class="dropdown-item" href="admin/index.php">Admin Dashboard</a></li>
                                <li><hr class="dropdown-divider"></li>
                            <?php endif; ?>
                            <li><a class="dropdown-item" href="profile.php">My Profile</a></li>
                            <li><a class="dropdown-item" href="orders.php">My Orders</a></li>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item" href="logout.php">Logout</a></li>
                        </ul>
                    </li>
                <?php else: ?>
                    <li class="nav-item">
                        <a class="nav-link" href="login.php">Login</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="register.php">Register</a>
                    </li>
                <?php endif; ?>
                <li class="nav-item">
                    <a class="nav-link" href="cart.php">
                        <i class="fas fa-shopping-cart"></i>
                        <?php if ($total_items > 0): ?>
                            <span class="badge rounded-pill bg-danger"><?php echo $total_items; ?></span>
                        <?php endif; ?>
                    </a>
                </li>
            </ul>
        </div>
    </div>
</nav>

<div class="container mt-4">
    <!-- Breadcrumb -->
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="index.php">Home</a></li>
            <li class="breadcrumb-item"><a href="cart.php">Cart</a></li>
            <li class="breadcrumb-item active" aria-current="page">Checkout</li>
        </ol>
    </nav>
</div>

<!-- Checkout Section -->
<section class="checkout-section">
    <div class="container">
        <h1 class="mb-4">Checkout</h1>
        
        <?php if (isset($errors['db'])): ?>
            <div class="alert alert-danger" role="alert">
                <?php echo $errors['db']; ?>
            </div>
        <?php endif; ?>
        
        <div class="row">
            <!-- Checkout Form -->
            <div class="col-lg-8">
                <form action="" method="POST" novalidate>
                    <!-- Shipping Information -->
                    <div class="card mb-4">
                        <div class="card-header bg-primary text-white">
                            <h5 class="mb-0">Shipping Information</h5>
                        </div>
                        <div class="card-body">
                            <div class="mb-3">
                                <label for="shipping_address" class="form-label">Shipping Address</label>
                                <textarea class="form-control <?php echo isset($errors['shipping_address']) ? 'is-invalid' : ''; ?>" id="shipping_address" name="shipping_address" rows="3" required><?php echo htmlspecialchars($shipping_address); ?></textarea>
                                <?php if (isset($errors['shipping_address'])): ?>
                                    <div class="invalid-feedback"><?php echo $errors['shipping_address']; ?></div>
                                <?php endif; ?>
                            </div>
                            
                            <div class="mb-3">
                                <label for="shipping_method" class="form-label">Shipping Method</label>
                                <select class="form-select <?php echo isset($errors['shipping_method']) ? 'is-invalid' : ''; ?>" id="shipping_method" name="shipping_method" required>
                                    <option value="" disabled <?php echo empty($shipping_method) ? 'selected' : ''; ?>>Select shipping method</option>
                                    <option value="standard" <?php echo $shipping_method === 'standard' ? 'selected' : ''; ?>>Standard Shipping ($10.00) - 3-5 business days</option>
                                    <option value="express" <?php echo $shipping_method === 'express' ? 'selected' : ''; ?>>Express Shipping ($20.00) - 2-3 business days</option>
                                    <option value="overnight" <?php echo $shipping_method === 'overnight' ? 'selected' : ''; ?>>Overnight Shipping ($30.00) - 1 business day</option>
                                </select>
                                <?php if (isset($errors['shipping_method'])): ?>
                                    <div class="invalid-feedback"><?php echo $errors['shipping_method']; ?></div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Billing Information -->
                    <div class="card mb-4">
                        <div class="card-header bg-primary text-white">
                            <h5 class="mb-0">Billing Information</h5>
                        </div>
                        <div class="card-body">
                            <div class="mb-3 form-check">
                                <input type="checkbox" class="form-check-input" id="same_as_shipping" checked>
                                <label class="form-check-label" for="same_as_shipping">Same as shipping address</label>
                            </div>
                            
                            <div id="billing_address_container" class="mb-3" style="display: none;">
                                <label for="billing_address" class="form-label">Billing Address</label>
                                <textarea class="form-control <?php echo isset($errors['billing_address']) ? 'is-invalid' : ''; ?>" id="billing_address" name="billing_address" rows="3"><?php echo htmlspecialchars($billing_address); ?></textarea>
                                <?php if (isset($errors['billing_address'])): ?>
                                    <div class="invalid-feedback"><?php echo $errors['billing_address']; ?></div>
                                <?php endif; ?>
                            </div>
                            <input type="hidden" id="billing_address_hidden" name="billing_address" value="<?php echo htmlspecialchars($billing_address); ?>">
                        </div>
                    </div>
                    
                    <!-- Payment Information -->
                    <div class="card mb-4">
                        <div class="card-header bg-primary text-white">
                            <h5 class="mb-0">Payment Method</h5>
                        </div>
                        <div class="card-body">
                            <div class="mb-3">
                                <div class="form-check mb-2">
                                    <input class="form-check-input" type="radio" name="payment_method" id="credit_card" value="credit_card" <?php echo $payment_method === 'credit_card' ? 'checked' : ''; ?> required>
                                    <label class="form-check-label" for="credit_card">
                                        <i class="fab fa-cc-visa me-2"></i>
                                        <i class="fab fa-cc-mastercard me-2"></i>
                                        <i class="fab fa-cc-amex me-2"></i>
                                        Credit Card
                                    </label>
                                </div>
                                <div class="form-check mb-2">
                                    <input class="form-check-input" type="radio" name="payment_method" id="paypal" value="paypal" <?php echo $payment_method === 'paypal' ? 'checked' : ''; ?>>
                                    <label class="form-check-label" for="paypal">
                                        <i class="fab fa-paypal me-2"></i>
                                        PayPal
                                    </label>
                                </div>
                                <div class="form-check">
                                    <input class="form-check-input" type="radio" name="payment_method" id="cash_on_delivery" value="cash_on_delivery" <?php echo $payment_method === 'cash_on_delivery' ? 'checked' : ''; ?>>
                                    <label class="form-check-label" for="cash_on_delivery">
                                        <i class="fas fa-money-bill-wave me-2"></i>
                                        Cash on Delivery
                                    </label>
                                </div>
                                <?php if (isset($errors['payment_method'])): ?>
                                    <div class="text-danger mt-2"><?php echo $errors['payment_method']; ?></div>
                                <?php endif; ?>
                            </div>
                            
                            <div id="credit_card_details" class="mt-3" style="display: none;">
                                <!-- In a real application, you would integrate with a payment gateway -->
                                <div class="alert alert-info">
                                    <p class="mb-0">This is a demo checkout. No actual payment will be processed.</p>
                                </div>
                                
                                <div class="row">
                                    <div class="col-md-6 mb-3">
                                        <label for="card_number" class="form-label">Card Number</label>
                                        <input type="text" class="form-control" id="card_number" placeholder="1234 5678 9012 3456">
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <label for="card_name" class="form-label">Name on Card</label>
                                        <input type="text" class="form-control" id="card_name" placeholder="John Doe">
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-6 mb-3">
                                        <label for="expiry_date" class="form-label">Expiry Date</label>
                                        <input type="text" class="form-control" id="expiry_date" placeholder="MM/YY">
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <label for="cvv" class="form-label">CVV</label>
                                        <input type="text" class="form-control" id="cvv" placeholder="123">
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Additional Information -->
                    <div class="card mb-4">
                        <div class="card-header bg-primary text-white">
                            <h5 class="mb-0">Additional Information</h5>
                        </div>
                        <div class="card-body">
                            <div class="mb-3">
                                <label for="notes" class="form-label">Order Notes (Optional)</label>
                                <textarea class="form-control" id="notes" name="notes" rows="3" placeholder="Special instructions for delivery, etc."><?php echo htmlspecialchars($notes); ?></textarea>
                            </div>
                        </div>
                    </div>
                    
                    <div class="d-grid gap-2">
                        <button type="submit" class="btn btn-primary btn-lg">Place Order</button>
                        <a href="cart.php" class="btn btn-outline-secondary">Return to Cart</a>
                    </div>
                </form>
            </div>
            
            <!-- Order Summary -->
            <div class="col-lg-4 mt-4 mt-lg-0">
                <div class="order-summary sticky-top" style="top: 20px;">
                    <h4 class="mb-3">Order Summary</h4>
                    
                    <div class="card mb-3">
                        <div class="card-header bg-light">
                            <h5 class="mb-0">Items (<?php echo $total_items; ?>)</h5>
                        </div>
                        <div class="card-body">
                            <?php foreach ($_SESSION['cart'] as $item): ?>
                                <div class="d-flex justify-content-between mb-2">
                                    <div>
                                        <span class="fw-bold"><?php echo htmlspecialchars($item['name']); ?></span>
                                        <br>
                                        <small class="text-muted">Qty: <?php echo $item['quantity']; ?></small>
                                    </div>
                                    <div class="text-end">
                                        <?php if ($item['discount'] > 0): ?>
                                            <span class="text-decoration-line-through text-muted">$<?php echo number_format($item['price'], 2); ?></span>
                                            <br>
                                            <span>$<?php echo number_format(($item['price'] - $item['discount']) * $item['quantity'], 2); ?></span>
                                        <?php else: ?>
                                            <span>$<?php echo number_format($item['price'] * $item['quantity'], 2); ?></span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                    
                    <div class="card">
                        <div class="card-body">
                            <div class="d-flex justify-content-between mb-2">
                                <span>Subtotal</span>
                                <span>$<?php echo number_format($subtotal, 2); ?></span>
                            </div>
                            <div class="d-flex justify-content-between mb-2">
                                <span>Shipping</span>
                                <span>$<?php echo number_format($shipping_fee, 2); ?></span>
                            </div>
                            <div class="d-flex justify-content-between mb-2">
                                <span>Tax (5%)</span>
                                <span>$<?php echo number_format($tax_amount, 2); ?></span>
                            </div>
                            <div class="d-flex justify-content-between total-line grand-total">
                                <span>Total</span>
                                <span>$<?php echo number_format($total_amount, 2); ?></span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Footer -->
<footer class="bg-dark text-white mt-5 py-4">
    <div class="container">
        <div class="row">
            <div class="col-md-4">
                <h5>EcomPro</h5>
                <p>Your one-stop shop for quality products.</p>
            </div>
            <div class="col-md-4">
                <h5>Quick Links</h5>
                <ul class="list-unstyled">
                    <li><a href="index.php" class="text-white">Home</a></li>
                    <li><a href="catalog.php" class="text-white">Catalog</a></li>
                    <li><a href="about.php" class="text-white">About Us</a></li>
                    <li><a href="contact.php" class="text-white">Contact</a></li>
                </ul>
            </div>
            <div class="col-md-4">
                <h5>Contact Us</h5>
                <address>
                    <p><i class="fas fa-map-marker-alt me-2"></i> 123 Main St, City</p>
                    <p><i class="fas fa-phone me-2"></i> (123) 456-7890</p>
                    <p><i class="fas fa-envelope me-2"></i> info@ecompro.com</p>
                </address>
            </div>
        </div>
        <hr>
        <div class="text-center">
            <p>&copy; <?php echo date('Y'); ?> EcomPro. All rights reserved.</p>
        </div>
    </div>
</footer>

<!-- Bootstrap Bundle with Popper -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        // Handle "Same as shipping" checkbox
        const sameAsShippingCheckbox = document.getElementById('same_as_shipping');
        const billingAddressContainer = document.getElementById('billing_address_container');
        const billingAddressTextarea = document.getElementById('billing_address');
        const billingAddressHidden = document.getElementById('billing_address_hidden');
        const shippingAddressTextarea = document.getElementById('shipping_address');
        
        function updateBillingAddress() {
            if (sameAsShippingCheckbox.checked) {
                billingAddressContainer.style.display = 'none';
                billingAddressHidden.value = shippingAddressTextarea.value;
            } else {
                billingAddressContainer.style.display = 'block';
                billingAddressHidden.value = billingAddressTextarea.value;
            }
        }
        
        sameAsShippingCheckbox.addEventListener('change', updateBillingAddress);
        shippingAddressTextarea.addEventListener('input', function() {
            if (sameAsShippingCheckbox.checked) {
                billingAddressHidden.value = this.value;
            }
        });
        
        billingAddressTextarea.addEventListener('input', function() {
            billingAddressHidden.value = this.value;
        });
        
        // Initial setup
        updateBillingAddress();
        
        // Handle payment method selection
        const creditCardRadio = document.getElementById('credit_card');
        const creditCardDetails = document.getElementById('credit_card_details');
        
        function updatePaymentDetails() {
            creditCardDetails.style.display = creditCardRadio.checked ? 'block' : 'none';
        }
        
        document.querySelectorAll('input[name="payment_method"]').forEach(function(radio) {
            radio.addEventListener('change', updatePaymentDetails);
        });
        
        // Initial setup
        updatePaymentDetails();
    });
</script>

</body>
</html> 