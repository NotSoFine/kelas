<?php
session_start();
include 'db.php';

// Calculate cart items count
$total_items = 0;
if (isset($_SESSION['cart'])) {
    foreach ($_SESSION['cart'] as $item) {
        $total_items += $item['quantity'];
    }
}

// Check if user is logged in
$isLoggedIn = isset($_SESSION['user_id']) || isset($_SESSION['admin_id']);
$username = $_SESSION['username'] ?? $_SESSION['admin_username'] ?? '';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>About Us - EcomPro</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome for icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

    <style>
        .navbar-brand {
            font-weight: 700;
            font-size: 1.8rem;
            color: #0d6efd;
        }
        .team-member img {
            width: 150px;
            height: 150px;
            object-fit: cover;
            border-radius: 50%;
        }
        .about-section {
            padding: 50px 0;
        }
        .about-section:nth-child(even) {
            background-color: #f8f9fa;
        }
        .mission-vision {
            background-color: #0d6efd;
            color: white;
            padding: 60px 0;
        }
        .timeline-item {
            border-left: 2px solid #0d6efd;
            padding-left: 20px;
            margin-bottom: 30px;
            position: relative;
        }
        .timeline-item:before {
            content: '';
            position: absolute;
            left: -10px;
            top: 0;
            width: 20px;
            height: 20px;
            border-radius: 50%;
            background-color: #0d6efd;
        }
    </style>
</head>
<body>

<!-- Main Navbar -->
<nav class="navbar navbar-expand-lg navbar-light bg-white shadow-sm">
    <div class="container">
        <a class="navbar-brand" href="index.php">EcomPro</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav me-auto">
                <li class="nav-item">
                    <a class="nav-link" href="index.php">Home</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="catalog.php">Catalog</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link active" href="about.php">About</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="contact.php">Contact</a>
                </li>
            </ul>
            <ul class="navbar-nav">
                <?php if ($isLoggedIn): ?>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown">
                            <i class="fas fa-user-circle me-1"></i> <?php echo htmlspecialchars($username); ?>
                        </a>
                        <ul class="dropdown-menu dropdown-menu-end">
                            <?php if (isset($_SESSION['admin_id'])): ?>
                                <li><a class="dropdown-item" href="admin/index.php">Admin Dashboard</a></li>
                                <li><hr class="dropdown-divider"></li>
                            <?php endif; ?>
                            <li><a class="dropdown-item" href="profile.php">My Profile</a></li>
                            <li><a class="dropdown-item" href="orders.php">My Orders</a></li>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item" href="logout.php">Logout</a></li>
                        </ul>
                    </li>
                <?php else: ?>
                    <li class="nav-item">
                        <a class="nav-link" href="login.php">Login</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="register.php">Register</a>
                    </li>
                <?php endif; ?>
                <li class="nav-item">
                    <a class="nav-link" href="cart.php">
                        <i class="fas fa-shopping-cart"></i>
                        <?php if ($total_items > 0): ?>
                            <span class="badge rounded-pill bg-danger"><?php echo $total_items; ?></span>
                        <?php endif; ?>
                    </a>
                </li>
            </ul>
        </div>
    </div>
</nav>

<div class="container mt-4">
    <!-- Breadcrumb -->
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="index.php">Home</a></li>
            <li class="breadcrumb-item active" aria-current="page">About Us</li>
        </ol>
    </nav>
</div>

<!-- Hero Section -->
<header class="bg-dark text-white text-center py-5">
    <div class="container">
        <h1 class="display-4">About EcomPro</h1>
        <p class="lead">Your trusted partner for quality products since 2020</p>
    </div>
</header>

<!-- Our Story -->
<section class="about-section">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-md-6">
                <h2>Our Story</h2>
                <p>EcomPro was founded in 2020 with a simple mission: to provide high-quality products at affordable prices with exceptional customer service. What started as a small online store has grown into a trusted e-commerce platform serving thousands of customers worldwide.</p>
                <p>We believe in the power of e-commerce to connect people with the products they love, regardless of geographical boundaries. Our team works tirelessly to curate a selection of products that meet our strict quality standards and deliver them to your doorstep with care and efficiency.</p>
            </div>
            <div class="col-md-6">
                <img src="assets/about/store.jpg" alt="Our Store" class="img-fluid rounded shadow">
            </div>
        </div>
    </div>
</section>

<!-- Mission & Vision -->
<section class="mission-vision">
    <div class="container">
        <div class="row">
            <div class="col-md-6 mb-4">
                <div class="card h-100 border-0 shadow">
                    <div class="card-body">
                        <h3 class="card-title text-primary">Our Mission</h3>
                        <p class="card-text">To provide customers with a seamless shopping experience, offering high-quality products at competitive prices while maintaining exceptional customer service and building lasting relationships.</p>
                    </div>
                </div>
            </div>
            <div class="col-md-6 mb-4">
                <div class="card h-100 border-0 shadow">
                    <div class="card-body">
                        <h3 class="card-title text-primary">Our Vision</h3>
                        <p class="card-text">To become the leading e-commerce platform known for reliability, quality, and customer satisfaction, setting new standards for online shopping experiences across the globe.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Our Values -->
<section class="about-section">
    <div class="container">
        <h2 class="text-center mb-5">Our Core Values</h2>
        <div class="row">
            <div class="col-md-4 mb-4">
                <div class="card h-100 border-0 shadow-sm">
                    <div class="card-body text-center">
                        <i class="fas fa-medal fa-3x text-primary mb-3"></i>
                        <h4>Quality</h4>
                        <p>We never compromise on the quality of our products. Each item in our catalog undergoes rigorous quality checks before reaching our customers.</p>
                    </div>
                </div>
            </div>
            <div class="col-md-4 mb-4">
                <div class="card h-100 border-0 shadow-sm">
                    <div class="card-body text-center">
                        <i class="fas fa-handshake fa-3x text-primary mb-3"></i>
                        <h4>Integrity</h4>
                        <p>We conduct our business with honesty, transparency, and ethical practices, building trust with our customers, partners, and suppliers.</p>
                    </div>
                </div>
            </div>
            <div class="col-md-4 mb-4">
                <div class="card h-100 border-0 shadow-sm">
                    <div class="card-body text-center">
                        <i class="fas fa-users fa-3x text-primary mb-3"></i>
                        <h4>Customer Focus</h4>
                        <p>Our customers are at the heart of everything we do. We continuously strive to exceed expectations and deliver exceptional experiences.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Our Journey -->
<section class="about-section">
    <div class="container">
        <h2 class="text-center mb-5">Our Journey</h2>
        <div class="timeline">
            <div class="timeline-item">
                <h4>2020</h4>
                <p>EcomPro was founded as a small online store with just 50 products.</p>
            </div>
            <div class="timeline-item">
                <h4>2021</h4>
                <p>Expanded our catalog to over 500 products and launched our mobile app.</p>
            </div>
            <div class="timeline-item">
                <h4>2022</h4>
                <p>Opened our first physical warehouse and established partnerships with major brands.</p>
            </div>
            <div class="timeline-item">
                <h4>2023</h4>
                <p>Reached 10,000 customers and expanded operations to international markets.</p>
            </div>
            <div class="timeline-item">
                <h4>2024</h4>
                <p>Launched our premium membership program and continued to grow our product offerings.</p>
            </div>
        </div>
    </div>
</section>

<!-- Our Team -->
<section class="about-section">
    <div class="container">
        <h2 class="text-center mb-5">Meet Our Team</h2>
        <div class="row">
            <div class="col-md-3 mb-4">
                <div class="team-member text-center">
                    <img src="assets/team/ceo.jpg" alt="CEO" class="mb-3">
                    <h5>John Smith</h5>
                    <p class="text-muted">CEO & Founder</p>
                </div>
            </div>
            <div class="col-md-3 mb-4">
                <div class="team-member text-center">
                    <img src="assets/team/cto.jpg" alt="CTO" class="mb-3">
                    <h5>Sarah Johnson</h5>
                    <p class="text-muted">CTO</p>
                </div>
            </div>
            <div class="col-md-3 mb-4">
                <div class="team-member text-center">
                    <img src="assets/team/marketing.jpg" alt="Marketing Director" class="mb-3">
                    <h5>Michael Brown</h5>
                    <p class="text-muted">Marketing Director</p>
                </div>
            </div>
            <div class="col-md-3 mb-4">
                <div class="team-member text-center">
                    <img src="assets/team/customer.jpg" alt="Customer Support" class="mb-3">
                    <h5>Emily Davis</h5>
                    <p class="text-muted">Customer Support Lead</p>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Call to Action -->
<section class="bg-primary text-white text-center py-5">
    <div class="container">
        <h2>Ready to Experience EcomPro?</h2>
        <p class="lead">Join thousands of satisfied customers and discover our quality products today.</p>
        <a href="catalog.php" class="btn btn-light btn-lg mt-3">Shop Now</a>
    </div>
</section>

<!-- Footer -->
<footer class="bg-dark text-white mt-0 py-4">
    <div class="container">
        <div class="row">
            <div class="col-md-4">
                <h5>EcomPro</h5>
                <p>Your one-stop shop for quality products.</p>
            </div>
            <div class="col-md-4">
                <h5>Quick Links</h5>
                <ul class="list-unstyled">
                    <li><a href="index.php" class="text-white">Home</a></li>
                    <li><a href="catalog.php" class="text-white">Catalog</a></li>
                    <li><a href="about.php" class="text-white">About Us</a></li>
                    <li><a href="contact.php" class="text-white">Contact</a></li>
                </ul>
            </div>
            <div class="col-md-4">
                <h5>Contact Us</h5>
                <address>
                    <p><i class="fas fa-map-marker-alt me-2"></i> 123 Main St, City</p>
                    <p><i class="fas fa-phone me-2"></i> (123) 456-7890</p>
                    <p><i class="fas fa-envelope me-2"></i> info@ecompro.com</p>
                </address>
            </div>
        </div>
        <hr>
        <div class="text-center">
            <p>&copy; <?php echo date('Y'); ?> EcomPro. All rights reserved.</p>
        </div>
    </div>
</footer>

<!-- Bootstrap Bundle with Popper -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html> 