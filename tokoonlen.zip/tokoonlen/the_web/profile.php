<?php
session_start();
require_once 'db.php';

// Check if user is logged in
if (!isset($_SESSION['user_id']) && !isset($_SESSION['admin_id'])) {
    header("Location: login.php");
    exit;
}

// Get user ID and role
$user_id = $_SESSION['user_id'] ?? $_SESSION['admin_id'] ?? 0;
$role = $_SESSION['role'] ?? 'user';
$is_admin = ($role === 'operator');

// Fetch user information
$stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
$stmt->execute([$user_id]);
$user = $stmt->fetch();

if (!$user) {
    header("Location: index.php");
    exit;
}

// Handle profile update
$success_message = '';
$error_message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_profile'])) {
    $username = $_POST['username'] ?? '';
    $current_password = $_POST['current_password'] ?? '';
    $new_password = $_POST['new_password'] ?? '';
    $confirm_password = $_POST['confirm_password'] ?? '';
    
    // Check if username is changed and already exists
    if ($username !== $user['username']) {
        $check_stmt = $pdo->prepare("SELECT COUNT(*) FROM users WHERE username = ? AND id != ?");
        $check_stmt->execute([$username, $user_id]);
        $username_exists = $check_stmt->fetchColumn() > 0;
        
        if ($username_exists) {
            $error_message = "Username already exists";
        }
    }
    
    // Validate current password if trying to change password
    if (!empty($new_password) && $current_password !== $user['password']) {
        $error_message = "Current password is incorrect";
    }
    
    // Validate new password match
    if (!empty($new_password) && $new_password !== $confirm_password) {
        $error_message = "New passwords do not match";
    }
    
    // Update profile if no errors
    if (empty($error_message)) {
        if (!empty($new_password)) {
            // Update username and password
            // In production, use password_hash() for passwords
            $update_stmt = $pdo->prepare("UPDATE users SET username = ?, password = ? WHERE id = ?");
            $update_stmt->execute([$username, $new_password, $user_id]);
        } else {
            // Update username only
            $update_stmt = $pdo->prepare("UPDATE users SET username = ? WHERE id = ?");
            $update_stmt->execute([$username, $user_id]);
        }
        
        // Update session username
        if (isset($_SESSION['username'])) {
            $_SESSION['username'] = $username;
        } else if (isset($_SESSION['admin_username'])) {
            $_SESSION['admin_username'] = $username;
        }
        
        $success_message = "Profile updated successfully!";
        
        // Refresh user data
        $stmt->execute([$user_id]);
        $user = $stmt->fetch();
    }
}

// Get user's order history
$orders = [];
try {
    $order_stmt = $pdo->prepare("SELECT * FROM orders WHERE user_id = ? ORDER BY created_at DESC");
    $order_stmt->execute([$user_id]);
    $orders = $order_stmt->fetchAll();
} catch (PDOException $e) {
    // Table might not exist or other error
}

// Get user's review history
$reviews = [];
try {
    $review_stmt = $pdo->prepare("
        SELECT r.*, p.name as product_name, p.image as product_image 
        FROM reviews r 
        JOIN products p ON r.product_id = p.id 
        WHERE r.user_id = ? 
        ORDER BY r.created_at DESC
    ");
    $review_stmt->execute([$user_id]);
    $reviews = $review_stmt->fetchAll();
} catch (PDOException $e) {
    // Table might not exist or other error
}

// Page title and active tab
$page_title = "My Profile";
$active_tab = isset($_GET['tab']) ? $_GET['tab'] : 'profile';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $page_title; ?> - eCompro</title>
    
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome for icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <style>
        .navbar-brand {
            font-weight: 700;
            font-size: 1.8rem;
            color: #0d6efd;
        }
        .profile-header {
            background-color: #f8f9fa;
            padding: 20px 0;
            border-bottom: 1px solid #dee2e6;
        }
        .avatar-placeholder {
            width: 100px;
            height: 100px;
            background-color: #e9ecef;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 2.5rem;
            color: #6c757d;
            margin: 0 auto 15px;
        }
        .nav-pills .nav-link.active {
            background-color: #0d6efd;
        }
        .tab-content {
            padding: 20px 0;
        }
        .order-card, .review-card {
            margin-bottom: 15px;
            transition: transform 0.2s;
        }
        .order-card:hover, .review-card:hover {
            transform: translateY(-5px);
        }
        .rating {
            color: #ffc107;
        }
        .product-img {
            width: 50px;
            height: 50px;
            object-fit: cover;
        }
    </style>
</head>
<body>

<!-- Main Navbar -->
<nav class="navbar navbar-expand-lg navbar-light bg-white shadow-sm">
    <div class="container">
        <a class="navbar-brand" href="index.php">EcomPro</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav me-auto">
                <li class="nav-item">
                    <a class="nav-link" href="index.php">Home</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="catalog.php">Catalog</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="about.php">About</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="contact.php">Contact</a>
                </li>
            </ul>
            <ul class="navbar-nav">
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle active" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown">
                        <i class="fas fa-user-circle me-1"></i> <?php echo htmlspecialchars($user['username']); ?>
                    </a>
                    <ul class="dropdown-menu dropdown-menu-end">
                        <?php if ($is_admin): ?>
                            <li><a class="dropdown-item" href="admin/index.php">Admin Dashboard</a></li>
                            <li><hr class="dropdown-divider"></li>
                        <?php endif; ?>
                        <li><a class="dropdown-item active" href="profile.php">My Profile</a></li>
                        <li><a class="dropdown-item" href="orders.php">My Orders</a></li>
                        <li><hr class="dropdown-divider"></li>
                        <li><a class="dropdown-item" href="logout.php">Logout</a></li>
                    </ul>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="cart.php">
                        <i class="fas fa-shopping-cart"></i>
                    </a>
                </li>
            </ul>
        </div>
    </div>
</nav>

<!-- Profile Header -->
<div class="profile-header">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-md-3 text-center">
                <div class="avatar-placeholder">
                    <i class="fas fa-user"></i>
                </div>
                <h5 class="mb-0"><?php echo htmlspecialchars($user['username']); ?></h5>
                <p class="text-muted mb-0"><?php echo $is_admin ? 'Administrator' : 'Customer'; ?></p>
            </div>
            <div class="col-md-9">
                <ul class="nav nav-pills">
                    <li class="nav-item">
                        <a class="nav-link <?php echo $active_tab === 'profile' ? 'active' : ''; ?>" href="?tab=profile">Profile</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?php echo $active_tab === 'orders' ? 'active' : ''; ?>" href="?tab=orders">Orders</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?php echo $active_tab === 'reviews' ? 'active' : ''; ?>" href="?tab=reviews">Reviews</a>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</div>

<div class="container">
    <div class="tab-content">
        <!-- Profile Tab -->
        <?php if ($active_tab === 'profile'): ?>
            <div class="tab-pane fade show active">
                <div class="row">
                    <div class="col-md-8">
                        <div class="card">
                            <div class="card-header">
                                <h5 class="card-title mb-0">Account Information</h5>
                            </div>
                            <div class="card-body">
                                <?php if (!empty($success_message)): ?>
                                    <div class="alert alert-success" role="alert">
                                        <?php echo $success_message; ?>
                                    </div>
                                <?php endif; ?>
                                
                                <?php if (!empty($error_message)): ?>
                                    <div class="alert alert-danger" role="alert">
                                        <?php echo $error_message; ?>
                                    </div>
                                <?php endif; ?>
                                
                                <form method="POST" action="">
                                    <div class="mb-3">
                                        <label for="username" class="form-label">Username</label>
                                        <input type="text" class="form-control" id="username" name="username" value="<?php echo htmlspecialchars($user['username']); ?>" required>
                                    </div>
                                    
                                    <div class="mb-3">
                                        <label for="role" class="form-label">Account Type</label>
                                        <input type="text" class="form-control" id="role" value="<?php echo $is_admin ? 'Administrator' : 'Customer'; ?>" readonly>
                                    </div>
                                    
                                    <hr>
                                    <h6>Change Password (Optional)</h6>
                                    
                                    <div class="mb-3">
                                        <label for="current_password" class="form-label">Current Password</label>
                                        <input type="password" class="form-control" id="current_password" name="current_password">
                                        <div class="form-text">Enter your current password to change it</div>
                                    </div>
                                    
                                    <div class="mb-3">
                                        <label for="new_password" class="form-label">New Password</label>
                                        <input type="password" class="form-control" id="new_password" name="new_password">
                                    </div>
                                    
                                    <div class="mb-3">
                                        <label for="confirm_password" class="form-label">Confirm New Password</label>
                                        <input type="password" class="form-control" id="confirm_password" name="confirm_password">
                                    </div>
                                    
                                    <div class="d-grid gap-2 d-md-flex justify-content-md-end">
                                        <button type="submit" name="update_profile" class="btn btn-primary">
                                            <i class="fas fa-save me-1"></i> Save Changes
                                        </button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-md-4">
                        <div class="card mb-4">
                            <div class="card-header">
                                <h5 class="card-title mb-0">Account Security</h5>
                            </div>
                            <div class="card-body">
                                <div class="mb-3">
                                    <p class="mb-1"><i class="fas fa-shield-alt me-2 text-primary"></i> <strong>Password:</strong></p>
                                    <p class="text-muted small">Last changed: <?php echo date('M j, Y'); ?></p>
                                </div>
                                <div class="mb-0">
                                    <p class="mb-1"><i class="fas fa-user-lock me-2 text-primary"></i> <strong>Account Type:</strong></p>
                                    <p class="text-muted small"><?php echo $is_admin ? 'Administrator' : 'Customer'; ?></p>
                                </div>
                            </div>
                        </div>
                        
                        <div class="card">
                            <div class="card-header">
                                <h5 class="card-title mb-0">Quick Links</h5>
                            </div>
                            <div class="card-body">
                                <div class="list-group">
                                    <a href="orders.php" class="list-group-item list-group-item-action">
                                        <i class="fas fa-shopping-bag me-2"></i> My Orders
                                    </a>
                                    <?php if ($is_admin): ?>
                                        <a href="admin/index.php" class="list-group-item list-group-item-action">
                                            <i class="fas fa-tachometer-alt me-2"></i> Admin Dashboard
                                        </a>
                                    <?php endif; ?>
                                    <a href="logout.php" class="list-group-item list-group-item-action text-danger">
                                        <i class="fas fa-sign-out-alt me-2"></i> Logout
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        <?php endif; ?>
        
        <!-- Orders Tab -->
        <?php if ($active_tab === 'orders'): ?>
            <div class="tab-pane fade show active">
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-header">
                                <h5 class="card-title mb-0">Order History</h5>
                            </div>
                            <div class="card-body">
                                <?php if (empty($orders)): ?>
                                    <div class="alert alert-info">
                                        <i class="fas fa-info-circle me-2"></i> You don't have any orders yet.
                                        <a href="catalog.php" class="alert-link">Browse products</a> to place your first order.
                                    </div>
                                <?php else: ?>
                                    <div class="row">
                                        <?php foreach ($orders as $order): ?>
                                            <div class="col-md-6">
                                                <div class="card order-card">
                                                    <div class="card-body">
                                                        <div class="d-flex justify-content-between align-items-center mb-2">
                                                            <h6 class="mb-0">Order #<?php echo htmlspecialchars($order['order_code']); ?></h6>
                                                            <?php
                                                            $statusClass = '';
                                                            switch ($order['status']) {
                                                                case 'pending':
                                                                    $statusClass = 'bg-warning text-dark';
                                                                    break;
                                                                case 'processing':
                                                                    $statusClass = 'bg-info text-dark';
                                                                    break;
                                                                case 'shipped':
                                                                    $statusClass = 'bg-primary';
                                                                    break;
                                                                case 'delivered':
                                                                    $statusClass = 'bg-success';
                                                                    break;
                                                                case 'cancelled':
                                                                    $statusClass = 'bg-danger';
                                                                    break;
                                                            }
                                                            ?>
                                                            <span class="badge <?php echo $statusClass; ?>"><?php echo ucfirst($order['status']); ?></span>
                                                        </div>
                                                        <p class="text-muted mb-2">
                                                            <i class="far fa-calendar-alt me-1"></i> 
                                                            <?php echo date('M j, Y', strtotime($order['created_at'])); ?>
                                                        </p>
                                                        <p class="mb-2">
                                                            <strong>Total:</strong> $<?php echo number_format($order['total_amount'], 2); ?>
                                                        </p>
                                                        <div class="d-grid">
                                                            <a href="order_detail.php?id=<?php echo $order['id']; ?>" class="btn btn-outline-primary btn-sm">
                                                                View Details
                                                            </a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        <?php endforeach; ?>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        <?php endif; ?>
        
        <!-- Reviews Tab -->
        <?php if ($active_tab === 'reviews'): ?>
            <div class="tab-pane fade show active">
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-header">
                                <h5 class="card-title mb-0">My Reviews</h5>
                            </div>
                            <div class="card-body">
                                <?php if (empty($reviews)): ?>
                                    <div class="alert alert-info">
                                        <i class="fas fa-info-circle me-2"></i> You haven't written any reviews yet.
                                    </div>
                                <?php else: ?>
                                    <div class="row">
                                        <?php foreach ($reviews as $review): ?>
                                            <div class="col-md-6">
                                                <div class="card review-card">
                                                    <div class="card-body">
                                                        <div class="d-flex align-items-center mb-3">
                                                            <img src="<?php echo htmlspecialchars($review['product_image']); ?>" class="product-img me-3" alt="Product">
                                                            <div>
                                                                <h6 class="mb-0"><?php echo htmlspecialchars($review['product_name']); ?></h6>
                                                                <div class="rating">
                                                                    <?php for ($i = 1; $i <= 5; $i++): ?>
                                                                        <?php if ($i <= $review['rating']): ?>
                                                                            <i class="fas fa-star"></i>
                                                                        <?php else: ?>
                                                                            <i class="far fa-star"></i>
                                                                        <?php endif; ?>
                                                                    <?php endfor; ?>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <p><?php echo htmlspecialchars($review['comment']); ?></p>
                                                        <p class="text-muted small mb-0">
                                                            <i class="far fa-calendar-alt me-1"></i> 
                                                            <?php echo date('M j, Y', strtotime($review['created_at'])); ?>
                                                        </p>
                                                    </div>
                                                </div>
                                            </div>
                                        <?php endforeach; ?>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        <?php endif; ?>
    </div>
</div>

<!-- Footer -->
<footer class="bg-dark text-white py-4 mt-5">
    <div class="container">
        <div class="row">
            <div class="col-md-4 mb-3 mb-md-0">
                <h5>eCompro</h5>
                <p class="text-muted">Your one-stop shop for quality products.</p>
            </div>
            <div class="col-md-4 mb-3 mb-md-0">
                <h5>Quick Links</h5>
                <ul class="list-unstyled">
                    <li><a href="index.php" class="text-decoration-none text-muted">Home</a></li>
                    <li><a href="catalog.php" class="text-decoration-none text-muted">Catalog</a></li>
                    <li><a href="about.php" class="text-decoration-none text-muted">About</a></li>
                    <li><a href="contact.php" class="text-decoration-none text-muted">Contact</a></li>
                </ul>
            </div>
            <div class="col-md-4">
                <h5>Contact Us</h5>
                <ul class="list-unstyled text-muted">
                    <li><i class="fas fa-map-marker-alt me-2"></i> 123 Street, City, Country</li>
                    <li><i class="fas fa-phone me-2"></i> +1 234 5678 900</li>
                    <li><i class="fas fa-envelope me-2"></i> info@ecompro.com</li>
                </ul>
            </div>
        </div>
        <hr class="my-4 bg-secondary">
        <div class="row align-items-center">
            <div class="col-md-6 text-center text-md-start mb-3 mb-md-0">
                <p class="mb-0">&copy; <?php echo date('Y'); ?> eCompro. All rights reserved.</p>
            </div>
            <div class="col-md-6 text-center text-md-end">
                <a href="#" class="text-decoration-none text-muted me-3"><i class="fab fa-facebook-f"></i></a>
                <a href="#" class="text-decoration-none text-muted me-3"><i class="fab fa-twitter"></i></a>
                <a href="#" class="text-decoration-none text-muted me-3"><i class="fab fa-instagram"></i></a>
                <a href="#" class="text-decoration-none text-muted"><i class="fab fa-linkedin-in"></i></a>
            </div>
        </div>
    </div>
</footer>

<!-- Bootstrap Bundle with Popper -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html> 