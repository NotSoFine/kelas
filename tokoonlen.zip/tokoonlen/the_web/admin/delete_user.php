<?php
require_once '../db.php';
require_once 'includes/auth_check.php';

// Check if ID is provided
if (!isset($_GET['id']) || empty($_GET['id'])) {
    header("Location: users.php");
    exit;
}

$id = $_GET['id'];

// Prevent deleting own account
if ($id == $_SESSION['admin_id']) {
    header("Location: users.php?error=cannot_delete_self");
    exit;
}

// Delete the user
$stmt = $pdo->prepare("DELETE FROM users WHERE id = ?");
$stmt->execute([$id]);

// Redirect back to users page
header("Location: users.php?deleted=1");
exit; 