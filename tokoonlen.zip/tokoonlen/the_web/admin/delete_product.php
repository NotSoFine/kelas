<?php
require_once '../db.php';

// Include authentication check
require_once 'includes/auth_check.php';

// Check if ID is provided
if (isset($_GET['id']) && !empty($_GET['id'])) {
    $id = $_GET['id'];
    
    // Get the product image path before deleting
    $stmt = $pdo->prepare("SELECT image FROM products WHERE id = ?");
    $stmt->execute([$id]);
    $product = $stmt->fetch();
    
    // Delete the product
    $stmt = $pdo->prepare("DELETE FROM products WHERE id = ?");
    $stmt->execute([$id]);
    
    // Delete the image file if it exists
    if ($product && !empty($product['image'])) {
        $imagePath = "../" . $product['image'];
        if (file_exists($imagePath)) {
            unlink($imagePath);
        }
    }
    
    // Redirect with success message
    header("Location: products.php?deleted=1");
    exit;
} else {
    // Redirect if no ID provided
    header("Location: products.php");
    exit;
} 