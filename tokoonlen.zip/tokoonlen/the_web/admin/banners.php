<?php
require_once '../db.php';
require_once 'includes/functions.php';

// Authentication is handled in includes/header.php

// Handle banner insertion/update
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_banner'])) {
    $banner_id = $_POST['banner_id'] ?? 0;
    $title = $_POST['title'] ?? '';
    $description = $_POST['description'] ?? '';
    $link = $_POST['link'] ?? '';
    $position = $_POST['position'] ?? 0;
    $active = isset($_POST['active']) ? 1 : 0;
    
    // Handle image upload
    $image = $_POST['current_image'] ?? '';
    if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
        $uploadDir = '../uploads/banners/';
        
        // Create directory if it doesn't exist
        if (!is_dir($uploadDir)) {
            mkdir($uploadDir, 0755, true);
        }
        
        $fileName = basename($_FILES['image']['name']);
        $fileExt = pathinfo($fileName, PATHINFO_EXTENSION);
        $newFileName = 'banner_' . time() . '.' . $fileExt;
        $uploadFile = $uploadDir . $newFileName;
        
        if (move_uploaded_file($_FILES['image']['tmp_name'], $uploadFile)) {
            $image = 'uploads/banners/' . $newFileName;
        }
    }
    
    if ($banner_id > 0) {
        // Update existing banner
        $stmt = $pdo->prepare("UPDATE banners SET title = ?, description = ?, image = ?, link = ?, position = ?, active = ? WHERE id = ?");
        $stmt->execute([$title, $description, $image, $link, $position, $active, $banner_id]);
        $success = "Banner updated successfully!";
    } else {
        // Insert new banner
        $stmt = $pdo->prepare("INSERT INTO banners (title, description, image, link, position, active) VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->execute([$title, $description, $image, $link, $position, $active]);
        $success = "Banner added successfully!";
    }
    
    // Redirect to avoid form resubmission
    header("Location: banners.php?success=1");
    exit;
}

// Handle banner deletion
if (isset($_GET['delete']) && is_numeric($_GET['delete'])) {
    $banner_id = $_GET['delete'];
    $stmt = $pdo->prepare("DELETE FROM banners WHERE id = ?");
    $stmt->execute([$banner_id]);
    
    header("Location: banners.php?deleted=1");
    exit;
}

// Get banner for editing
$editBanner = null;
if (isset($_GET['edit']) && is_numeric($_GET['edit'])) {
    $banner_id = $_GET['edit'];
    $stmt = $pdo->prepare("SELECT * FROM banners WHERE id = ?");
    $stmt->execute([$banner_id]);
    $editBanner = $stmt->fetch();
}

// Fetch all banners
try {
    $stmt = $pdo->query("SELECT * FROM banners ORDER BY position ASC");
    $banners = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    // Table might not exist yet
    $banners = [];
}

// Include header
include 'includes/header.php';
?>

<div class="container-fluid">
    <h1 class="h2 mb-4">Banner Management</h1>
    
    <?php if (isset($_GET['success'])): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            Banner successfully saved!
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>
    
    <?php if (isset($_GET['deleted'])): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            Banner successfully deleted!
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>
    
    <!-- Add/Edit Banner Form -->
    <div class="card mb-4">
        <div class="card-header bg-white">
            <h5 class="mb-0"><?php echo $editBanner ? 'Edit Banner' : 'Add New Banner'; ?></h5>
        </div>
        <div class="card-body">
            <form action="" method="POST" class="row g-3" enctype="multipart/form-data">
                <input type="hidden" name="banner_id" value="<?php echo $editBanner ? $editBanner['id'] : 0; ?>">
                <input type="hidden" name="current_image" value="<?php echo $editBanner ? $editBanner['image'] : ''; ?>">
                
                <div class="col-md-6">
                    <label class="form-label">Title</label>
                    <input type="text" name="title" class="form-control" value="<?php echo $editBanner ? htmlspecialchars($editBanner['title']) : ''; ?>">
                </div>
                
                <div class="col-md-6">
                    <label class="form-label">Link (URL)</label>
                    <input type="text" name="link" class="form-control" value="<?php echo $editBanner ? htmlspecialchars($editBanner['link']) : ''; ?>">
                </div>
                
                <div class="col-md-12">
                    <label class="form-label">Description</label>
                    <textarea name="description" class="form-control" rows="2"><?php echo $editBanner ? htmlspecialchars($editBanner['description']) : ''; ?></textarea>
                </div>
                
                <div class="col-md-6">
                    <label class="form-label">Banner Image</label>
                    <input type="file" name="image" class="form-control" accept="image/*">
                    <?php if ($editBanner && !empty($editBanner['image'])): ?>
                        <div class="mt-2">
                            <small>Current image: <?php echo htmlspecialchars($editBanner['image']); ?></small>
                            <img src="../<?php echo htmlspecialchars($editBanner['image']); ?>" alt="Current Banner" class="img-thumbnail mt-2" style="max-height: 100px;">
                        </div>
                    <?php endif; ?>
                </div>
                
                <div class="col-md-3">
                    <label class="form-label">Position</label>
                    <input type="number" name="position" class="form-control" value="<?php echo $editBanner ? $editBanner['position'] : count($banners) + 1; ?>" min="1">
                </div>
                
                <div class="col-md-3">
                    <label class="form-label d-block">&nbsp;</label>
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" name="active" id="activeCheck" <?php echo (!$editBanner || $editBanner['active']) ? 'checked' : ''; ?>>
                        <label class="form-check-label" for="activeCheck">
                            Active
                        </label>
                    </div>
                </div>
                
                <div class="col-12">
                    <button type="submit" name="save_banner" class="btn btn-primary">
                        <i class="fas fa-save"></i> <?php echo $editBanner ? 'Update Banner' : 'Add Banner'; ?>
                    </button>
                    <?php if ($editBanner): ?>
                        <a href="banners.php" class="btn btn-secondary">
                            <i class="fas fa-plus-circle"></i> Add New
                        </a>
                    <?php endif; ?>
                </div>
            </form>
        </div>
    </div>
    
    <!-- Banners Table -->
    <div class="card">
        <div class="card-header bg-white">
            <h5 class="mb-0">All Banners</h5>
        </div>
        <div class="card-body">
            <?php if (empty($banners)): ?>
                <div class="alert alert-info">
                    No banners found. Add your first banner above.
                </div>
            <?php else: ?>
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th>Image</th>
                                <th>Title</th>
                                <th>Description</th>
                                <th>Position</th>
                                <th>Status</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($banners as $banner): ?>
                                <tr>
                                    <td>
                                        <?php if (!empty($banner['image'])): ?>
                                            <img src="../<?php echo htmlspecialchars($banner['image']); ?>" 
                                                alt="<?php echo htmlspecialchars($banner['title']); ?>" 
                                                class="img-thumbnail" style="width: 100px; height: 50px; object-fit: cover;">
                                        <?php else: ?>
                                            <span class="text-muted">No image</span>
                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo htmlspecialchars($banner['title']); ?></td>
                                    <td><?php echo htmlspecialchars(substr($banner['description'], 0, 50)) . (strlen($banner['description']) > 50 ? '...' : ''); ?></td>
                                    <td><?php echo $banner['position']; ?></td>
                                    <td>
                                        <?php if ($banner['active']): ?>
                                            <span class="badge bg-success">Active</span>
                                        <?php else: ?>
                                            <span class="badge bg-secondary">Inactive</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <a href="banners.php?edit=<?php echo $banner['id']; ?>" class="btn btn-sm btn-primary">
                                            <i class="fas fa-edit"></i>
                                        </a>
                                        <a href="#" class="btn btn-sm btn-danger" 
                                           onclick="if(confirm('Are you sure you want to delete this banner?')) 
                                           window.location.href='banners.php?delete=<?php echo $banner['id']; ?>'">
                                            <i class="fas fa-trash"></i>
                                        </a>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?> 