<?php
// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Ensure session is started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Debug session - output as HTML comment
echo "<!-- SESSION DEBUG: ";
print_r($_SESSION);
echo " -->";

require_once '../db.php';
require_once 'includes/functions.php';

// AUTOMATIC SESSION FIX - Check if admin_id is missing or invalid
if (empty($_SESSION['admin_id']) || $_SESSION['admin_id'] == 0) {
    // Try to find the admin user 'test' with role 'operator'
    $stmt = $pdo->prepare("SELECT * FROM users WHERE username = ? AND role = ? LIMIT 1");
    $stmt->execute(['test', 'operator']);
    $admin = $stmt->fetch();
    
    if ($admin) {
        // Set the session variables
        $_SESSION['admin_id'] = $admin['id'];
        $_SESSION['admin_username'] = $admin['username'];
        $_SESSION['role'] = $admin['role'];
        
        echo "<!-- AUTO-FIXED SESSION: Admin found and session set -->";
    } else {
        echo "<!-- FAILED TO AUTO-FIX SESSION: Admin 'test' not found -->";
    }
}

// Authentication is now handled in includes/header.php

// Get admin ID
$admin_id = $_SESSION['admin_id'] ?? 0;

// Fetch admin information - NO REDIRECTION, we know the user exists
$stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
$stmt->execute([$admin_id]);
$admin = $stmt->fetch();

// IMPORTANT: Don't redirect even if admin not found, just show an error message instead
// This ensures the page doesn't bounce back to dashboard

// Handle profile update
$success_message = '';
$error_message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_profile'])) {
    $username = $_POST['username'] ?? '';
    $current_password = $_POST['current_password'] ?? '';
    $new_password = $_POST['new_password'] ?? '';
    $confirm_password = $_POST['confirm_password'] ?? '';
    
    // Check if username is changed and already exists
    if ($username !== $admin['username']) {
        $check_stmt = $pdo->prepare("SELECT COUNT(*) FROM users WHERE username = ? AND id != ?");
        $check_stmt->execute([$username, $admin_id]);
        $username_exists = $check_stmt->fetchColumn() > 0;
        
        if ($username_exists) {
            $error_message = "Username already exists";
        }
    }
    
    // Validate current password if trying to change password
    if (!empty($new_password) && $current_password !== $admin['password']) {
        $error_message = "Current password is incorrect";
    }
    
    // Validate new password match
    if (!empty($new_password) && $new_password !== $confirm_password) {
        $error_message = "New passwords do not match";
    }
    
    // Update profile if no errors
    if (empty($error_message) && $admin) {
        if (!empty($new_password)) {
            // Update username and password
            // In production, use password_hash() for passwords
            $update_stmt = $pdo->prepare("UPDATE users SET username = ?, password = ? WHERE id = ?");
            $update_stmt->execute([$username, $new_password, $admin_id]);
        } else {
            // Update username only
            $update_stmt = $pdo->prepare("UPDATE users SET username = ? WHERE id = ?");
            $update_stmt->execute([$username, $admin_id]);
        }
        
        // Update session username
        $_SESSION['admin_username'] = $username;
        
        $success_message = "Profile updated successfully!";
        
        // Refresh admin data
        $stmt->execute([$admin_id]);
        $admin = $stmt->fetch();
    }
}

// Get admin activity stats
$stats = [
    'products_count' => 0,
    'orders_count' => 0,
    'users_count' => 0,
    'banners_count' => 0
];

try {
    // Count products
    $stats['products_count'] = $pdo->query("SELECT COUNT(*) FROM products")->fetchColumn();
    
    // Count orders (if table exists)
    try {
        $stats['orders_count'] = $pdo->query("SELECT COUNT(*) FROM orders")->fetchColumn();
    } catch (PDOException $e) {
        // Table might not exist
    }
    
    // Count users
    $stats['users_count'] = $pdo->query("SELECT COUNT(*) FROM users WHERE role = 'user'")->fetchColumn();
    
    // Count banners (if table exists)
    try {
        $stats['banners_count'] = $pdo->query("SELECT COUNT(*) FROM banners")->fetchColumn();
    } catch (PDOException $e) {
        // Table might not exist
    }
} catch (PDOException $e) {
    // Handle errors
    $error_message = "Database error: " . $e->getMessage();
}

// Include header
include 'includes/header.php';
?>

<div class="container-fluid">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h1 class="h2">Admin Profile</h1>
        <a href="index.php" class="btn btn-secondary">
            <i class="fas fa-arrow-left"></i> Back to Dashboard
        </a>
    </div>
    
    <?php if (!$admin): ?>
        <div class="alert alert-danger">
            <h4>Error: Admin Not Found</h4>
            <p>No admin user was found with ID: <?php echo $admin_id; ?></p>
            <p>You may need to <a href="fix_session.php" class="alert-link">fix your session</a> or log out and log in again.</p>
        </div>
    <?php else: ?>
    
    <?php if (!empty($success_message)): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?php echo $success_message; ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>
    
    <?php if (!empty($error_message)): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <?php echo $error_message; ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>
    
    <div class="row">
        <div class="col-md-8">
            <!-- Profile Information -->
            <div class="card mb-4">
                <div class="card-header bg-white">
                    <h5 class="mb-0">Account Information</h5>
                </div>
                <div class="card-body">
                    <form action="" method="POST">
                        <div class="mb-3">
                            <label for="username" class="form-label">Username</label>
                            <input type="text" class="form-control" id="username" name="username" value="<?php echo htmlspecialchars($admin['username']); ?>" required>
                        </div>
                        
                        <div class="mb-3">
                            <label for="role" class="form-label">Role</label>
                            <input type="text" class="form-control" id="role" value="Administrator" readonly>
                        </div>
                        
                        <hr>
                        <h6>Change Password</h6>
                        
                        <div class="mb-3">
                            <label for="current_password" class="form-label">Current Password</label>
                            <input type="password" class="form-control" id="current_password" name="current_password">
                            <div class="form-text">Enter your current password to change it</div>
                        </div>
                        
                        <div class="mb-3">
                            <label for="new_password" class="form-label">New Password</label>
                            <input type="password" class="form-control" id="new_password" name="new_password">
                        </div>
                        
                        <div class="mb-3">
                            <label for="confirm_password" class="form-label">Confirm New Password</label>
                            <input type="password" class="form-control" id="confirm_password" name="confirm_password">
                        </div>
                        
                        <div class="d-grid gap-2 d-md-flex justify-content-md-end">
                            <button type="submit" name="update_profile" class="btn btn-primary">
                                <i class="fas fa-save me-1"></i> Update Profile
                            </button>
                        </div>
                    </form>
                </div>
            </div>
            
            <!-- Security Settings -->
            <div class="card">
                <div class="card-header bg-white">
                    <h5 class="mb-0">Security Settings</h5>
                </div>
                <div class="card-body">
                    <div class="mb-3">
                        <label class="form-label">Two-Factor Authentication</label>
                        <div class="form-check form-switch">
                            <input class="form-check-input" type="checkbox" id="twoFactorToggle" disabled>
                            <label class="form-check-label" for="twoFactorToggle">Enable Two-Factor Authentication</label>
                        </div>
                        <div class="form-text text-muted">This feature will be available in a future update.</div>
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label">Login Notification</label>
                        <div class="form-check form-switch">
                            <input class="form-check-input" type="checkbox" id="loginNotificationToggle" disabled>
                            <label class="form-check-label" for="loginNotificationToggle">Receive email notifications for new logins</label>
                        </div>
                        <div class="form-text text-muted">This feature will be available in a future update.</div>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="col-md-4">
            <!-- Admin Info Card -->
            <div class="card mb-4">
                <div class="card-header bg-white">
                    <h5 class="mb-0">Administrator Info</h5>
                </div>
                <div class="card-body text-center">
                    <div class="avatar-placeholder mb-3">
                        <i class="fas fa-user-shield"></i>
                    </div>
                    <h5 class="mb-1"><?php echo htmlspecialchars($admin['username']); ?></h5>
                    <p class="text-muted mb-3">Administrator</p>
                    <div class="d-grid">
                        <a href="generate_token.php" class="btn btn-outline-primary btn-sm">
                            <i class="fas fa-key me-1"></i> Generate Admin Token
                        </a>
                    </div>
                </div>
            </div>
            
            <!-- Activity Stats -->
            <div class="card mb-4">
                <div class="card-header bg-white">
                    <h5 class="mb-0">Store Statistics</h5>
                </div>
                <div class="card-body">
                    <ul class="list-group list-group-flush">
                        <li class="list-group-item d-flex justify-content-between align-items-center">
                            Products
                            <span class="badge bg-primary rounded-pill"><?php echo $stats['products_count']; ?></span>
                        </li>
                        <li class="list-group-item d-flex justify-content-between align-items-center">
                            Orders
                            <span class="badge bg-primary rounded-pill"><?php echo $stats['orders_count']; ?></span>
                        </li>
                        <li class="list-group-item d-flex justify-content-between align-items-center">
                            Customers
                            <span class="badge bg-primary rounded-pill"><?php echo $stats['users_count']; ?></span>
                        </li>
                        <li class="list-group-item d-flex justify-content-between align-items-center">
                            Banners
                            <span class="badge bg-primary rounded-pill"><?php echo $stats['banners_count']; ?></span>
                        </li>
                    </ul>
                </div>
            </div>
            
            <!-- Quick Links -->
            <div class="card">
                <div class="card-header bg-white">
                    <h5 class="mb-0">Quick Links</h5>
                </div>
                <div class="card-body">
                    <div class="list-group">
                        <a href="products.php" class="list-group-item list-group-item-action">
                            <i class="fas fa-box me-2"></i> Manage Products
                        </a>
                        <a href="orders.php" class="list-group-item list-group-item-action">
                            <i class="fas fa-shopping-cart me-2"></i> Manage Orders
                        </a>
                        <a href="users.php" class="list-group-item list-group-item-action">
                            <i class="fas fa-users me-2"></i> Manage Users
                        </a>
                        <a href="banners.php" class="list-group-item list-group-item-action">
                            <i class="fas fa-images me-2"></i> Manage Banners
                        </a>
                        <a href="../index.php" class="list-group-item list-group-item-action">
                            <i class="fas fa-store me-2"></i> View Store
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <?php endif; ?>
    
    <!-- Add links to diagnostic tools at the bottom -->
    <?php if (!$admin): ?>
    <div class="mt-4">
        <h3>Diagnostic Tools</h3>
        <div class="list-group">
            <a href="fix_session.php" class="list-group-item list-group-item-action">
                <i class="fas fa-wrench me-2"></i> Session Repair Tool
            </a>
            <a href="session_debug.php" class="list-group-item list-group-item-action">
                <i class="fas fa-bug me-2"></i> Session Debug Information
            </a>
            <a href="profile_simple.php" class="list-group-item list-group-item-action">
                <i class="fas fa-user-check me-2"></i> Simple Profile View
            </a>
        </div>
    </div>
    <?php endif; ?>
</div>

<style>
    .avatar-placeholder {
        width: 100px;
        height: 100px;
        background-color: #e9ecef;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 2.5rem;
        color: #6c757d;
        margin: 0 auto;
    }
</style>

<?php include 'includes/footer.php'; ?> 