<?php
require_once '../db.php';
require_once 'includes/functions.php';
require_once '../includes/api_client.php';

// Authentication is now handled in includes/header.php

// Initialize API client
$api = new ApiClient();

// Check if ID is provided
if (!isset($_GET['id'])) {
    header("Location: products_api.php");
    exit;
}

$id = $_GET['id'];

// Get product from API
$response = $api->getProduct($id);

if ($response['status'] !== 'success') {
    header("Location: products_api.php?error=Product+not+found");
    exit;
}

$product = $response['data'];

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_product'])) {
    $name = $_POST['name'];
    $price = $_POST['price'];
    $stock = $_POST['stock'];
    $discount = !empty($_POST['discount']) ? $_POST['discount'] : null;
    
    // Prepare update data
    $productData = [
        'name' => $name,
        'price' => $price,
        'stock' => $stock,
        'discount' => $discount
    ];
    
    // Add category if provided
    if (isset($_POST['category'])) {
        $productData['category'] = $_POST['category'];
    }
    
    // Handle image upload
    if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
        $targetDir = "../uploads/";
        if (!is_dir($targetDir)) {
            mkdir($targetDir, 0755, true);
        }
        $imageName = basename($_FILES['image']['name']);
        $targetFile = $targetDir . uniqid() . '_' . $imageName;
        move_uploaded_file($_FILES['image']['tmp_name'], $targetFile);
        $productData['image'] = str_replace("../", "", $targetFile); // Store relative path
    }
    
    // Update product using API
    $updateResponse = $api->updateProduct($id, $productData);
    
    if ($updateResponse['status'] === 'success') {
        // Refresh product data
        $product = $updateResponse['data'];
        $success = "Product updated successfully!";
    } else {
        $error = $updateResponse['message'];
    }
}

// Include header
include 'includes/header.php';
?>

<div class="container-fluid">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h1 class="h2">Edit Product (API Version)</h1>
        <a href="products_api.php" class="btn btn-secondary">
            <i class="fas fa-arrow-left"></i> Back to Products
        </a>
    </div>
    
    <?php if (isset($success)): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?php echo $success; ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>
    
    <?php if (isset($error)): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <?php echo $error; ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>
    
    <div class="card">
        <div class="card-header bg-white">
            <h5 class="mb-0">Edit Product: <?php echo htmlspecialchars($product['name']); ?></h5>
        </div>
        <div class="card-body">
            <div class="row">
                <div class="col-md-4 mb-4">
                    <div class="card">
                        <img src="../<?php echo htmlspecialchars($product['image']); ?>" class="card-img-top" alt="<?php echo htmlspecialchars($product['name']); ?>">
                        <div class="card-body">
                            <h5 class="card-title"><?php echo htmlspecialchars($product['name']); ?></h5>
                            <p class="card-text">
                                <strong>Price:</strong> <?php echo formatPrice($product['price']); ?><br>
                                <strong>Stock:</strong> <?php echo $product['stock']; ?><br>
                                <strong>Discount:</strong> <?php echo $product['discount'] ? formatPrice($product['discount']) : 'None'; ?><br>
                                <strong>Category:</strong> <?php echo !empty($product['category']) ? htmlspecialchars($product['category']) : 'Uncategorized'; ?><br>
                                <strong>Created:</strong> <?php echo date('Y-m-d', strtotime($product['created_at'])); ?>
                            </p>
                        </div>
                    </div>
                </div>
                
                <div class="col-md-8">
                    <form action="" method="POST" enctype="multipart/form-data" class="row g-3">
                        <div class="col-md-6">
                            <label class="form-label">Product Name</label>
                            <input type="text" name="name" class="form-control" value="<?php echo htmlspecialchars($product['name']); ?>" required>
                        </div>
                        
                        <div class="col-md-3">
                            <label class="form-label">Price</label>
                            <div class="input-group">
                                <span class="input-group-text">$</span>
                                <input type="number" name="price" step="0.01" class="form-control" value="<?php echo $product['price']; ?>" required>
                            </div>
                        </div>
                        
                        <div class="col-md-3">
                            <label class="form-label">Stock</label>
                            <input type="number" name="stock" class="form-control" value="<?php echo $product['stock']; ?>" required>
                        </div>
                        
                        <div class="col-md-6">
                            <label class="form-label">Discount (optional)</label>
                            <div class="input-group">
                                <span class="input-group-text">$</span>
                                <input type="number" name="discount" step="0.01" class="form-control" value="<?php echo $product['discount']; ?>">
                            </div>
                        </div>
                        
                        <div class="col-md-6">
                            <label class="form-label">Category</label>
                            <input type="text" name="category" class="form-control" value="<?php echo htmlspecialchars($product['category'] ?? ''); ?>" placeholder="Enter product category">
                        </div>
                        
                        <div class="col-md-6">
                            <label class="form-label">Change Image (leave empty to keep current)</label>
                            <input type="file" name="image" class="form-control" accept="image/*">
                        </div>
                        
                        <div class="col-12 mt-4">
                            <button type="submit" name="update_product" class="btn btn-primary">
                                <i class="fas fa-save"></i> Update Product
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?> 