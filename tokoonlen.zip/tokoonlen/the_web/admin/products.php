<?php
require_once '../db.php';
require_once 'includes/functions.php';

// Authentication is now handled in includes/header.php

// Handle product insertion
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_product'])) {
    $name = $_POST['name'];
    $price = $_POST['price'];
    $stock = $_POST['stock'];
    $discount = !empty($_POST['discount']) ? $_POST['discount'] : null;
    $description = $_POST['description'];
    $category = !empty($_POST['category']) ? $_POST['category'] : null;

    // Handle image upload
    $imagePath = '';
    if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
        $targetDir = "../uploads/";
        if (!is_dir($targetDir)) {
            mkdir($targetDir, 0755, true);
        }
        $imageName = basename($_FILES['image']['name']);
        $targetFile = $targetDir . uniqid() . '_' . $imageName;
        move_uploaded_file($_FILES['image']['tmp_name'], $targetFile);
        $imagePath = str_replace("../", "", $targetFile); // Store relative path
    }

    $stmt = $pdo->prepare("INSERT INTO products (name, description, price, stock, discount, category, image) VALUES (?, ?, ?, ?, ?, ?, ?)");
    $stmt->execute([$name, $description, $price, $stock, $discount, $category, $imagePath]);

    // Redirect to avoid form resubmission
    header("Location: products.php?success=1");
    exit;
}

// Handle search functionality
$products = [];
$searchPerformed = false;
if (isset($_GET['search']) && !empty($_GET['search'])) {
    $searchQuery = $_GET['search'];
    $products = searchProducts($pdo, $searchQuery);
    $searchPerformed = true;
} else {
    // Get all products if no search is performed
    $stmt = $pdo->query("SELECT * FROM products ORDER BY id DESC");
    $products = $stmt->fetchAll();
}

// Get all unique categories for dropdown
$categories = [];
$categoryStmt = $pdo->query("SELECT DISTINCT category FROM products WHERE category IS NOT NULL ORDER BY category");
if ($categoryStmt) {
    while ($row = $categoryStmt->fetch()) {
        $categories[] = $row['category'];
    }
}

// Include header
include 'includes/header.php';
?>

<div class="container-fluid">
    <h1 class="h2 mb-4">Products Management</h1>
    
    <?php if (isset($_GET['success'])): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            Product successfully added!
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>
    
    <!-- Add Product Form -->
    <div class="card mb-4">
        <div class="card-header bg-white">
            <h5 class="mb-0">Add New Product</h5>
        </div>
        <div class="card-body">
            <form action="" method="POST" enctype="multipart/form-data" class="row g-3">
                <div class="col-md-6">
                    <label class="form-label">Product Name</label>
                    <input type="text" name="name" class="form-control" required>
                </div>
                
                <div class="col-md-2">
                    <label class="form-label">Price</label>
                    <div class="input-group">
                        <span class="input-group-text">$</span>
                        <input type="number" name="price" step="0.01" class="form-control" required>
                    </div>
                </div>
                
                <div class="col-md-2">
                    <label class="form-label">Stock</label>
                    <input type="number" name="stock" class="form-control" required>
                </div>
                
                <div class="col-md-2">
                    <label class="form-label">Discount (optional)</label>
                    <div class="input-group">
                        <span class="input-group-text">$</span>
                        <input type="number" name="discount" step="0.01" class="form-control">
                    </div>
                </div>

                <div class="col-md-6">
                    <label class="form-label">Category</label>
                    <div class="input-group">
                        <input type="text" name="category" list="categoryList" class="form-control" placeholder="Select or enter a new category">
                        <datalist id="categoryList">
                            <?php foreach ($categories as $cat): ?>
                                <option value="<?php echo htmlspecialchars($cat); ?>">
                            <?php endforeach; ?>
                        </datalist>
                    </div>
                </div>
                
                <div class="col-md-12">
                    <label class="form-label">Product Description</label>
                    <textarea name="description" class="form-control" rows="3"></textarea>
                </div>
                
                <div class="col-md-12">
                    <label class="form-label">Product Image</label>
                    <input type="file" name="image" class="form-control" accept="image/*" required>
                </div>
                
                <div class="col-12">
                    <button type="submit" name="add_product" class="btn btn-primary">
                        <i class="fas fa-plus-circle"></i> Add Product
                    </button>
                </div>
            </form>
        </div>
    </div>
    
    <!-- Products Table -->
    <div class="card">
        <div class="card-header bg-white">
            <div class="d-flex justify-content-between align-items-center">
                <h5 class="mb-0">
                    <?php if ($searchPerformed): ?>
                        Search Results for "<?php echo htmlspecialchars($_GET['search']); ?>"
                    <?php else: ?>
                        All Products
                    <?php endif; ?>
                </h5>
            </div>
        </div>
        <div class="card-body">
            <?php if (empty($products)): ?>
                <div class="alert alert-info">
                    <?php echo $searchPerformed ? 'No products found matching your search.' : 'No products found.'; ?>
                </div>
            <?php else: ?>
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Image</th>
                                <th>Name</th>
                                <th>Description</th>
                                <th>Category</th>
                                <th>Price</th>
                                <th>Stock</th>
                                <th>Discount</th>
                                <th>Created At</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($products as $product): ?>
                                <tr>
                                    <td><?php echo $product['id']; ?></td>
                                    <td>
                                        <img src="../<?php echo htmlspecialchars($product['image']); ?>" 
                                             alt="<?php echo htmlspecialchars($product['name']); ?>" 
                                             class="img-thumbnail" style="width: 50px; height: 50px; object-fit: cover;">
                                    </td>
                                    <td><?php echo htmlspecialchars($product['name']); ?></td>
                                    <td>
                                        <?php if (!empty($product['description'])): ?>
                                            <span class="text-truncate d-inline-block" style="max-width: 150px;" title="<?php echo htmlspecialchars($product['description']); ?>">
                                                <?php echo htmlspecialchars($product['description']); ?>
                                            </span>
                                        <?php else: ?>
                                            <span class="text-muted">No description</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if (!empty($product['category'])): ?>
                                            <span class="badge bg-info"><?php echo htmlspecialchars($product['category']); ?></span>
                                        <?php else: ?>
                                            <span class="text-muted">Uncategorized</span>
                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo formatPrice($product['price']); ?></td>
                                    <td><?php echo $product['stock']; ?></td>
                                    <td>
                                        <?php if ($product['discount']): ?>
                                            <?php echo formatPrice($product['discount']); ?>
                                        <?php else: ?>
                                            -
                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo date('Y-m-d', strtotime($product['created_at'])); ?></td>
                                    <td>
                                        <a href="edit_product.php?id=<?php echo $product['id']; ?>" class="btn btn-sm btn-primary">
                                            <i class="fas fa-edit"></i>
                                        </a>
                                        <a href="#" class="btn btn-sm btn-danger" 
                                           onclick="if(confirm('Are you sure you want to delete this product?')) 
                                           window.location.href='delete_product.php?id=<?php echo $product['id']; ?>'">
                                            <i class="fas fa-trash"></i>
                                        </a>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?> 