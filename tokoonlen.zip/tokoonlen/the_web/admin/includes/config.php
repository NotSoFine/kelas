<?php
/**
 * Admin Configuration File
 * 
 * Contains configuration settings for the admin panel
 */

// Admin registration token
// This token is required to register a new admin account
// Change this to a strong, random string in production
define('ADMIN_REGISTER_TOKEN', 'eCompro2025AdminSecureToken');

// Maximum login attempts before temporary lockout
define('MAX_LOGIN_ATTEMPTS', 5);

// Lockout time in seconds (15 minutes)
define('LOCKOUT_TIME', 900);

// Session timeout in seconds (30 minutes)
define('SESSION_TIMEOUT', 1800); 