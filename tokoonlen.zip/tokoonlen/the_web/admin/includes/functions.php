<?php
/**
 * Admin Functions
 */

/**
 * Search products based on query
 * 
 * @param PDO $pdo Database connection
 * @param string $query Search query
 * @return array Array of products matching the search query
 */
function searchProducts($pdo, $query) {
    $searchTerm = "%$query%";
    $stmt = $pdo->prepare("SELECT * FROM products 
                          WHERE name LIKE ? 
                          OR description LIKE ?
                          OR category LIKE ?
                          OR price LIKE ? 
                          OR stock LIKE ? 
                          OR discount LIKE ?
                          ORDER BY id DESC");
    $stmt->execute([$searchTerm, $searchTerm, $searchTerm, $searchTerm, $searchTerm, $searchTerm]);
    return $stmt->fetchAll();
}

/**
 * Get recent products
 * 
 * @param PDO $pdo Database connection
 * @param int $limit Number of products to return
 * @return array Array of recent products
 */
function getRecentProducts($pdo, $limit = 10) {
    $stmt = $pdo->prepare("SELECT * FROM products ORDER BY id DESC LIMIT ?");
    $stmt->execute([$limit]);
    return $stmt->fetchAll();
}

/**
 * Get product by ID
 * 
 * @param PDO $pdo Database connection
 * @param int $id Product ID
 * @return array|false Product data or false if not found
 */
function getProductById($pdo, $id) {
    $stmt = $pdo->prepare("SELECT * FROM products WHERE id = ?");
    $stmt->execute([$id]);
    return $stmt->fetch();
}

/**
 * Search users based on query
 * 
 * @param PDO $pdo Database connection
 * @param string $query Search query
 * @return array Array of users matching the search query
 */
function searchUsers($pdo, $query) {
    $searchTerm = "%$query%";
    $stmt = $pdo->prepare("SELECT * FROM users 
                          WHERE username LIKE ? 
                          OR role LIKE ? 
                          ORDER BY id DESC");
    $stmt->execute([$searchTerm, $searchTerm]);
    return $stmt->fetchAll();
}

/**
 * Get all users
 * 
 * @param PDO $pdo Database connection
 * @return array Array of all users
 */
function getAllUsers($pdo) {
    $stmt = $pdo->query("SELECT * FROM users ORDER BY id DESC");
    return $stmt->fetchAll();
}

/**
 * Get user by ID
 * 
 * @param PDO $pdo Database connection
 * @param int $id User ID
 * @return array|false User data or false if not found
 */
function getUserById($pdo, $id) {
    $stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
    $stmt->execute([$id]);
    return $stmt->fetch();
}

/**
 * Format price with currency symbol
 * 
 * @param float $price Price to format
 * @param string $currency Currency symbol
 * @return string Formatted price
 */
function formatPrice($price, $currency = '$') {
    return $currency . number_format($price, 2);
} 