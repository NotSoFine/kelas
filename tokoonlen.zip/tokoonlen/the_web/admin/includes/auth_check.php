<?php
/**
 * Admin Authentication Check
 * 
 * This file is used to verify if the current user is authenticated as an admin.
 * Include this file at the beginning of all admin pages that require authentication.
 */

// Start session if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Check if user is logged in and has admin role (either 'operator', 'admin', or 'adm')
if (!isset($_SESSION['admin_id']) || ($_SESSION['role'] !== 'operator' && $_SESSION['role'] !== 'admin' && $_SESSION['role'] !== 'adm')) {
    // Store the requested URL for redirection after login
    $_SESSION['redirect_url'] = $_SERVER['REQUEST_URI'];
    
    // Redirect to main login page
    header("Location: " . getRelativePath() . "../login.php");
    exit;
}

/**
 * Get the relative path to the admin directory
 * This helps with proper redirection based on the current file location
 */
function getRelativePath() {
    $currentPath = $_SERVER['SCRIPT_NAME'];
    $adminDir = '/admin/';
    
    // If we're already in the admin directory root
    if (strpos($currentPath, $adminDir) !== false && substr_count($currentPath, '/', strpos($currentPath, $adminDir)) === 1) {
        return '';
    }
    
    // If we're in a subdirectory of admin
    $depth = substr_count($currentPath, '/', strpos($currentPath, $adminDir)) - 1;
    return str_repeat('../', $depth);
} 