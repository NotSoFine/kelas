            </main>
            <!-- Footer -->
            <footer class="bg-dark text-white text-center py-3">
                <div class="container-fluid">
                    <p class="mb-0">&copy; <?php echo date('Y'); ?> eCompro Admin Panel. All rights reserved.</p>
                </div>
            </footer>
        </div>
    </div>

    <!-- Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <!-- Custom JavaScript -->
    <script src="../assets/script.js"></script>
</body>
</html> 