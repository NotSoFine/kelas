<?php
require_once '../db.php';
require_once 'includes/functions.php';

// Authentication is now handled in includes/header.php

// Check if ID is provided
if (!isset($_GET['id']) || empty($_GET['id'])) {
    header("Location: products.php");
    exit;
}

$id = $_GET['id'];
$product = getProductById($pdo, $id);

// If product not found, redirect
if (!$product) {
    header("Location: products.php");
    exit;
}

// Handle product update
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_product'])) {
    $name = $_POST['name'];
    $price = $_POST['price'];
    $stock = $_POST['stock'];
    $discount = !empty($_POST['discount']) ? $_POST['discount'] : null;
    $description = $_POST['description'];
    $category = !empty($_POST['category']) ? $_POST['category'] : null;

    // Handle image upload if a new image is provided
    $imagePath = $product['image']; // Keep existing image by default
    if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
        $targetDir = "../uploads/";
        if (!is_dir($targetDir)) {
            mkdir($targetDir, 0755, true);
        }
        $imageName = basename($_FILES['image']['name']);
        $targetFile = $targetDir . uniqid() . '_' . $imageName;
        move_uploaded_file($_FILES['image']['tmp_name'], $targetFile);
        $imagePath = str_replace("../", "", $targetFile); // Store relative path
    }

    $stmt = $pdo->prepare("UPDATE products SET name = ?, description = ?, price = ?, stock = ?, discount = ?, category = ?, image = ? WHERE id = ?");
    $stmt->execute([$name, $description, $price, $stock, $discount, $category, $imagePath, $id]);

    // Redirect to avoid form resubmission
    header("Location: products.php?updated=1");
    exit;
}

// Get all unique categories for dropdown
$categories = [];
$categoryStmt = $pdo->query("SELECT DISTINCT category FROM products WHERE category IS NOT NULL ORDER BY category");
if ($categoryStmt) {
    while ($row = $categoryStmt->fetch()) {
        $categories[] = $row['category'];
    }
}

// Include header
include 'includes/header.php';
?>

<div class="container-fluid">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h1 class="h2">Edit Product</h1>
        <a href="products.php" class="btn btn-secondary">
            <i class="fas fa-arrow-left"></i> Back to Products
        </a>
    </div>
    
    <div class="card">
        <div class="card-header bg-white">
            <h5 class="mb-0">Edit Product: <?php echo htmlspecialchars($product['name']); ?></h5>
        </div>
        <div class="card-body">
            <div class="row">
                <div class="col-md-4 mb-4 mb-md-0">
                    <div class="card">
                        <div class="card-body text-center">
                            <h6 class="card-title">Current Image</h6>
                            <img src="../<?php echo htmlspecialchars($product['image']); ?>" 
                                 alt="<?php echo htmlspecialchars($product['name']); ?>" 
                                 class="img-fluid mb-3" style="max-height: 200px;">
                            <p class="small text-muted">Upload a new image to replace the current one</p>
                        </div>
                    </div>
                </div>
                
                <div class="col-md-8">
                    <form action="" method="POST" enctype="multipart/form-data">
                        <div class="mb-3">
                            <label class="form-label">Product Name</label>
                            <input type="text" name="name" class="form-control" value="<?php echo htmlspecialchars($product['name']); ?>" required>
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label">Product Description</label>
                            <textarea name="description" class="form-control" rows="3"><?php echo htmlspecialchars($product['description'] ?? ''); ?></textarea>
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label">Category</label>
                            <div class="input-group">
                                <input type="text" name="category" list="categoryList" class="form-control" 
                                       value="<?php echo htmlspecialchars($product['category'] ?? ''); ?>" 
                                       placeholder="Select or enter a new category">
                                <datalist id="categoryList">
                                    <?php foreach ($categories as $cat): ?>
                                        <option value="<?php echo htmlspecialchars($cat); ?>">
                                    <?php endforeach; ?>
                                </datalist>
                            </div>
                        </div>
                        
                        <div class="row mb-3">
                            <div class="col-md-4">
                                <label class="form-label">Price</label>
                                <div class="input-group">
                                    <span class="input-group-text">$</span>
                                    <input type="number" name="price" step="0.01" class="form-control" value="<?php echo $product['price']; ?>" required>
                                </div>
                            </div>
                            
                            <div class="col-md-4">
                                <label class="form-label">Stock</label>
                                <input type="number" name="stock" class="form-control" value="<?php echo $product['stock']; ?>" required>
                            </div>
                            
                            <div class="col-md-4">
                                <label class="form-label">Discount (optional)</label>
                                <div class="input-group">
                                    <span class="input-group-text">$</span>
                                    <input type="number" name="discount" step="0.01" class="form-control" value="<?php echo $product['discount']; ?>">
                                </div>
                            </div>
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label">New Product Image (leave empty to keep current)</label>
                            <input type="file" name="image" class="form-control" accept="image/*">
                        </div>
                        
                        <div class="d-grid gap-2 d-md-flex justify-content-md-end">
                            <a href="products.php" class="btn btn-light">Cancel</a>
                            <button type="submit" name="update_product" class="btn btn-primary">
                                <i class="fas fa-save"></i> Update Product
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?> 