<?php
// Start session if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Clear all admin session variables
unset($_SESSION['admin_id']);
unset($_SESSION['admin_username']);
unset($_SESSION['role']);

// Destroy the session
session_destroy();

// Redirect to main login page with logout message
header("Location: ../login.php?logout=1");
exit;
