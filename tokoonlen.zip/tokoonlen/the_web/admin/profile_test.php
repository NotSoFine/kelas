<?php
// Enable error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Start session if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once '../db.php';

echo "<h1>Profile Test</h1>";
echo "<pre>";

// Debug session info
echo "Session data:\n";
print_r($_SESSION);

// Get admin ID
$admin_id = $_SESSION['admin_id'] ?? 0;
echo "\nAdmin ID: $admin_id\n";

// Try different role queries
$roles = ['operator', 'admin', 'adm'];

foreach ($roles as $role) {
    echo "\nTrying role: $role\n";
    $stmt = $pdo->prepare("SELECT * FROM users WHERE id = ? AND role = ?");
    $stmt->execute([$admin_id, $role]);
    $admin = $stmt->fetch();
    
    if ($admin) {
        echo "FOUND with role: $role\n";
        echo "Username: " . htmlspecialchars($admin['username']) . "\n";
    } else {
        echo "NOT found with role: $role\n";
    }
}

// Try with no role restriction
echo "\nTrying without role restriction:\n";
$stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
$stmt->execute([$admin_id]);
$admin = $stmt->fetch();

if ($admin) {
    echo "User found!\n";
    echo "Username: " . htmlspecialchars($admin['username']) . "\n";
    echo "Role: " . htmlspecialchars($admin['role']) . "\n";
} else {
    echo "User not found, even without role restriction!\n";
}

echo "</pre>";
?> 