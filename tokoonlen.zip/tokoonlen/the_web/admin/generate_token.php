<?php
require_once '../db.php';
require_once 'includes/config.php';
require_once 'includes/auth_check.php';

// Only existing admins can generate tokens
if (!isset($_SESSION['admin_id']) || $_SESSION['role'] !== 'operator') {
    header("Location: login.php");
    exit;
}

$registrationLink = '';
$baseUrl = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]";
$path = dirname($_SERVER['PHP_SELF']);
$registrationLink = $baseUrl . $path . '/register.php?token=' . ADMIN_REGISTER_TOKEN;

// Include header
include 'includes/header.php';
?>

<div class="container-fluid">
    <div class="row mb-4">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header bg-primary text-white">
                    <h5 class="mb-0"><i class="fas fa-key me-2"></i>Generate Admin Registration Token</h5>
                </div>
                <div class="card-body">
                    <div class="alert alert-info">
                        <i class="fas fa-info-circle me-2"></i>
                        Use this page to generate a secure registration link for new admin accounts. 
                        The link contains a token that allows the recipient to register as an admin without being logged in.
                    </div>
                    
                    <h6 class="mb-3">Registration Link:</h6>
                    <div class="input-group mb-3">
                        <input type="text" class="form-control" id="registrationLink" value="<?php echo htmlspecialchars($registrationLink); ?>" readonly>
                        <button class="btn btn-outline-secondary" type="button" id="copyButton" onclick="copyToClipboard()">
                            <i class="fas fa-copy"></i> Copy
                        </button>
                    </div>
                    
                    <div class="alert alert-warning">
                        <i class="fas fa-exclamation-triangle me-2"></i>
                        <strong>Security Warning:</strong> This link contains a secure token that grants admin registration privileges.
                        Share it only with trusted individuals who need admin access.
                    </div>
                    
                    <hr>
                    
                    <h6 class="mb-3">Or Share the Token Directly:</h6>
                    <div class="input-group mb-3">
                        <input type="text" class="form-control" id="tokenOnly" value="<?php echo htmlspecialchars(ADMIN_REGISTER_TOKEN); ?>" readonly>
                        <button class="btn btn-outline-secondary" type="button" id="copyTokenButton" onclick="copyTokenToClipboard()">
                            <i class="fas fa-copy"></i> Copy
                        </button>
                    </div>
                    <p class="text-muted">
                        The recipient can enter this token on the registration page.
                    </p>
                </div>
                <div class="card-footer">
                    <a href="index.php" class="btn btn-secondary">
                        <i class="fas fa-arrow-left me-2"></i>Back to Dashboard
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
function copyToClipboard() {
    var copyText = document.getElementById("registrationLink");
    copyText.select();
    copyText.setSelectionRange(0, 99999); /* For mobile devices */
    document.execCommand("copy");
    
    var copyButton = document.getElementById("copyButton");
    copyButton.innerHTML = '<i class="fas fa-check"></i> Copied!';
    setTimeout(function() {
        copyButton.innerHTML = '<i class="fas fa-copy"></i> Copy';
    }, 2000);
}

function copyTokenToClipboard() {
    var copyText = document.getElementById("tokenOnly");
    copyText.select();
    copyText.setSelectionRange(0, 99999); /* For mobile devices */
    document.execCommand("copy");
    
    var copyButton = document.getElementById("copyTokenButton");
    copyButton.innerHTML = '<i class="fas fa-check"></i> Copied!';
    setTimeout(function() {
        copyButton.innerHTML = '<i class="fas fa-copy"></i> Copy';
    }, 2000);
}
</script>

<?php include 'includes/footer.php'; ?> 