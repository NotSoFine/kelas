<?php
require_once '../db.php';
require_once 'includes/functions.php';

// Authentication is handled in functions.php

// Check if order ID is provided
if (!isset($_GET['id'])) {
    header('Location: orders.php');
    exit;
}

$order_id = $_GET['id'];

// Fetch order details
try {
    // Get order data
    $stmt = $pdo->prepare("SELECT o.*, u.username 
                           FROM orders o 
                           JOIN users u ON o.user_id = u.id 
                           WHERE o.id = ?");
    $stmt->execute([$order_id]);
    $order = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$order) {
        // Order not found
        header('Location: orders.php');
        exit;
    }
    
    // Fetch order items
    $stmt = $pdo->prepare("SELECT * FROM order_items WHERE order_id = ?");
    $stmt->execute([$order_id]);
    $order_items = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
} catch (PDOException $e) {
    // Handle database error
    die("Error fetching order details: " . $e->getMessage());
}

// Get store information from settings
$storeName = "EcomPro";
$storeAddress = "123 Main St, City";
$storePhone = "(123) 456-7890";
$storeEmail = "info@ecompro.com";

// Try to get actual store info from settings table if available
try {
    $stmt = $pdo->prepare("SELECT setting_key, setting_value FROM settings WHERE setting_key IN ('site_name', 'contact_address', 'contact_phone', 'contact_email')");
    $stmt->execute();
    $settings = $stmt->fetchAll(PDO::FETCH_KEY_PAIR);
    
    if (isset($settings['site_name'])) {
        $storeName = $settings['site_name'];
    }
    if (isset($settings['contact_address'])) {
        $storeAddress = $settings['contact_address'];
    }
    if (isset($settings['contact_phone'])) {
        $storePhone = $settings['contact_phone'];
    }
    if (isset($settings['contact_email'])) {
        $storeEmail = $settings['contact_email'];
    }
} catch (PDOException $e) {
    // Just use the default values if there's an error
}

// Calculate subtotal
$subtotal = $order['total_amount'] - $order['shipping_fee'] - $order['tax_amount'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Receipt - Order #<?php echo htmlspecialchars($order['order_code'] ?? 'Unknown'); ?></title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Hide URL and other browser elements when printing -->
    <meta name="format-detection" content="telephone=no">
    <meta name="format-detection" content="date=no">
    <meta name="format-detection" content="address=no">
    <meta name="format-detection" content="email=no">
    
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome for icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

    <style>
        body {
            font-family: 'Courier New', monospace;
            font-size: 14px;
            padding: 20px;
            background-color: #fff;
        }
        .receipt-container {
            max-width: 800px;
            margin: 0 auto;
            padding: 20px;
            border: 1px solid #ddd;
            page-break-after: avoid;
            page-break-inside: avoid;
        }
        .receipt-header {
            text-align: center;
            margin-bottom: 20px;
            padding-bottom: 10px;
            border-bottom: 1px dashed #000;
        }
        .receipt-header h1 {
            font-size: 24px;
            margin-bottom: 5px;
        }
        .receipt-header p {
            margin: 3px 0;
        }
        .receipt-details {
            margin-bottom: 20px;
            padding-bottom: 10px;
            border-bottom: 1px dashed #000;
        }
        .receipt-details .row {
            margin-bottom: 5px;
        }
        .receipt-items {
            margin-bottom: 20px;
            padding-bottom: 10px;
            border-bottom: 1px dashed #000;
        }
        .receipt-item {
            padding: 5px 0;
            border-bottom: 1px dotted #ddd;
        }
        .receipt-item:last-child {
            border-bottom: none;
        }
        .receipt-totals {
            margin-bottom: 20px;
            padding-bottom: 10px;
            border-bottom: 1px dashed #000;
        }
        .receipt-footer {
            text-align: center;
            margin-top: 20px;
            page-break-after: avoid;
        }
        .receipt-footer p {
            margin: 3px 0;
        }
        .total-line {
            font-weight: bold;
        }
        .admin-mark {
            font-size: 12px;
            text-align: right;
            color: #666;
            margin-top: 10px;
            margin-bottom: -5px;
        }
        @media print {
            .no-print {
                display: none !important;
            }
            body {
                padding: 0;
                margin: 0;
                -webkit-print-color-adjust: exact !important;
                print-color-adjust: exact !important;
                background-color: #fff;
            }
            .receipt-container {
                width: 100%;
                max-width: 100%;
                border: none;
                padding: 0;
                margin: 0;
                height: auto;
            }
            @page {
                size: auto;
                margin: 10mm;
            }
            .url-info {
                display: none !important;
            }
            .print-only {
                display: block !important;
            }
            html {
                height: auto !important;
                overflow: hidden !important;
            }
            html, body {
                height: auto !important;
                overflow: visible !important;
                page-break-after: avoid;
                page-break-before: avoid;
            }
            /* Force background color to white */
            * {
                background-color: #fff !important;
            }
        }
        .print-only {
            display: none;
        }
        .receipt-actions {
            margin-bottom: 20px;
        }
        /* Fix for URL showing in print */
        @page {
            size: auto;
            margin: 0mm;
        }
        @media print {
            html, body {
                height: auto !important;
                overflow: visible !important;
            }
        }
        /* Remove extra spacing */
        @media print {
            .receipt-container:after {
                content: none !important;
            }
            body:after {
                content: none !important;
            }
        }
    </style>
    
    <script>
        // This function attempts to hide the URL from the footer when printing
        function printReceiptWithoutURL() {
            // Set print CSS
            var style = document.createElement('style');
            style.innerHTML = `
                @page {
                    size: auto;
                    margin: 0mm !important;
                }
                body {
                    margin: 10mm !important;
                    -webkit-print-color-adjust: exact !important;
                    print-color-adjust: exact !important;
                    background-color: #fff !important;
                }
                html, body {
                    height: auto !important;
                    overflow: visible !important;
                }
                .receipt-container {
                    page-break-inside: avoid !important;
                    page-break-after: avoid !important;
                }
                .receipt-footer {
                    page-break-after: avoid !important;
                }
                * {
                    background-color: #fff !important;
                }
            `;
            document.head.appendChild(style);
            
            // Remove URL from the footer
            document.title = " ";
            
            // Print
            setTimeout(function() {
                window.print();
                
                // Clean up
                document.head.removeChild(style);
            }, 300);
            
            return false;
        }
        
        // Auto-trigger print if in print mode
        window.onload = function() {
            <?php if (isset($_GET['print_mode']) && $_GET['print_mode'] == '1'): ?>
            printReceiptWithoutURL();
            <?php endif; ?>
        };
    </script>
</head>
<body>
    <div class="receipt-container">
        <!-- Print Controls (won't show when printing) -->
        <div class="receipt-actions no-print">
            <div class="d-flex justify-content-between mb-3">
                <a href="orders.php" class="btn btn-secondary">
                    <i class="fas fa-arrow-left"></i> Back to Orders
                </a>
                <div>
                    <button onclick="printReceiptWithoutURL()" class="btn btn-primary">
                        <i class="fas fa-print"></i> Print Receipt
                    </button>
                </div>
            </div>
        </div>
        
        <div class="admin-mark no-print">
            <i class="fas fa-user-shield"></i> Admin-generated receipt
        </div>
        
        <!-- Receipt Header -->
        <div class="receipt-header">
            <h1><?php echo htmlspecialchars($storeName); ?></h1>
            <p><?php echo htmlspecialchars($storeAddress); ?></p>
            <p>Phone: <?php echo htmlspecialchars($storePhone); ?></p>
            <p>Email: <?php echo htmlspecialchars($storeEmail); ?></p>
            <h2>RECEIPT</h2>
        </div>
        
        <!-- Receipt Details -->
        <div class="receipt-details">
            <div class="row">
                <div class="col-6">
                    <strong>Order #:</strong> <?php echo htmlspecialchars($order['order_code'] ?? 'Unknown'); ?>
                </div>
                <div class="col-6 text-end">
                    <strong>Date:</strong> <?php echo date('F j, Y', strtotime($order['created_at'])); ?>
                </div>
            </div>
            <div class="row">
                <div class="col-6">
                    <strong>Customer:</strong> <?php echo htmlspecialchars($order['username'] ?? 'Unknown'); ?><br>
                    <strong>User ID:</strong> <?php echo htmlspecialchars($order['user_id'] ?? 'Unknown'); ?>
                </div>
                <div class="col-6 text-end">
                    <strong>Time:</strong> <?php echo date('g:i A', strtotime($order['created_at'])); ?><br>
                    <strong>Status:</strong> <?php echo ucfirst($order['status'] ?? 'Unknown'); ?>
                </div>
            </div>
            <div class="row">
                <div class="col-12">
                    <strong>Payment Method:</strong> <?php echo ucfirst(str_replace('_', ' ', $order['payment_method'] ?? 'Unknown')); ?>
                </div>
            </div>
            <div class="row">
                <div class="col-12">
                    <strong>Shipping Method:</strong> <?php echo ucfirst($order['shipping_method'] ?? 'Standard'); ?> Shipping
                </div>
            </div>
            <div class="row">
                <div class="col-12">
                    <strong>Shipping Address:</strong><br>
                    <?php echo nl2br(htmlspecialchars($order['shipping_address'] ?? 'Not provided')); ?>
                </div>
            </div>
        </div>
        
        <!-- Receipt Items -->
        <div class="receipt-items">
            <div class="row fw-bold mb-2">
                <div class="col-6">Description</div>
                <div class="col-2 text-center">Qty</div>
                <div class="col-2 text-end">Price</div>
                <div class="col-2 text-end">Total</div>
            </div>
            
            <?php foreach ($order_items as $item): ?>
                <div class="receipt-item row">
                    <div class="col-6"><?php echo htmlspecialchars($item['product_name'] ?? 'Unknown Product'); ?></div>
                    <div class="col-2 text-center"><?php echo $item['quantity']; ?></div>
                    <div class="col-2 text-end">
                        <?php 
                        $price = $item['price'] ?? 0;
                        $discount = $item['discount'] ?? 0;
                        echo '$' . number_format(($price - $discount), 2);
                        ?>
                    </div>
                    <div class="col-2 text-end">
                        <?php 
                        $price = $item['price'] ?? 0;
                        $discount = $item['discount'] ?? 0;
                        $quantity = $item['quantity'] ?? 1;
                        echo '$' . number_format(($price - $discount) * $quantity, 2);
                        ?>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
        
        <!-- Receipt Totals -->
        <div class="receipt-totals">
            <div class="row">
                <div class="col-9 text-end">Subtotal:</div>
                <div class="col-3 text-end"><?php echo '$' . number_format($subtotal, 2); ?></div>
            </div>
            <div class="row">
                <div class="col-9 text-end">Shipping:</div>
                <div class="col-3 text-end"><?php echo '$' . number_format($order['shipping_fee'] ?? 0, 2); ?></div>
            </div>
            <div class="row">
                <div class="col-9 text-end">Tax:</div>
                <div class="col-3 text-end"><?php echo '$' . number_format($order['tax_amount'] ?? 0, 2); ?></div>
            </div>
            <div class="row total-line">
                <div class="col-9 text-end">TOTAL:</div>
                <div class="col-3 text-end"><?php echo '$' . number_format($order['total_amount'] ?? 0, 2); ?></div>
            </div>
        </div>
        
        <!-- Receipt Footer -->
        <div class="receipt-footer">
            <p>Thank you for your purchase!</p>
            <p>This is an official receipt issued by <?php echo htmlspecialchars($storeName); ?></p>
            <p>For questions or support, contact us at <?php echo htmlspecialchars($storeEmail); ?></p>
            <p><?php echo date('Y'); ?> &copy; <?php echo htmlspecialchars($storeName); ?></p>
        </div>
    </div>
    
    <!-- Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html> 