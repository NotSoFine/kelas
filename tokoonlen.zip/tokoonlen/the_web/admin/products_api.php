<?php
require_once '../db.php';
require_once 'includes/functions.php';
require_once '../includes/api_client.php';

// Authentication is now handled in includes/header.php

// Initialize API client
$api = new ApiClient();

// Handle product insertion
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_product'])) {
    $name = $_POST['name'];
    $price = $_POST['price'];
    $stock = $_POST['stock'];
    $discount = !empty($_POST['discount']) ? $_POST['discount'] : null;
    $category = $_POST['category'];
    
    // Handle image upload
    $imagePath = '';
    if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
        $targetDir = "../uploads/";
        if (!is_dir($targetDir)) {
            mkdir($targetDir, 0755, true);
        }
        $imageName = basename($_FILES['image']['name']);
        $targetFile = $targetDir . uniqid() . '_' . $imageName;
        move_uploaded_file($_FILES['image']['tmp_name'], $targetFile);
        $imagePath = str_replace("../", "", $targetFile); // Store relative path
    }
    
    // Create product using API
    $productData = [
        'name' => $name,
        'price' => $price,
        'stock' => $stock,
        'discount' => $discount,
        'category' => $category,
        'image' => $imagePath
    ];
    
    $response = $api->addProduct($productData);
    
    // Check response
    if ($response['status'] === 'success') {
        // Redirect to avoid form resubmission
        header("Location: products_api.php?success=1");
        exit;
    } else {
        $error = $response['message'];
    }
}

// Handle search functionality
$searchPerformed = false;
$products = [];

if (isset($_GET['search']) && !empty($_GET['search'])) {
    $searchQuery = $_GET['search'];
    $response = $api->searchProducts($searchQuery);
    if ($response['status'] === 'success') {
        $products = $response['data'];
    }
    $searchPerformed = true;
} else {
    // Get all products with pagination
    $page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
    $limit = isset($_GET['limit']) ? (int)$_GET['limit'] : 10;
    
    $response = $api->getProducts($page, $limit);
    
    // Debug information
    if ($response['status'] !== 'success') {
        $error = "API Error: " . $response['message'];
        // Log the error
        error_log("Products API Error: " . $response['message']);
    }
    
    // Check if products exist in the response
    if ($response['status'] === 'success') {
        if (empty($response['data']['products'])) {
            error_log("API returned success but no products were found in the data");
            // Dump the response structure for debugging
            error_log("API Response structure: " . print_r($response, true));
        } else {
            $products = $response['data']['products'];
            $pagination = $response['data']['pagination'];
        }
    }
}

// Include header
include 'includes/header.php';
?>

<div class="container-fluid">
    <h1 class="h2 mb-4">Products Management (API Version)</h1>
    
    <?php if (isset($_GET['success'])): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            Product successfully added!
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>
    
    <?php if (isset($error)): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <?php echo $error; ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>
    
    <!-- Add Product Form -->
    <div class="card mb-4">
        <div class="card-header bg-white">
            <h5 class="mb-0">Add New Product</h5>
        </div>
        <div class="card-body">
            <form action="" method="POST" enctype="multipart/form-data" class="row g-3">
                <div class="col-md-6">
                    <label class="form-label">Product Name</label>
                    <input type="text" name="name" class="form-control" required>
                </div>
                
                <div class="col-md-2">
                    <label class="form-label">Price</label>
                    <div class="input-group">
                        <span class="input-group-text">$</span>
                        <input type="number" name="price" step="0.01" class="form-control" required>
                    </div>
                </div>
                
                <div class="col-md-2">
                    <label class="form-label">Stock</label>
                    <input type="number" name="stock" class="form-control" required>
                </div>
                
                <div class="col-md-2">
                    <label class="form-label">Discount (optional)</label>
                    <div class="input-group">
                        <span class="input-group-text">$</span>
                        <input type="number" name="discount" step="0.01" class="form-control">
                    </div>
                </div>
                
                <div class="col-md-6">
                    <label class="form-label">Category</label>
                    <input type="text" name="category" class="form-control" placeholder="Enter product category">
                </div>
                
                <div class="col-md-12">
                    <label class="form-label">Product Image</label>
                    <input type="file" name="image" class="form-control" accept="image/*" required>
                </div>
                
                <div class="col-12">
                    <button type="submit" name="add_product" class="btn btn-primary">
                        <i class="fas fa-plus-circle"></i> Add Product
                    </button>
                </div>
            </form>
        </div>
    </div>
    
    <!-- Products Table -->
    <div class="card">
        <div class="card-header bg-white">
            <div class="d-flex justify-content-between align-items-center">
                <h5 class="mb-0">
                    <?php if ($searchPerformed): ?>
                        Search Results for "<?php echo htmlspecialchars($_GET['search']); ?>"
                    <?php else: ?>
                        All Products
                    <?php endif; ?>
                </h5>
                <form class="d-flex" method="GET">
                    <input class="form-control me-2" type="search" name="search" placeholder="Search products..." aria-label="Search" value="<?php echo isset($_GET['search']) ? htmlspecialchars($_GET['search']) : ''; ?>">
                    <button class="btn btn-outline-primary" type="submit">Search</button>
                </form>
            </div>
        </div>
        <div class="card-body">
            <?php if (empty($products)): ?>
                <div class="alert alert-info">
                    <?php echo $searchPerformed ? 'No products found matching your search.' : 'No products found.'; ?>
                </div>
            <?php else: ?>
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Image</th>
                                <th>Name</th>
                                <th>Price</th>
                                <th>Stock</th>
                                <th>Discount</th>
                                <th>Category</th>
                                <th>Created At</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($products as $product): ?>
                                <tr>
                                    <td><?php echo $product['id']; ?></td>
                                    <td>
                                        <img src="../<?php echo htmlspecialchars($product['image']); ?>" 
                                             alt="<?php echo htmlspecialchars($product['name']); ?>" 
                                             class="img-thumbnail" style="width: 50px; height: 50px; object-fit: cover;">
                                    </td>
                                    <td><?php echo htmlspecialchars($product['name']); ?></td>
                                    <td><?php echo formatPrice($product['price']); ?></td>
                                    <td><?php echo $product['stock']; ?></td>
                                    <td>
                                        <?php if ($product['discount']): ?>
                                            <?php echo formatPrice($product['discount']); ?>
                                        <?php else: ?>
                                            -
                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo htmlspecialchars($product['category']); ?></td>
                                    <td><?php echo date('Y-m-d', strtotime($product['created_at'])); ?></td>
                                    <td>
                                        <a href="edit_product_api.php?id=<?php echo $product['id']; ?>" class="btn btn-sm btn-primary">
                                            <i class="fas fa-edit"></i>
                                        </a>
                                        <button type="button" class="btn btn-sm btn-danger delete-product" data-id="<?php echo $product['id']; ?>">
                                            <i class="fas fa-trash"></i>
                                        </button>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
                
                <?php if (!$searchPerformed && isset($pagination)): ?>
                <nav aria-label="Product pagination">
                    <ul class="pagination justify-content-center">
                        <?php if ($pagination['page'] > 1): ?>
                            <li class="page-item">
                                <a class="page-link" href="?page=<?php echo ($pagination['page'] - 1); ?>&limit=<?php echo $pagination['limit']; ?>">
                                    Previous
                                </a>
                            </li>
                        <?php else: ?>
                            <li class="page-item disabled">
                                <span class="page-link">Previous</span>
                            </li>
                        <?php endif; ?>
                        
                        <?php for ($i = 1; $i <= $pagination['total_pages']; $i++): ?>
                            <li class="page-item <?php echo ($i == $pagination['page']) ? 'active' : ''; ?>">
                                <a class="page-link" href="?page=<?php echo $i; ?>&limit=<?php echo $pagination['limit']; ?>">
                                    <?php echo $i; ?>
                                </a>
                            </li>
                        <?php endfor; ?>
                        
                        <?php if ($pagination['page'] < $pagination['total_pages']): ?>
                            <li class="page-item">
                                <a class="page-link" href="?page=<?php echo ($pagination['page'] + 1); ?>&limit=<?php echo $pagination['limit']; ?>">
                                    Next
                                </a>
                            </li>
                        <?php else: ?>
                            <li class="page-item disabled">
                                <span class="page-link">Next</span>
                            </li>
                        <?php endif; ?>
                    </ul>
                </nav>
                <?php endif; ?>
            <?php endif; ?>
        </div>
    </div>
</div>

<!-- Delete Confirmation Modal -->
<div class="modal fade" id="deleteModal" tabindex="-1" aria-labelledby="deleteModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="deleteModalLabel">Confirm Delete</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                Are you sure you want to delete this product?
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                <button type="button" class="btn btn-danger" id="confirmDelete">Delete</button>
            </div>
        </div>
    </div>
</div>

<script>
    // Handle delete confirmation
    document.addEventListener('DOMContentLoaded', function() {
        const deleteModal = new bootstrap.Modal(document.getElementById('deleteModal'));
        let productIdToDelete = null;
        
        // Set up delete buttons
        document.querySelectorAll('.delete-product').forEach(button => {
            button.addEventListener('click', function() {
                productIdToDelete = this.getAttribute('data-id');
                deleteModal.show();
            });
        });
        
        // Handle delete confirmation
        document.getElementById('confirmDelete').addEventListener('click', function() {
            if (productIdToDelete) {
                // Use fetch to call the API
                fetch(`../api/products.php?id=${productIdToDelete}`, {
                    method: 'DELETE',
                    credentials: 'same-origin' // Include cookies for authentication
                })
                .then(response => response.json())
                .then(data => {
                    if (data.status === 'success') {
                        // Refresh the page to show updated list
                        window.location.reload();
                    } else {
                        alert('Error: ' + data.message);
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    alert('An error occurred. Please try again.');
                });
                
                deleteModal.hide();
            }
        });
    });
</script>

<?php include 'includes/footer.php'; ?> 