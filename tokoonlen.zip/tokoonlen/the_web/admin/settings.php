<?php
require_once '../db.php';
require_once 'includes/functions.php';

// Authentication is now handled in includes/header.php

// Get current settings
$settings = [];
try {
    // Check if settings table exists
    $check = $pdo->query("SHOW TABLES LIKE 'settings'");
    if ($check->rowCount() == 0) {
        // Create settings table if it doesn't exist
        $pdo->exec("CREATE TABLE settings (
            id INT AUTO_INCREMENT PRIMARY KEY,
            setting_key VARCHAR(100) NOT NULL UNIQUE,
            setting_value TEXT,
            setting_type VARCHAR(50) DEFAULT 'text',
            setting_group VARCHAR(50) DEFAULT 'general',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        )");
        
        // Insert default settings
        $default_settings = [
            ['site_name', 'eCompro', 'text', 'general'],
            ['site_description', 'Your Online Shopping Destination', 'textarea', 'general'],
            ['site_email', 'contact@ecompro.com', 'email', 'contact'],
            ['enable_reviews', '1', 'boolean', 'products'],
            ['products_per_page', '12', 'number', 'products'],
            ['shipping_fee', '5.00', 'number', 'checkout'],
            ['tax_rate', '7', 'number', 'checkout'],
            ['currency_symbol', '$', 'text', 'general'],
            ['phone_number', '+1234567890', 'text', 'contact'],
            ['address', '123 Shopping St, Ecommerce City, 12345', 'textarea', 'contact']
        ];
        
        $stmt = $pdo->prepare("INSERT INTO settings (setting_key, setting_value, setting_type, setting_group) VALUES (?, ?, ?, ?)");
        foreach ($default_settings as $setting) {
            $stmt->execute($setting);
        }
    }
    
    // Get all settings
    $stmt = $pdo->query("SELECT * FROM settings ORDER BY setting_group, id");
    while ($row = $stmt->fetch()) {
        $settings[$row['setting_key']] = $row;
    }
} catch (PDOException $e) {
    $error = "Database error: " . $e->getMessage();
}

// Handle form submission
$success_message = '';
$error_message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_settings'])) {
    try {
        // Begin transaction
        $pdo->beginTransaction();
        
        // Get all settings from the form
        foreach ($_POST as $key => $value) {
            // Skip non-setting fields
            if ($key === 'update_settings') continue;
            
            // Update setting in database
            $stmt = $pdo->prepare("UPDATE settings SET setting_value = ? WHERE setting_key = ?");
            $stmt->execute([$value, $key]);
        }
        
        // Commit transaction
        $pdo->commit();
        
        $success_message = "Settings updated successfully!";
        
        // Refresh settings
        $stmt = $pdo->query("SELECT * FROM settings ORDER BY setting_group, id");
        while ($row = $stmt->fetch()) {
            $settings[$row['setting_key']] = $row;
        }
    } catch (PDOException $e) {
        // Rollback transaction on error
        $pdo->rollBack();
        $error_message = "Error updating settings: " . $e->getMessage();
    }
}

// Group settings by their group
$grouped_settings = [];
foreach ($settings as $key => $setting) {
    $group = $setting['setting_group'];
    if (!isset($grouped_settings[$group])) {
        $grouped_settings[$group] = [];
    }
    $grouped_settings[$group][$key] = $setting;
}

// Include header
include 'includes/header.php';
?>

<div class="container-fluid">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h1 class="h2">Store Settings</h1>
        <a href="index.php" class="btn btn-secondary">
            <i class="fas fa-arrow-left"></i> Back to Dashboard
        </a>
    </div>
    
    <?php if (!empty($success_message)): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?php echo $success_message; ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>
    
    <?php if (!empty($error_message)): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <?php echo $error_message; ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>
    
    <div class="card">
        <div class="card-header bg-white">
            <ul class="nav nav-tabs card-header-tabs" id="settingsTabs" role="tablist">
                <?php 
                $first = true;
                foreach ($grouped_settings as $group => $group_settings): 
                    $group_id = 'tab-' . $group;
                ?>
                <li class="nav-item" role="presentation">
                    <button class="nav-link <?php echo $first ? 'active' : ''; ?>" 
                            id="<?php echo $group_id; ?>-tab" 
                            data-bs-toggle="tab" 
                            data-bs-target="#<?php echo $group_id; ?>" 
                            type="button" 
                            role="tab" 
                            aria-controls="<?php echo $group_id; ?>" 
                            aria-selected="<?php echo $first ? 'true' : 'false'; ?>">
                        <?php echo ucfirst($group); ?>
                    </button>
                </li>
                <?php 
                    $first = false;
                endforeach; 
                ?>
            </ul>
        </div>
        
        <div class="card-body">
            <form action="" method="POST">
                <div class="tab-content" id="settingsTabsContent">
                    <?php 
                    $first = true;
                    foreach ($grouped_settings as $group => $group_settings): 
                        $group_id = 'tab-' . $group;
                    ?>
                    <div class="tab-pane fade <?php echo $first ? 'show active' : ''; ?>" 
                         id="<?php echo $group_id; ?>" 
                         role="tabpanel" 
                         aria-labelledby="<?php echo $group_id; ?>-tab">
                        
                        <div class="row">
                            <?php foreach ($group_settings as $key => $setting): ?>
                                <div class="col-md-6 mb-3">
                                    <label for="<?php echo $key; ?>" class="form-label">
                                        <?php echo ucwords(str_replace('_', ' ', $key)); ?>
                                    </label>
                                    
                                    <?php if ($setting['setting_type'] === 'textarea'): ?>
                                        <textarea class="form-control" id="<?php echo $key; ?>" name="<?php echo $key; ?>" rows="3"><?php echo htmlspecialchars($setting['setting_value']); ?></textarea>
                                    
                                    <?php elseif ($setting['setting_type'] === 'boolean'): ?>
                                        <div class="form-check form-switch">
                                            <input class="form-check-input" type="checkbox" id="<?php echo $key; ?>" name="<?php echo $key; ?>" value="1" <?php echo $setting['setting_value'] == '1' ? 'checked' : ''; ?>>
                                            <label class="form-check-label" for="<?php echo $key; ?>">Enabled</label>
                                        </div>
                                    
                                    <?php elseif ($setting['setting_type'] === 'number'): ?>
                                        <input type="number" class="form-control" id="<?php echo $key; ?>" name="<?php echo $key; ?>" value="<?php echo htmlspecialchars($setting['setting_value']); ?>" step="0.01">
                                    
                                    <?php elseif ($setting['setting_type'] === 'email'): ?>
                                        <input type="email" class="form-control" id="<?php echo $key; ?>" name="<?php echo $key; ?>" value="<?php echo htmlspecialchars($setting['setting_value']); ?>">
                                    
                                    <?php else: ?>
                                        <input type="text" class="form-control" id="<?php echo $key; ?>" name="<?php echo $key; ?>" value="<?php echo htmlspecialchars($setting['setting_value']); ?>">
                                    
                                    <?php endif; ?>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                    <?php 
                        $first = false;
                    endforeach; 
                    ?>
                </div>
                
                <div class="d-grid gap-2 d-md-flex justify-content-md-end mt-4">
                    <button type="submit" name="update_settings" class="btn btn-primary">
                        <i class="fas fa-save me-1"></i> Save Settings
                    </button>
                </div>
            </form>
        </div>
    </div>
    
    <div class="row mt-4">
        <div class="col-md-6">
            <div class="card">
                <div class="card-header bg-white">
                    <h5 class="mb-0">Cache Management</h5>
                </div>
                <div class="card-body">
                    <p>Clear various caches to ensure changes take effect immediately.</p>
                    <div class="d-grid gap-2">
                        <button type="button" class="btn btn-outline-primary" disabled>
                            <i class="fas fa-trash-alt me-2"></i> Clear Cache
                        </button>
                        <p class="text-muted small">This feature will be available in a future update.</p>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="col-md-6">
            <div class="card">
                <div class="card-header bg-white">
                    <h5 class="mb-0">System Information</h5>
                </div>
                <div class="card-body">
                    <ul class="list-group list-group-flush">
                        <li class="list-group-item d-flex justify-content-between align-items-center">
                            PHP Version
                            <span class="badge bg-primary rounded-pill"><?php echo phpversion(); ?></span>
                        </li>
                        <li class="list-group-item d-flex justify-content-between align-items-center">
                            MySQL Version
                            <span class="badge bg-primary rounded-pill">
                                <?php 
                                    try {
                                        echo $pdo->query('SELECT VERSION()')->fetchColumn();
                                    } catch (PDOException $e) {
                                        echo 'Unknown';
                                    }
                                ?>
                            </span>
                        </li>
                        <li class="list-group-item d-flex justify-content-between align-items-center">
                            eCompro Version
                            <span class="badge bg-primary rounded-pill">1.0.0</span>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?> 