# eCompro Admin Panel

This is the admin panel for the eCompro e-commerce platform. It provides a modern and user-friendly interface for managing products, users, and other aspects of the e-commerce system.

## Features

- **Modern Dashboard**: Overview of key metrics and recent products
- **Product Management**: Add, edit, and delete products with image uploads
- **Search Functionality**: Search products by name, price, stock, or discount
- **Responsive Design**: Works on desktop and mobile devices
- **User-friendly Interface**: Clean and intuitive UI with Bootstrap 5

## Directory Structure

```
admin/
├── includes/
│   ├── header.php     # Common header with navbar and sidebar
│   ├── footer.php     # Common footer with scripts
│   └── functions.php  # Helper functions for the admin panel
├── index.php          # Dashboard page
├── products.php       # Products management page
├── edit_product.php   # Edit product page
└── delete_product.php # Delete product handler
```

## Installation

1. Make sure you have set up the database using the provided SQL file
2. Configure the database connection in `db.php`
3. Access the admin panel at `/the_web/admin/`

## Authentication

The admin panel requires authentication as an operator. Login credentials:
- Username: operator
- Password: operator123

## Search Functionality

The search feature allows searching products by:
- Product name
- Price
- Stock quantity
- Discount amount

The search uses SQL LIKE queries with wildcards for flexible matching.

## Credits

- Bootstrap 5 for the UI framework
- Font Awesome for icons
- PHP 8.2+ for the backend 