<?php
// Enable error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Start session
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once '../db.php';

// Get admin info
$admin_id = $_SESSION['admin_id'] ?? 0;
$username = $_SESSION['admin_username'] ?? '';
$role = $_SESSION['role'] ?? '';

// Get admin from database
$admin = null;
if ($admin_id > 0) {
    $stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
    $stmt->execute([$admin_id]);
    $admin = $stmt->fetch();
}

// Get all admins
$stmt = $pdo->query("SELECT id, username, role FROM users WHERE role IN ('operator', 'admin', 'adm')");
$all_admins = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Direct Admin Profile</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body {
            padding: 20px;
            background-color: #f8f9fa;
        }
        .container {
            max-width: 1200px;
        }
        .card {
            margin-bottom: 20px;
            box-shadow: 0 0.125rem 0.25rem rgba(0, 0, 0, 0.075);
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h1>Direct Admin Profile</h1>
            <div>
                <a href="index.php" class="btn btn-outline-secondary me-2">
                    <i class="fas fa-tachometer-alt"></i> Dashboard
                </a>
                <a href="fix_session.php" class="btn btn-outline-primary">
                    <i class="fas fa-wrench"></i> Fix Session
                </a>
            </div>
        </div>
        
        <div class="row">
            <!-- Profile Information -->
            <div class="col-md-8">
                <?php if (!$admin): ?>
                    <div class="alert alert-danger">
                        <h4>Error: Admin Not Found</h4>
                        <p>No admin user was found with ID: <?php echo $admin_id; ?></p>
                        <p>Current session data:</p>
                        <pre><?php print_r($_SESSION); ?></pre>
                    </div>
                    
                    <div class="card">
                        <div class="card-header bg-warning">
                            <h5 class="mb-0">Login as Admin</h5>
                        </div>
                        <div class="card-body">
                            <p>Select an admin user to log in as:</p>
                            <form action="../direct_login.php" method="post">
                                <div class="mb-3">
                                    <select name="admin_id" class="form-select">
                                        <?php foreach ($all_admins as $adm): ?>
                                            <option value="<?php echo $adm['id']; ?>">
                                                <?php echo htmlspecialchars($adm['username']); ?> 
                                                (<?php echo htmlspecialchars($adm['role']); ?>)
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                <div class="d-grid">
                                    <button type="submit" class="btn btn-warning">
                                        <i class="fas fa-sign-in-alt"></i> Log In as Selected Admin
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>
                <?php else: ?>
                    <div class="alert alert-success">
                        <h4>Admin Found!</h4>
                        <p><strong>ID:</strong> <?php echo htmlspecialchars($admin['id']); ?></p>
                        <p><strong>Username:</strong> <?php echo htmlspecialchars($admin['username']); ?></p>
                        <p><strong>Role:</strong> <?php echo htmlspecialchars($admin['role']); ?></p>
                    </div>
                    
                    <div class="card">
                        <div class="card-header bg-white">
                            <h5 class="mb-0">Account Information</h5>
                        </div>
                        <div class="card-body">
                            <form>
                                <div class="mb-3">
                                    <label class="form-label">Username</label>
                                    <input type="text" class="form-control" value="<?php echo htmlspecialchars($admin['username']); ?>" readonly>
                                </div>
                                
                                <div class="mb-3">
                                    <label class="form-label">Role</label>
                                    <input type="text" class="form-control" value="<?php echo htmlspecialchars($admin['role']); ?>" readonly>
                                </div>
                                
                                <div class="mb-3">
                                    <label class="form-label">ID</label>
                                    <input type="text" class="form-control" value="<?php echo htmlspecialchars($admin['id']); ?>" readonly>
                                </div>
                            </form>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
            
            <!-- Debug Information -->
            <div class="col-md-4">
                <div class="card">
                    <div class="card-header bg-info text-white">
                        <h5 class="mb-0">Session Information</h5>
                    </div>
                    <div class="card-body">
                        <pre><?php print_r($_SESSION); ?></pre>
                    </div>
                </div>
                
                <div class="card">
                    <div class="card-header bg-secondary text-white">
                        <h5 class="mb-0">Available Admins</h5>
                    </div>
                    <div class="card-body p-0">
                        <ul class="list-group list-group-flush">
                            <?php foreach ($all_admins as $adm): ?>
                                <li class="list-group-item d-flex justify-content-between align-items-center">
                                    <div>
                                        <strong><?php echo htmlspecialchars($adm['username']); ?></strong>
                                        <small class="text-muted d-block">ID: <?php echo $adm['id']; ?></small>
                                    </div>
                                    <span class="badge bg-primary"><?php echo htmlspecialchars($adm['role']); ?></span>
                                </li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                </div>
                
                <div class="d-grid gap-2 mt-3">
                    <a href="../direct_login.php" class="btn btn-primary">
                        <i class="fas fa-sign-in-alt me-2"></i> Direct Login Page
                    </a>
                    <a href="profile.php" class="btn btn-secondary">
                        <i class="fas fa-user me-2"></i> Regular Profile Page
                    </a>
                </div>
            </div>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html> 