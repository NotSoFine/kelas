<?php
require_once '../db.php';
require_once 'includes/functions.php';

// Authentication is now handled in includes/header.php

// Handle user insertion
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_user'])) {
    $username = $_POST['username'];
    $password = $_POST['password'];
    $role = $_POST['role'];

    // Check if username already exists
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM users WHERE username = ?");
    $stmt->execute([$username]);
    $userExists = $stmt->fetchColumn() > 0;
    
    if ($userExists) {
        $error = "Username already exists";
    } else {
        // In a production environment, you should hash the password
        // $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
        
        // Insert new user
        $stmt = $pdo->prepare("INSERT INTO users (username, password, role) VALUES (?, ?, ?)");
        $stmt->execute([$username, $password, $role]); // Use $hashedPassword in production
        
        // Redirect to avoid form resubmission
        header("Location: users.php?success=1");
        exit;
    }
}

// Handle search functionality
$users = [];
$searchPerformed = false;
if (isset($_GET['search']) && !empty($_GET['search'])) {
    $searchQuery = $_GET['search'];
    $users = searchUsers($pdo, $searchQuery);
    $searchPerformed = true;
} else {
    // Get all users if no search is performed
    $users = getAllUsers($pdo);
}

// Include header
include 'includes/header.php';
?>

<div class="container-fluid">
    <h1 class="h2 mb-4">Users Management</h1>
    
    <?php if (isset($_GET['success'])): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            User successfully added!
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>
    
    <?php if (isset($_GET['deleted'])): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            User successfully deleted!
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>
    
    <?php if (isset($_GET['error']) && $_GET['error'] === 'cannot_delete_self'): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            You cannot delete your own account!
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>
    
    <?php if (isset($_GET['error']) && $_GET['error'] === 'not_admin'): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            The selected user is not an admin!
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>
    
    <?php if (isset($error)): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <?php echo $error; ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>
    
    <!-- Add User Form -->
    <div class="card mb-4">
        <div class="card-header bg-white">
            <h5 class="mb-0">Add New User</h5>
        </div>
        <div class="card-body">
            <form action="" method="POST" class="row g-3">
                <div class="col-md-5">
                    <label class="form-label">Username</label>
                    <div class="input-group">
                        <span class="input-group-text"><i class="fas fa-user"></i></span>
                        <input type="text" name="username" class="form-control" required>
                    </div>
                </div>
                
                <div class="col-md-5">
                    <label class="form-label">Password</label>
                    <div class="input-group">
                        <span class="input-group-text"><i class="fas fa-lock"></i></span>
                        <input type="password" name="password" class="form-control" required>
                    </div>
                </div>
                
                <div class="col-md-2">
                    <label class="form-label">Role</label>
                    <select name="role" class="form-select" required>
                        <option value="user">Customer</option>
                        <option value="operator">Admin</option>
                    </select>
                </div>
                
                <div class="col-12">
                    <button type="submit" name="add_user" class="btn btn-primary">
                        <i class="fas fa-plus-circle"></i> Add User
                    </button>
                </div>
            </form>
        </div>
    </div>
    
    <!-- Users Table -->
    <div class="card">
        <div class="card-header bg-white">
            <div class="d-flex justify-content-between align-items-center">
                <h5 class="mb-0">
                    <?php if ($searchPerformed): ?>
                        Search Results for "<?php echo htmlspecialchars($_GET['search']); ?>"
                    <?php else: ?>
                        All Users
                    <?php endif; ?>
                </h5>
            </div>
        </div>
        <div class="card-body">
            <?php if (empty($users)): ?>
                <div class="alert alert-info">
                    <?php echo $searchPerformed ? 'No users found matching your search.' : 'No users found.'; ?>
                </div>
            <?php else: ?>
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Username</th>
                                <th>Role</th>
                                <th>Created At</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($users as $user): ?>
                                <tr>
                                    <td><?php echo $user['id']; ?></td>
                                    <td><?php echo htmlspecialchars($user['username']); ?></td>
                                    <td>
                                        <?php if ($user['role'] === 'operator'): ?>
                                            <span class="badge bg-primary">Admin</span>
                                        <?php else: ?>
                                            <span class="badge bg-secondary">Customer</span>
                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo isset($user['created_at']) ? date('Y-m-d', strtotime($user['created_at'])) : '-'; ?></td>
                                    <td>
                                        <a href="edit_user.php?id=<?php echo $user['id']; ?>" class="btn btn-sm btn-primary">
                                            <i class="fas fa-edit"></i>
                                        </a>
                                        <?php if ($user['id'] != $_SESSION['admin_id']): // Prevent deleting own account ?>
                                        <a href="#" class="btn btn-sm btn-danger" 
                                           onclick="if(confirm('Are you sure you want to delete this user?')) 
                                           window.location.href='delete_user.php?id=<?php echo $user['id']; ?>'">
                                            <i class="fas fa-trash"></i>
                                        </a>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?> 