<?php
// Enable error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Start session
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once 'db.php';
require_once 'admin/includes/config.php';

$error = '';
$success = '';

// Handle admin_id direct selection
if (isset($_POST['admin_id']) && !empty($_POST['admin_id'])) {
    $admin_id = (int)$_POST['admin_id'];
    
    // Get admin info
    $stmt = $pdo->prepare("SELECT * FROM users WHERE id = ? AND role IN ('operator', 'admin', 'adm') LIMIT 1");
    $stmt->execute([$admin_id]);
    $user = $stmt->fetch();
    
    if ($user) {
        // Set session variables
        $_SESSION['admin_id'] = $user['id'];
        $_SESSION['admin_username'] = $user['username'];
        $_SESSION['role'] = $user['role'];
        
        // Log the successful login
        $success = "Logged in successfully as {$user['username']} (ID: {$user['id']}, Role: {$user['role']})";
    } else {
        $error = "Invalid admin ID selected";
    }
}

// Check if form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['username'])) {
    $username = $_POST['username'] ?? '';
    $password = $_POST['password'] ?? '';
    
    if (empty($username) || empty($password)) {
        $error = "Please enter both username and password";
    } else {
        // Try to find admin user
        $stmt = $pdo->prepare("SELECT * FROM users WHERE username = ? AND role IN ('operator', 'admin', 'adm') LIMIT 1");
        $stmt->execute([$username]);
        $user = $stmt->fetch();
        
        if ($user && $password === $user['password']) { // In production, use password_verify()
            // Set session variables
            $_SESSION['admin_id'] = $user['id'];
            $_SESSION['admin_username'] = $user['username'];
            $_SESSION['role'] = $user['role'];
            
            // Log the successful login
            $success = "Logged in successfully as {$user['username']} (ID: {$user['id']}, Role: {$user['role']})";
        } else {
            $error = "Invalid username or password, or user is not an admin";
        }
    }
}

// Show current session
$session_info = '';
if (!empty($_SESSION)) {
    ob_start();
    print_r($_SESSION);
    $session_info = ob_get_clean();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Direct Admin Login</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body {
            padding: 20px;
            background-color: #f8f9fa;
        }
        .container {
            max-width: 800px;
        }
        .card {
            margin-bottom: 20px;
            box-shadow: 0 0.125rem 0.25rem rgba(0, 0, 0, 0.075);
        }
    </style>
</head>
<body>
    <div class="container">
        <h1 class="mb-4">Direct Admin Login</h1>
        
        <div class="row">
            <div class="col-md-6">
                <!-- Login Form -->
                <div class="card">
                    <div class="card-header bg-primary text-white">
                        <h5 class="mb-0">Admin Login</h5>
                    </div>
                    <div class="card-body">
                        <?php if (!empty($error)): ?>
                            <div class="alert alert-danger"><?php echo $error; ?></div>
                        <?php endif; ?>
                        
                        <?php if (!empty($success)): ?>
                            <div class="alert alert-success"><?php echo $success; ?></div>
                        <?php endif; ?>
                        
                        <form method="POST" action="">
                            <div class="mb-3">
                                <label for="username" class="form-label">Username</label>
                                <input type="text" class="form-control" id="username" name="username" placeholder="Enter admin username">
                            </div>
                            
                            <div class="mb-3">
                                <label for="password" class="form-label">Password</label>
                                <input type="password" class="form-control" id="password" name="password" placeholder="Enter password">
                            </div>
                            
                            <div class="d-grid">
                                <button type="submit" class="btn btn-primary">
                                    <i class="fas fa-sign-in-alt me-2"></i> Login
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
                
                <div class="d-grid gap-2">
                    <a href="admin/profile.php" class="btn btn-success">
                        <i class="fas fa-user me-2"></i> Go to Admin Profile
                    </a>
                    <a href="admin/direct_profile.php" class="btn btn-primary">
                        <i class="fas fa-user-shield me-2"></i> Direct Profile Page
                    </a>
                    <a href="admin/fix_session.php" class="btn btn-info">
                        <i class="fas fa-wrench me-2"></i> Session Repair Tool
                    </a>
                    <a href="admin/index.php" class="btn btn-secondary">
                        <i class="fas fa-tachometer-alt me-2"></i> Admin Dashboard
                    </a>
                </div>
            </div>
            
            <div class="col-md-6">
                <!-- Session Information -->
                <div class="card">
                    <div class="card-header bg-info text-white">
                        <h5 class="mb-0">Current Session</h5>
                    </div>
                    <div class="card-body">
                        <?php if (empty($session_info)): ?>
                            <div class="alert alert-warning">No session data available</div>
                        <?php else: ?>
                            <pre class="mb-0"><?php echo htmlspecialchars($session_info); ?></pre>
                        <?php endif; ?>
                    </div>
                </div>
                
                <!-- Admin Token Information -->
                <div class="card">
                    <div class="card-header bg-warning">
                        <h5 class="mb-0">Admin Information</h5>
                    </div>
                    <div class="card-body">
                        <p><strong>Admin Token:</strong> <?php echo ADMIN_REGISTER_TOKEN; ?></p>
                        <p class="mb-0"><em>Note: This token is only for emergency access and debugging.</em></p>
                        
                        <!-- Display all admin users -->
                        <h6 class="mt-3">Available Admin Users:</h6>
                        <ul class="list-group">
                            <?php
                            $stmt = $pdo->query("SELECT id, username, role FROM users WHERE role IN ('operator', 'admin', 'adm')");
                            $admins = $stmt->fetchAll();
                            
                            if (empty($admins)) {
                                echo '<li class="list-group-item">No admin users found</li>';
                            } else {
                                foreach ($admins as $admin) {
                                    echo '<li class="list-group-item">';
                                    echo '<strong>' . htmlspecialchars($admin['username']) . '</strong> ';
                                    echo '(ID: ' . $admin['id'] . ', Role: ' . htmlspecialchars($admin['role']) . ')';
                                    echo '</li>';
                                }
                            }
                            ?>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html> 