<?php
session_start();
include 'db.php';

// Redirect if not logged in
if (!isset($_SESSION['user_id'])) {
    $_SESSION['redirect_after_login'] = 'orders.php';
    header('Location: login.php');
    exit;
}

$user_id = $_SESSION['user_id'];

// Check if there are success or error messages
$success_message = $_SESSION['success_message'] ?? null;
$error_message = $_SESSION['error_message'] ?? null;

// Clear session messages after displaying them
unset($_SESSION['success_message']);
unset($_SESSION['error_message']);

// Fetch user's orders
try {
    $stmt = $pdo->prepare("SELECT * FROM orders WHERE user_id = ? ORDER BY created_at DESC");
    $stmt->execute([$user_id]);
    $orders = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    // Handle database error
    die("Error fetching orders: " . $e->getMessage());
}

// Calculate cart items count
$total_items = 0;
if (isset($_SESSION['cart'])) {
    foreach ($_SESSION['cart'] as $item) {
        $total_items += $item['quantity'];
    }
}

// Check if user is logged in
$isLoggedIn = isset($_SESSION['user_id']) || isset($_SESSION['admin_id']);
$username = $_SESSION['username'] ?? $_SESSION['admin_username'] ?? '';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>My Orders - EcomPro</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome for icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

    <style>
        .navbar-brand {
            font-weight: 700;
            font-size: 1.8rem;
            color: #0d6efd;
        }
        .orders-section {
            padding: 50px 0;
        }
        .order-card {
            transition: all 0.3s ease;
            border: none;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
            margin-bottom: 20px;
        }
        .order-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 20px rgba(0, 0, 0, 0.1);
        }
        .status-badge {
            font-size: 0.8rem;
            padding: 0.4rem 0.7rem;
        }
        .card-header {
            background-color: #f8f9fa;
            border-bottom: 1px solid rgba(0, 0, 0, 0.05);
        }
        .order-items-preview {
            background-color: #f8f9fa;
            padding: 15px;
            border-radius: 5px;
            margin-top: 15px;
        }
        .order-meta {
            display: flex;
            align-items: center;
            margin-bottom: 15px;
        }
        .order-meta-item {
            display: flex;
            align-items: center;
            margin-right: 20px;
        }
        .order-meta-item i {
            margin-right: 8px;
            color: #0d6efd;
        }
        .empty-state {
            text-align: center;
            padding: 80px 0;
            background-color: #f8f9fa;
            border-radius: 8px;
            margin: 30px 0;
        }
        .empty-state i {
            font-size: 5rem;
            color: #0d6efd;
            margin-bottom: 20px;
        }
        .btn-view-details {
            width: 100%;
            padding: 10px;
            font-weight: 500;
        }
        .page-header {
            background-color: #f8f9fa;
            padding: 30px 0;
            margin-bottom: 30px;
            border-bottom: 1px solid #dee2e6;
        }
        footer {
            margin-top: 60px;
        }
        .footer-links a {
            color: #fff;
            text-decoration: none;
            transition: color 0.3s;
        }
        .footer-links a:hover {
            color: #0d6efd;
            text-decoration: underline;
        }
        .social-icons i {
            font-size: 1.5rem;
            margin-right: 15px;
            color: #fff;
            transition: color 0.3s;
        }
        .social-icons i:hover {
            color: #0d6efd;
        }
    </style>
</head>
<body>

<!-- Main Navbar -->
<nav class="navbar navbar-expand-lg navbar-light bg-white shadow-sm">
    <div class="container">
        <a class="navbar-brand" href="index.php">EcomPro</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav me-auto">
                <li class="nav-item">
                    <a class="nav-link" href="index.php">Home</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="catalog.php">Catalog</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="about.php">About</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="contact.php">Contact</a>
                </li>
            </ul>
            <ul class="navbar-nav">
                <?php if ($isLoggedIn): ?>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown">
                            <i class="fas fa-user-circle me-1"></i> <?php echo htmlspecialchars($username); ?>
                        </a>
                        <ul class="dropdown-menu dropdown-menu-end">
                            <?php if (isset($_SESSION['admin_id'])): ?>
                                <li><a class="dropdown-item" href="admin/index.php">Admin Dashboard</a></li>
                                <li><hr class="dropdown-divider"></li>
                            <?php endif; ?>
                            <li><a class="dropdown-item" href="profile.php">My Profile</a></li>
                            <li><a class="dropdown-item" href="orders.php">My Orders</a></li>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item" href="logout.php">Logout</a></li>
                        </ul>
                    </li>
                <?php else: ?>
                    <li class="nav-item">
                        <a class="nav-link" href="login.php">Login</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="register.php">Register</a>
                    </li>
                <?php endif; ?>
                <li class="nav-item">
                    <a class="nav-link" href="cart.php">
                        <i class="fas fa-shopping-cart"></i>
                        <?php if ($total_items > 0): ?>
                            <span class="badge rounded-pill bg-danger"><?php echo $total_items; ?></span>
                        <?php endif; ?>
                    </a>
                </li>
            </ul>
        </div>
    </div>
</nav>

<!-- Page Header -->
<header class="page-header bg-light">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-md-6">
                <h1 class="fw-bold">My Orders</h1>
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb mb-0">
                        <li class="breadcrumb-item"><a href="index.php">Home</a></li>
                        <li class="breadcrumb-item active" aria-current="page">My Orders</li>
                    </ol>
                </nav>
            </div>
            <div class="col-md-6 text-md-end">
                <a href="catalog.php" class="btn btn-primary">
                    <i class="fas fa-shopping-cart me-2"></i>Continue Shopping
                </a>
            </div>
        </div>
    </div>
</header>

<!-- Orders Section -->
<section class="orders-section">
    <div class="container">
        <?php if (isset($success_message)): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <i class="fas fa-check-circle me-2"></i><?php echo $success_message; ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>
        
        <?php if (isset($error_message)): ?>
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <i class="fas fa-exclamation-circle me-2"></i><?php echo $error_message; ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>
        
        <?php if (empty($orders)): ?>
            <div class="empty-state">
                <i class="fas fa-shopping-bag"></i>
                <h3>No Orders Yet</h3>
                <p class="text-muted mb-4">You haven't placed any orders yet. Start shopping to place your first order!</p>
                <a href="catalog.php" class="btn btn-primary btn-lg">
                    <i class="fas fa-shopping-cart me-2"></i>Browse Products
                </a>
            </div>
        <?php else: ?>
            <div class="row">
                <?php foreach ($orders as $order): ?>
                    <div class="col-md-6">
                        <div class="card order-card h-100">
                            <div class="card-header d-flex justify-content-between align-items-center py-3">
                                <div>
                                    <h5 class="mb-0">Order #<?php echo htmlspecialchars($order['order_code']); ?></h5>
                                    <small class="text-muted">Placed on <?php echo date('F j, Y', strtotime($order['created_at'])); ?></small>
                                </div>
                                <?php
                                $statusClass = '';
                                $statusIcon = '';
                                switch ($order['status']) {
                                    case 'pending':
                                        $statusClass = 'bg-warning text-dark';
                                        $statusIcon = 'fa-clock';
                                        break;
                                    case 'processing':
                                        $statusClass = 'bg-info text-dark';
                                        $statusIcon = 'fa-cog fa-spin';
                                        break;
                                    case 'shipped':
                                        $statusClass = 'bg-primary';
                                        $statusIcon = 'fa-truck';
                                        break;
                                    case 'delivered':
                                        $statusClass = 'bg-success';
                                        $statusIcon = 'fa-check-circle';
                                        break;
                                    case 'cancelled':
                                        $statusClass = 'bg-danger';
                                        $statusIcon = 'fa-times-circle';
                                        break;
                                }
                                ?>
                                <span class="badge <?php echo $statusClass; ?> status-badge">
                                    <i class="fas <?php echo $statusIcon; ?> me-1"></i>
                                    <?php echo ucfirst($order['status']); ?>
                                </span>
                            </div>
                            <div class="card-body">
                                <div class="order-meta">
                                    <div class="order-meta-item">
                                        <i class="fas fa-money-bill-wave"></i>
                                        <span>$<?php echo number_format($order['total_amount'], 2); ?></span>
                                    </div>
                                    <div class="order-meta-item">
                                        <i class="fas fa-credit-card"></i>
                                        <span><?php echo ucfirst(str_replace('_', ' ', $order['payment_method'])); ?></span>
                                    </div>
                                </div>
                                
                                <?php
                                // Fetch order items
                                $stmt = $pdo->prepare("SELECT * FROM order_items WHERE order_id = ?");
                                $stmt->execute([$order['id']]);
                                $orderItems = $stmt->fetchAll(PDO::FETCH_ASSOC);
                                
                                // Count total items
                                $itemCount = 0;
                                foreach ($orderItems as $item) {
                                    $itemCount += $item['quantity'];
                                }
                                ?>
                                
                                <p class="text-muted mb-2"><i class="fas fa-box me-2"></i><?php echo $itemCount; ?> item(s) in this order</p>
                                
                                <div class="order-items-preview">
                                    <?php 
                                    // Show first 2 items
                                    $previewCount = min(2, count($orderItems));
                                    for ($i = 0; $i < $previewCount; $i++): 
                                        $item = $orderItems[$i];
                                    ?>
                                        <div class="d-flex justify-content-between mb-2">
                                            <div>
                                                <span class="fw-bold"><?php echo htmlspecialchars($item['product_name']); ?></span>
                                                <small class="text-muted d-block">Qty: <?php echo $item['quantity']; ?></small>
                                            </div>
                                            <div>
                                                $<?php echo number_format(($item['price'] - $item['discount']) * $item['quantity'], 2); ?>
                                            </div>
                                        </div>
                                    <?php endfor; ?>
                                    
                                    <?php if (count($orderItems) > 2): ?>
                                        <p class="text-muted small text-center mt-2">
                                            <i class="fas fa-ellipsis-h me-1"></i>
                                            And <?php echo count($orderItems) - 2; ?> more item(s)...
                                        </p>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="card-footer bg-white border-top-0 pt-0">
                                <div class="d-grid gap-2">
                                    <a href="order_detail.php?id=<?php echo $order['id']; ?>" class="btn btn-outline-primary btn-view-details">
                                        <i class="fas fa-eye me-2"></i>View Order Details
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>
</section>

<!-- Footer -->
<footer class="bg-dark text-white py-5">
    <div class="container">
        <div class="row">
            <div class="col-lg-4 mb-4 mb-lg-0">
                <h4 class="fw-bold mb-4">EcomPro</h4>
                <p>Your one-stop shop for quality products at affordable prices. We're dedicated to providing an exceptional shopping experience.</p>
                <div class="social-icons mt-3">
                    <a href="#"><i class="fab fa-facebook"></i></a>
                    <a href="#"><i class="fab fa-twitter"></i></a>
                    <a href="#"><i class="fab fa-instagram"></i></a>
                    <a href="#"><i class="fab fa-linkedin"></i></a>
                </div>
            </div>
            <div class="col-lg-2 col-md-4 mb-4 mb-md-0">
                <h5 class="mb-4">Quick Links</h5>
                <ul class="list-unstyled footer-links">
                    <li class="mb-2"><a href="index.php">Home</a></li>
                    <li class="mb-2"><a href="catalog.php">Catalog</a></li>
                    <li class="mb-2"><a href="about.php">About Us</a></li>
                    <li class="mb-2"><a href="contact.php">Contact</a></li>
                </ul>
            </div>
            <div class="col-lg-2 col-md-4 mb-4 mb-md-0">
                <h5 class="mb-4">Customer Service</h5>
                <ul class="list-unstyled footer-links">
                    <li class="mb-2"><a href="#">FAQ</a></li>
                    <li class="mb-2"><a href="#">Shipping Policy</a></li>
                    <li class="mb-2"><a href="#">Return Policy</a></li>
                    <li class="mb-2"><a href="#">Privacy Policy</a></li>
                </ul>
            </div>
            <div class="col-lg-4 col-md-4">
                <h5 class="mb-4">Contact Us</h5>
                <ul class="list-unstyled">
                    <li class="mb-2"><i class="fas fa-map-marker-alt me-2"></i> 123 Main St, City, Country</li>
                    <li class="mb-2"><i class="fas fa-phone me-2"></i> (123) 456-7890</li>
                    <li class="mb-2"><i class="fas fa-envelope me-2"></i> info@ecompro.com</li>
                    <li class="mb-2"><i class="fas fa-clock me-2"></i> Mon-Fri: 9AM - 6PM</li>
                </ul>
            </div>
        </div>
        <hr class="mt-4 mb-4">
        <div class="row">
            <div class="col-md-6 text-center text-md-start">
                <p class="mb-0">&copy; <?php echo date('Y'); ?> EcomPro. All rights reserved.</p>
            </div>
            <div class="col-md-6 text-center text-md-end">
                <p class="mb-0">
                    <i class="fab fa-cc-visa me-2 fs-5"></i>
                    <i class="fab fa-cc-mastercard me-2 fs-5"></i>
                    <i class="fab fa-cc-paypal me-2 fs-5"></i>
                    <i class="fab fa-cc-amex fs-5"></i>
                </p>
            </div>
        </div>
    </div>
</footer>

<!-- Bootstrap Bundle with Popper -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html> 