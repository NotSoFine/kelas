<?php
require 'db.php';

if (!isset($_GET['id'])) {
    echo "No product ID provided.";
    exit;
}

$product_id = $_GET['id'];

// Fetch product data
$stmt = $pdo->prepare("SELECT * FROM products WHERE id = ?");
$stmt->execute([$product_id]);
$product = $stmt->fetch();

if (!$product) {
    echo "Product not found.";
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'];
    $price = $_POST['price'];
    $stock = $_POST['stock'];
    $discount = isset($_POST['discount']) ? $_POST['discount'] : null;

    // If a new image is uploaded
    if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
        $imageTmp = $_FILES['image']['tmp_name'];
        $imageName = uniqid() . '_' . basename($_FILES['image']['name']);
        $imagePath = 'uploads/' . $imageName;

        if (!move_uploaded_file($imageTmp, $imagePath)) {
            echo "Failed to upload image.";
            exit;
        }
    } else {
        // Keep the old image if no new one is uploaded
        $imagePath = $product['image'];
    }

    // Update the product
    $update = $pdo->prepare("UPDATE products SET name = ?, price = ?, stock = ?, discount = ?, image = ? WHERE id = ?");
    $update->execute([$name, $price, $stock, $discount, $imagePath, $product_id]);

    header("Location: admin_panel.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Edit Product</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="p-5">
    <div class="container">
        <h2 class="mb-4">Edit Product</h2>
        <form method="POST" enctype="multipart/form-data" style="max-width: 600px;">
            <div class="mb-3">
                <label class="form-label">Product Name</label>
                <input type="text" name="name" class="form-control" value="<?= htmlspecialchars($product['name']) ?>" required>
            </div>
            <div class="mb-3">
                <label class="form-label">Price</label>
                <input type="number" name="price" class="form-control" value="<?= $product['price'] ?>" required>
            </div>
            <div class="mb-3">
                <label class="form-label">Stock</label>
                <input type="number" name="stock" class="form-control" value="<?= $product['stock'] ?>" required>
            </div>
            <div class="mb-3">
                <label class="form-label">Discount (optional)</label>
                <input type="number" name="discount" class="form-control" value="<?= $product['discount'] ?>">
            </div>
            <div class="mb-3">
                <label class="form-label">Current Image</label><br>
                <img src="<?= htmlspecialchars($product['image']) ?>" alt="Product Image" style="width: 200px; height: auto; object-fit: contain; border: 1px solid #ccc;">
            </div>
            <div class="mb-3">
                <label class="form-label">Replace Image</label>
                <input type="file" name="image" class="form-control">
            </div>
            <button type="submit" class="btn btn-primary">Update Product</button>
            <a href="admin_panel.php" class="btn btn-secondary">Cancel</a>
        </form>
    </div>
</body>
</html>
