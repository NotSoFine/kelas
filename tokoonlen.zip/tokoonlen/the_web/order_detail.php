<?php
session_start();
include 'db.php';

// Redirect if not logged in
if (!isset($_SESSION['user_id'])) {
    $_SESSION['redirect_after_login'] = 'orders.php';
    header('Location: login.php');
    exit;
}

// Check if order ID is provided
if (!isset($_GET['id'])) {
    header('Location: orders.php');
    exit;
}

$order_id = $_GET['id'];
$user_id = $_SESSION['user_id'];

// Fetch order details
try {
    // Verify that the order belongs to the current user
    $stmt = $pdo->prepare("SELECT * FROM orders WHERE id = ? AND user_id = ?");
    $stmt->execute([$order_id, $user_id]);
    $order = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$order) {
        // Order not found or doesn't belong to the current user
        header('Location: orders.php');
        exit;
    }
    
    // Fetch order items
    $stmt = $pdo->prepare("SELECT * FROM order_items WHERE order_id = ?");
    $stmt->execute([$order_id]);
    $order_items = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
} catch (PDOException $e) {
    // Handle database error
    die("Error fetching order details: " . $e->getMessage());
}

// Calculate cart items count (for navbar)
$total_items = 0;
if (isset($_SESSION['cart'])) {
    foreach ($_SESSION['cart'] as $item) {
        $total_items += $item['quantity'];
    }
}

// Check if user is logged in
$isLoggedIn = isset($_SESSION['user_id']) || isset($_SESSION['admin_id']);
$username = $_SESSION['username'] ?? $_SESSION['admin_username'] ?? '';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Order Details - EcomPro</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome for icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

    <style>
        .navbar-brand {
            font-weight: 700;
            font-size: 1.8rem;
            color: #0d6efd;
        }
        .order-detail-section {
            padding: 30px 0;
        }
        .order-details {
            background-color: #f8f9fa;
            border-radius: 0.25rem;
            padding: 20px;
        }
        .order-item {
            border-bottom: 1px solid #dee2e6;
            padding: 10px 0;
        }
        .order-item:last-child {
            border-bottom: none;
        }
        .total-line {
            border-top: 1px solid #dee2e6;
            padding-top: 10px;
            margin-top: 10px;
        }
        .grand-total {
            font-size: 1.2rem;
            font-weight: bold;
        }
        .status-badge {
            font-size: 0.9rem;
        }
        .timeline-item {
            position: relative;
            padding-left: 30px;
            margin-bottom: 15px;
        }
        .timeline-item:before {
            content: '';
            position: absolute;
            left: 0;
            top: 5px;
            width: 12px;
            height: 12px;
            border-radius: 50%;
            background-color: #0d6efd;
        }
        .timeline-item:after {
            content: '';
            position: absolute;
            left: 5px;
            top: 17px;
            height: calc(100% + 5px);
            border-left: 2px dashed #0d6efd;
        }
        .timeline-item:last-child:after {
            display: none;
        }
    </style>
</head>
<body>

<!-- Main Navbar -->
<nav class="navbar navbar-expand-lg navbar-light bg-white shadow-sm">
    <div class="container">
        <a class="navbar-brand" href="index.php">EcomPro</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav me-auto">
                <li class="nav-item">
                    <a class="nav-link" href="index.php">Home</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="catalog.php">Catalog</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="about.php">About</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="contact.php">Contact</a>
                </li>
            </ul>
            <ul class="navbar-nav">
                <?php if ($isLoggedIn): ?>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown">
                            <i class="fas fa-user-circle me-1"></i> <?php echo htmlspecialchars($username); ?>
                        </a>
                        <ul class="dropdown-menu dropdown-menu-end">
                            <?php if (isset($_SESSION['admin_id'])): ?>
                                <li><a class="dropdown-item" href="admin/index.php">Admin Dashboard</a></li>
                                <li><hr class="dropdown-divider"></li>
                            <?php endif; ?>
                            <li><a class="dropdown-item" href="profile.php">My Profile</a></li>
                            <li><a class="dropdown-item" href="orders.php">My Orders</a></li>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item" href="logout.php">Logout</a></li>
                        </ul>
                    </li>
                <?php else: ?>
                    <li class="nav-item">
                        <a class="nav-link" href="login.php">Login</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="register.php">Register</a>
                    </li>
                <?php endif; ?>
                <li class="nav-item">
                    <a class="nav-link" href="cart.php">
                        <i class="fas fa-shopping-cart"></i>
                        <?php if ($total_items > 0): ?>
                            <span class="badge rounded-pill bg-danger"><?php echo $total_items; ?></span>
                        <?php endif; ?>
                    </a>
                </li>
            </ul>
        </div>
    </div>
</nav>

<div class="container mt-4">
    <!-- Breadcrumb -->
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="index.php">Home</a></li>
            <li class="breadcrumb-item"><a href="orders.php">My Orders</a></li>
            <li class="breadcrumb-item active" aria-current="page">Order #<?php echo htmlspecialchars($order['order_code']); ?></li>
        </ol>
    </nav>
</div>

<!-- Order Detail Section -->
<section class="order-detail-section">
    <div class="container">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h1>Order #<?php echo htmlspecialchars($order['order_code']); ?></h1>
            <?php
            $statusClass = '';
            switch ($order['status']) {
                case 'pending':
                    $statusClass = 'bg-warning text-dark';
                    break;
                case 'processing':
                    $statusClass = 'bg-info text-dark';
                    break;
                case 'shipped':
                    $statusClass = 'bg-primary';
                    break;
                case 'delivered':
                    $statusClass = 'bg-success';
                    break;
                case 'cancelled':
                    $statusClass = 'bg-danger';
                    break;
            }
            ?>
            <span class="badge <?php echo $statusClass; ?> status-badge"><?php echo ucfirst($order['status']); ?></span>
        </div>
        
        <div class="row">
            <div class="col-lg-8">
                <!-- Order Information -->
                <div class="card mb-4">
                    <div class="card-header bg-primary text-white">
                        <h5 class="mb-0">Order Information</h5>
                    </div>
                    <div class="card-body">
                        <div class="row mb-4">
                            <div class="col-md-6">
                                <h6>Order Details</h6>
                                <p class="mb-1">Order Number: <?php echo htmlspecialchars($order['order_code']); ?></p>
                                <p class="mb-1">Date: <?php echo date('F j, Y', strtotime($order['created_at'])); ?></p>
                                <p class="mb-1">Time: <?php echo date('g:i A', strtotime($order['created_at'])); ?></p>
                                <p class="mb-1">Status: <span class="badge <?php echo $statusClass; ?>"><?php echo ucfirst($order['status']); ?></span></p>
                            </div>
                            <div class="col-md-6">
                                <h6>Payment Information</h6>
                                <p class="mb-1">Payment Method: <?php echo ucfirst(str_replace('_', ' ', $order['payment_method'])); ?></p>
                                <p class="mb-0">Total Amount: $<?php echo number_format($order['total_amount'], 2); ?></p>
                            </div>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-6">
                                <h6>Shipping Information</h6>
                                <p class="mb-1">Shipping Method: <?php echo ucfirst($order['shipping_method']); ?> Shipping</p>
                                <p class="mb-1">Address:</p>
                                <p class="mb-0"><?php echo nl2br(htmlspecialchars($order['shipping_address'])); ?></p>
                            </div>
                            <div class="col-md-6">
                                <h6>Billing Information</h6>
                                <p class="mb-1">Address:</p>
                                <p class="mb-0"><?php echo nl2br(htmlspecialchars($order['billing_address'])); ?></p>
                            </div>
                        </div>
                        
                        <?php if (!empty($order['notes'])): ?>
                            <div class="mt-4">
                                <h6>Order Notes</h6>
                                <p class="mb-0"><?php echo nl2br(htmlspecialchars($order['notes'])); ?></p>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
                
                <!-- Order Items -->
                <div class="card mb-4">
                    <div class="card-header bg-primary text-white">
                        <h5 class="mb-0">Order Items</h5>
                    </div>
                    <div class="card-body">
                        <div class="order-details">
                            <?php foreach ($order_items as $item): ?>
                                <div class="order-item">
                                    <div class="row">
                                        <div class="col-md-8">
                                            <h6 class="mb-1"><?php echo htmlspecialchars($item['product_name']); ?></h6>
                                            <p class="text-muted mb-0">Quantity: <?php echo $item['quantity']; ?></p>
                                        </div>
                                        <div class="col-md-4 text-md-end">
                                            <?php if ($item['discount'] > 0): ?>
                                                <p class="mb-0">
                                                    <span class="text-decoration-line-through text-muted">$<?php echo number_format($item['price'], 2); ?></span>
                                                    <span class="ms-2">$<?php echo number_format($item['price'] - $item['discount'], 2); ?></span>
                                                    <span class="d-block">Total: $<?php echo number_format(($item['price'] - $item['discount']) * $item['quantity'], 2); ?></span>
                                                </p>
                                            <?php else: ?>
                                                <p class="mb-0">
                                                    $<?php echo number_format($item['price'], 2); ?>
                                                    <span class="d-block">Total: $<?php echo number_format($item['price'] * $item['quantity'], 2); ?></span>
                                                </p>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                            
                            <div class="mt-3">
                                <div class="d-flex justify-content-between mb-2">
                                    <span>Subtotal</span>
                                    <span>$<?php echo number_format($order['total_amount'] - $order['shipping_fee'] - $order['tax_amount'], 2); ?></span>
                                </div>
                                <div class="d-flex justify-content-between mb-2">
                                    <span>Shipping (<?php echo ucfirst($order['shipping_method']); ?>)</span>
                                    <span>$<?php echo number_format($order['shipping_fee'], 2); ?></span>
                                </div>
                                <div class="d-flex justify-content-between mb-2">
                                    <span>Tax</span>
                                    <span>$<?php echo number_format($order['tax_amount'], 2); ?></span>
                                </div>
                                <div class="d-flex justify-content-between total-line grand-total">
                                    <span>Total</span>
                                    <span>$<?php echo number_format($order['total_amount'], 2); ?></span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="col-lg-4">
                <!-- Order Status Timeline -->
                <div class="card mb-4">
                    <div class="card-header bg-primary text-white">
                        <h5 class="mb-0">Order Status</h5>
                    </div>
                    <div class="card-body">
                        <div class="timeline">
                            <?php
                            // In a real application, you would fetch the order status history from the database
                            // For this demo, we'll create a simulated timeline based on the current status
                            
                            // Define all possible statuses in order
                            $allStatuses = ['pending', 'processing', 'shipped', 'delivered'];
                            $currentStatusIndex = array_search($order['status'], $allStatuses);
                            
                            // If the order is cancelled, show only that status
                            if ($order['status'] === 'cancelled') {
                                ?>
                                <div class="timeline-item">
                                    <h6>Order Placed</h6>
                                    <p class="text-muted mb-0"><?php echo date('F j, Y g:i A', strtotime($order['created_at'])); ?></p>
                                </div>
                                <div class="timeline-item">
                                    <h6 class="text-danger">Order Cancelled</h6>
                                    <p class="text-muted mb-0"><?php echo date('F j, Y g:i A', strtotime($order['updated_at'])); ?></p>
                                </div>
                                <?php
                            } else {
                                // Show all statuses up to the current one
                                for ($i = 0; $i <= $currentStatusIndex; $i++) {
                                    $status = $allStatuses[$i];
                                    $statusDate = $i === 0 ? $order['created_at'] : $order['updated_at'];
                                    $statusText = '';
                                    
                                    switch ($status) {
                                        case 'pending':
                                            $statusText = 'Order Placed';
                                            break;
                                        case 'processing':
                                            $statusText = 'Order Processing';
                                            break;
                                        case 'shipped':
                                            $statusText = 'Order Shipped';
                                            break;
                                        case 'delivered':
                                            $statusText = 'Order Delivered';
                                            break;
                                    }
                                    ?>
                                    <div class="timeline-item">
                                        <h6><?php echo $statusText; ?></h6>
                                        <p class="text-muted mb-0"><?php echo date('F j, Y g:i A', strtotime($statusDate)); ?></p>
                                    </div>
                                    <?php
                                }
                                
                                // Show upcoming statuses as pending
                                for ($i = $currentStatusIndex + 1; $i < count($allStatuses); $i++) {
                                    $status = $allStatuses[$i];
                                    $statusText = '';
                                    
                                    switch ($status) {
                                        case 'processing':
                                            $statusText = 'Order Processing';
                                            break;
                                        case 'shipped':
                                            $statusText = 'Order Shipped';
                                            break;
                                        case 'delivered':
                                            $statusText = 'Order Delivered';
                                            break;
                                    }
                                    ?>
                                    <div class="timeline-item">
                                        <h6 class="text-muted"><?php echo $statusText; ?></h6>
                                        <p class="text-muted mb-0">Pending</p>
                                    </div>
                                    <?php
                                }
                            }
                            ?>
                        </div>
                    </div>
                </div>
                
                <!-- Actions -->
                <div class="card">
                    <div class="card-header bg-primary text-white">
                        <h5 class="mb-0">Actions</h5>
                    </div>
                    <div class="card-body">
                        <div class="d-grid gap-2">
                            <a href="orders.php" class="btn btn-outline-primary">Back to My Orders</a>
                            
                            <?php if ($order['status'] === 'pending'): ?>
                                <button class="btn btn-outline-danger" data-bs-toggle="modal" data-bs-target="#cancelOrderModal">Cancel Order</button>
                            <?php endif; ?>
                            
                            <a href="contact.php" class="btn btn-outline-secondary">Contact Support</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Cancel Order Modal -->
<?php if ($order['status'] === 'pending'): ?>
    <div class="modal fade" id="cancelOrderModal" tabindex="-1" aria-labelledby="cancelOrderModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="cancelOrderModalLabel">Cancel Order</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <p>Are you sure you want to cancel this order?</p>
                    <p class="text-danger">This action cannot be undone.</p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <form action="cancel_order.php" method="POST">
                        <input type="hidden" name="order_id" value="<?php echo $order['id']; ?>">
                        <button type="submit" class="btn btn-danger">Cancel Order</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php endif; ?>

<!-- Footer -->
<footer class="bg-dark text-white mt-5 py-4">
    <div class="container">
        <div class="row">
            <div class="col-md-4">
                <h5>EcomPro</h5>
                <p>Your one-stop shop for quality products.</p>
            </div>
            <div class="col-md-4">
                <h5>Quick Links</h5>
                <ul class="list-unstyled">
                    <li><a href="index.php" class="text-white">Home</a></li>
                    <li><a href="catalog.php" class="text-white">Catalog</a></li>
                    <li><a href="about.php" class="text-white">About Us</a></li>
                    <li><a href="contact.php" class="text-white">Contact</a></li>
                </ul>
            </div>
            <div class="col-md-4">
                <h5>Contact Us</h5>
                <address>
                    <p><i class="fas fa-map-marker-alt me-2"></i> 123 Main St, City</p>
                    <p><i class="fas fa-phone me-2"></i> (123) 456-7890</p>
                    <p><i class="fas fa-envelope me-2"></i> info@ecompro.com</p>
                </address>
            </div>
        </div>
        <hr>
        <div class="text-center">
            <p>&copy; <?php echo date('Y'); ?> EcomPro. All rights reserved.</p>
        </div>
    </div>
</footer>

<!-- Bootstrap Bundle with Popper -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html> 