-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 26, 2025 at 12:33 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ecompro`
--

-- --------------------------------------------------------

--
-- Table structure for table `banners`
--

CREATE TABLE `banners` (
  `id` int(11) NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `image` varchar(255) NOT NULL,
  `link` varchar(255) DEFAULT NULL,
  `position` int(11) DEFAULT 0,
  `active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `banners`
--

INSERT INTO `banners` (`id`, `title`, `description`, `image`, `link`, `position`, `active`, `created_at`) VALUES
(1, 'Welcome to EcomPro', 'Your one-stop shop for quality products', 'assets/carousel/carousel1.png', 'index.php', 1, 1, '2025-05-24 12:38:12'),
(2, 'Great Deals', 'Check out our special offers', 'assets/carousel/carousel2.jpg', 'catalog.php?sort=price_low', 2, 1, '2025-05-24 12:38:12'),
(3, 'New Arrivals', 'Discover our latest products', 'assets/carousel/carousel3.jpg', 'catalog.php?sort=newest', 3, 1, '2025-05-24 12:38:12');

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `product_id` int(11) DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `front_display`
--

CREATE TABLE `front_display` (
  `id` int(11) NOT NULL,
  `product_id` int(11) DEFAULT NULL,
  `display_type` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` int(11) NOT NULL,
  `order_code` varchar(20) NOT NULL,
  `user_id` int(11) NOT NULL,
  `total_amount` decimal(10,2) NOT NULL,
  `status` enum('pending','processing','shipped','delivered','cancelled') NOT NULL DEFAULT 'pending',
  `shipping_address` text NOT NULL,
  `billing_address` text NOT NULL,
  `payment_method` varchar(50) NOT NULL,
  `shipping_method` varchar(50) NOT NULL,
  `shipping_fee` decimal(10,2) NOT NULL DEFAULT 0.00,
  `tax_amount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `notes` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `order_code`, `user_id`, `total_amount`, `status`, `shipping_address`, `billing_address`, `payment_method`, `shipping_method`, `shipping_fee`, `tax_amount`, `notes`, `created_at`, `updated_at`) VALUES
(1, 'ORD-14324C90', 5, 31536.30, 'delivered', 'St. Louis', 'St. Louis', 'paypal', 'overnight', 30.00, 1500.30, 'Package it with steel and aluminium', '2025-05-24 12:59:11', '2025-05-24 13:27:43'),
(2, 'ORD-8F54F845', 5, 3180.00, 'cancelled', 'St. Louis', 'St. Louis', 'cash_on_delivery', 'overnight', 30.00, 150.00, 'Fast as  it  could, Tip: 20$', '2025-05-24 22:18:08', '2025-05-24 22:18:22');

-- --------------------------------------------------------

--
-- Table structure for table `order_items`
--

CREATE TABLE `order_items` (
  `id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `product_name` varchar(255) NOT NULL,
  `quantity` int(11) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `discount` decimal(10,2) NOT NULL DEFAULT 0.00
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `order_items`
--

INSERT INTO `order_items` (`id`, `order_id`, `product_id`, `product_name`, `quantity`, `price`, `discount`) VALUES
(1, 1, 32, 'B90 stressfortress', 1, 200004.00, 170000.00),
(2, 1, 33, 'odwhewuiude', 1, 4.00, 2.00),
(3, 2, 31, 'this thing', 1, 20000.00, 17000.00);

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `price` decimal(10,2) DEFAULT NULL,
  `stock` int(11) DEFAULT NULL,
  `category` varchar(50) DEFAULT NULL,
  `tags` text DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `discount` int(11) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `image_path` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `name`, `description`, `price`, `stock`, `category`, `tags`, `image`, `discount`, `created_at`, `image_path`) VALUES
(30, 'sybdam hussam', 'You ever download a consciousness? No? Sybdam Hussam is what happens when an AI reads too much fanfic, learns about human emotion through memes, and achieves enlightenment during a Discord argument. It doesn’t run — it vibes. Built for absolutely nothing and everything at once. The UI? Confusing. The backend? Spaghetti-coded by a sleep-deprived prophet. But it works. Somehow.', 600000.00, 1, NULL, NULL, 'uploads/68121000232f2_2ac81dee-1a53-437d-a37c-dcbbc2f9e4ab.jpeg', 0, '2025-04-30 10:46:37', NULL),
(31, 'this thing', 'No name. No identity. Just vibes. “this thing” is the Schrödinger’s cat of software: simultaneously broken and revolutionary. You click it? It clicks back. Half tool, half existential crisis. Was it meant to solve a problem? Was it meant to become the problem? The answer is yes.', 20000.00, 4, NULL, NULL, 'uploads/6812ac9ec0d81_Image-3-Tomahawk-Long-Range-Cruise-Missile.png', 17000, '2025-04-30 23:05:02', NULL),
(32, 'B90 stressfortress', 'Finally — a solution for when you’re too calm. B90 Stressfortress is the ultimate productivity siege engine. Log in and immediately feel like you’re defending your sanity against 900 siege units of assignments, bugs, and deadlines. The UI screams at you (figuratively, for now). Every feature unlocks a new reason to panic. Therapeutic? Debatable. Iconic? Absolutely.', 200004.00, 3, NULL, NULL, 'uploads/6812b9505dddf_B52takeoff.png', 170000, '2025-04-30 23:59:12', NULL),
(33, 'odwhewuiude', 'Don’t try to pronounce it. Don’t try to understand it. Just feel it. odwhewuiude is the product of a keyboard faceplant and divine inspiration. It’s like if an error log became sentient and started a startup. It doesn\'t have a use case — it is the case. Open it, and you’re either entering the matrix or a haunted spreadsheet. No in-between.', 4.00, 4, NULL, NULL, 'uploads/6812b99c410d8_njsdit.png', 2, '2025-05-01 00:00:28', NULL),
(34, 'test', NULL, 12.00, 10, NULL, NULL, 'uploads/6834427e9d2ee_indomie.jpg', 9, '2025-05-26 10:29:18', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `reviews`
--

CREATE TABLE `reviews` (
  `id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `rating` int(11) NOT NULL,
  `comment` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `reviews`
--

INSERT INTO `reviews` (`id`, `product_id`, `user_id`, `rating`, `comment`, `created_at`) VALUES
(1, 31, 4, 5, 'Amazing product, now i can  blow up my annoying neighbor!', '2025-05-24 12:00:04'),
(2, 31, 5, 5, 'great product', '2025-05-24 22:20:21');

-- --------------------------------------------------------

--
-- Table structure for table `settings`
--

CREATE TABLE `settings` (
  `id` int(11) NOT NULL,
  `setting_key` varchar(100) NOT NULL,
  `setting_value` text DEFAULT NULL,
  `setting_type` varchar(50) DEFAULT 'text',
  `setting_group` varchar(50) DEFAULT 'general',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `settings`
--

INSERT INTO `settings` (`id`, `setting_key`, `setting_value`, `setting_type`, `setting_group`, `created_at`, `updated_at`) VALUES
(1, 'site_name', 'eCompro', 'text', 'general', '2025-05-24 23:21:13', '2025-05-24 23:21:13'),
(2, 'site_description', 'Your Online Shopping Destination', 'textarea', 'general', '2025-05-24 23:21:13', '2025-05-24 23:21:13'),
(3, 'site_email', 'contact@ecompro.com', 'email', 'contact', '2025-05-24 23:21:13', '2025-05-24 23:21:13'),
(4, 'enable_reviews', '1', 'boolean', 'products', '2025-05-24 23:21:13', '2025-05-24 23:21:13'),
(5, 'products_per_page', '12', 'number', 'products', '2025-05-24 23:21:13', '2025-05-24 23:21:13'),
(6, 'shipping_fee', '5.00', 'number', 'checkout', '2025-05-24 23:21:13', '2025-05-24 23:21:13'),
(7, 'tax_rate', '7', 'number', 'checkout', '2025-05-24 23:21:13', '2025-05-24 23:21:13'),
(8, 'currency_symbol', '$', 'text', 'general', '2025-05-24 23:21:13', '2025-05-24 23:21:13'),
(9, 'phone_number', '+1234567890', 'text', 'contact', '2025-05-24 23:21:13', '2025-05-24 23:21:13'),
(10, 'address', '123 Shopping St, Ecommerce City, 12345', 'textarea', 'contact', '2025-05-24 23:21:13', '2025-05-24 23:21:13');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) DEFAULT NULL,
  `password` varchar(100) DEFAULT NULL,
  `role` enum('guest','user','operator') DEFAULT 'user',
  `address` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `role`, `address`) VALUES
(1, 'operator', 'operator123', 'user', NULL),
(2, 'normaluser', 'user123', 'user', NULL),
(4, 'test', 'test', 'operator', NULL),
(5, 'test1', 'test1', 'user', NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `banners`
--
ALTER TABLE `banners`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `product_id` (`product_id`);

--
-- Indexes for table `front_display`
--
ALTER TABLE `front_display`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `order_items`
--
ALTER TABLE `order_items`
  ADD PRIMARY KEY (`id`),
  ADD KEY `order_id` (`order_id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `reviews`
--
ALTER TABLE `reviews`
  ADD PRIMARY KEY (`id`),
  ADD KEY `product_id` (`product_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `settings`
--
ALTER TABLE `settings`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `setting_key` (`setting_key`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `banners`
--
ALTER TABLE `banners`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `cart`
--
ALTER TABLE `cart`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `front_display`
--
ALTER TABLE `front_display`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `order_items`
--
ALTER TABLE `order_items`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;

--
-- AUTO_INCREMENT for table `reviews`
--
ALTER TABLE `reviews`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `settings`
--
ALTER TABLE `settings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `cart`
--
ALTER TABLE `cart`
  ADD CONSTRAINT `cart_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `cart_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`);

--
-- Constraints for table `order_items`
--
ALTER TABLE `order_items`
  ADD CONSTRAINT `order_items_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `reviews`
--
ALTER TABLE `reviews`
  ADD CONSTRAINT `reviews_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `reviews_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
